# 🔧 "Failed to Fetch" Error - Complete Fix Guide

## Problem
Getting "Failed to fetch" error when trying to load states/districts in the FRA Atlas application.

## Root Cause
The main issue is that you're opening the HTML file directly using `file://` protocol instead of through a web server (`http://`). 

When you double-click `index.html`, it opens as:
```
file:///Users/arman2006/path/to/index.html  ❌ WRONG
```

It should be:
```
http://localhost:8080/index.html  ✅ CORRECT
```

### Why file:// doesn't work?
- **CORS (Cross-Origin Resource Sharing)** blocks requests from `file://` to `http://localhost:5001`
- Browsers treat `file://` as a different origin than `http://`
- This causes "Failed to fetch" errors even though the backend is running fine

## Solution

### Option 1: Using Python (Recommended)

1. **Open Terminal in project root directory**

2. **Start the frontend server:**
   ```bash
   python3 -m http.server 8080
   ```
   
   Or if you have Python 2:
   ```bash
   python -m SimpleHTTPServer 8080
   ```

3. **Open browser and go to:**
   ```
   http://localhost:8080/index.html
   ```

4. **Keep both servers running:**
   - Backend: `http://localhost:5001` (in server directory)
   - Frontend: `http://localhost:8080` (in root directory)

### Option 2: Using Node.js

1. **Install http-server globally:**
   ```bash
   npm install -g http-server
   ```

2. **Start the server:**
   ```bash
   http-server -p 8080
   ```

3. **Open browser:**
   ```
   http://localhost:8080/index.html
   ```

### Option 3: Using VS Code Live Server

1. **Install "Live Server" extension** in VS Code

2. **Right-click on `index.html`**

3. **Select "Open with Live Server"**

4. **It will automatically open** at `http://127.0.0.1:5500/index.html`

### Option 4: Using PHP

1. **Start PHP server:**
   ```bash
   php -S localhost:8080
   ```

2. **Open browser:**
   ```
   http://localhost:8080/index.html
   ```

## Complete Startup Process

### Step 1: Start Backend
```bash
cd server
npm start
# Backend running at http://localhost:5001
```

### Step 2: Start Frontend (in new terminal)
```bash
# Go back to project root
cd ..

# Start frontend server
python3 -m http.server 8080
# Frontend running at http://localhost:8080
```

### Step 3: Open Application
```
Open browser: http://localhost:8080/index.html
```

## Verification Steps

### 1. Test API Connection
Open this file in browser (via http://):
```
http://localhost:8080/test-api-connection.html
```

This will:
- ✅ Check if you're using correct protocol
- ✅ Test backend connectivity
- ✅ Test all geo API endpoints
- ✅ Verify CORS configuration

### 2. Check Browser Console
1. Open DevTools (F12)
2. Go to Console tab
3. Look for errors
4. Should see: "✅ Loaded X states into claim form"

### 3. Check Network Tab
1. Open DevTools (F12)
2. Go to Network tab
3. Try to load states/districts
4. Should see successful requests to `http://localhost:5001/api/geo/...`

## Common Issues & Solutions

### Issue 1: "Failed to fetch" still appearing
**Solution:** Make sure you're NOT opening file directly
- ❌ Wrong: `file:///Users/.../index.html`
- ✅ Correct: `http://localhost:8080/index.html`

### Issue 2: "Connection refused"
**Solution:** Backend server not running
```bash
cd server
npm start
```

### Issue 3: "Port 8080 already in use"
**Solution:** Use different port
```bash
python3 -m http.server 8081
# Then open http://localhost:8081/index.html
```

### Issue 4: CORS error even with http://
**Solution:** Check backend CORS configuration
```javascript
// In server/app.js, should have:
app.use(cors({
    origin: ['http://localhost:8080', 'http://localhost:3000', 'http://127.0.0.1:8080'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
```

### Issue 5: States load but districts don't
**Solution:** Clear localStorage cache
```javascript
// In browser console:
localStorage.removeItem('fra_geo_filters');
location.reload();
```

## Quick Test Commands

### Test Backend Health
```bash
curl http://localhost:5001/api/health
```

### Test States API
```bash
curl http://localhost:5001/api/geo/states
```

### Test Districts API
```bash
curl http://localhost:5001/api/geo/districts/JH
```

## Files Created for Debugging

1. **test-api-connection.html** - Comprehensive API connection tester
2. **test-claim-form-geo.html** - Isolated claim form geo hierarchy test
3. **fix-geo-cache.html** - Cache diagnostic and clearing tool

## Summary

The "Failed to fetch" error is caused by:
1. ❌ Opening HTML file directly (file:// protocol)
2. ✅ **FIX:** Use a local web server (http:// protocol)

**Quick Fix:**
```bash
# Terminal 1 - Backend
cd server && npm start

# Terminal 2 - Frontend
python3 -m http.server 8080

# Browser
http://localhost:8080/index.html
```

## Status
✅ **ISSUE IDENTIFIED** - Need to use http:// protocol instead of file://
✅ **SOLUTION PROVIDED** - Multiple options to start local server
✅ **TEST TOOLS CREATED** - Diagnostic pages for verification
