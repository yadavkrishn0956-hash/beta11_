# 🔧 Chatbot Not Showing - Quick Fix Guide

## 🔍 Problem: Chatbot Nahi Dikh Raha

Agar chatbot button bottom-right corner mein nahi dikh raha, toh ye steps follow karo:

---

## ✅ Quick Fixes

### Fix 1: Debug Page Se Check Karo
```
http://localhost:8080/debug-chatbot.html
```

Ye page automatically check karega:
- ✅ Chatbot button exists?
- ✅ Chatbot window exists?
- ✅ FRAAssistant class loaded?
- ✅ Instance created?
- ✅ Lucide icons loaded?

**Actions:**
- Click "Check Chatbot Status" - Status dekhne ke liye
- Click "Force Show Chatbot" - Manually chatbot create karne ke liye
- Click "Test Chatbot" - Chatbot toggle karne ke liye
- Click "Clear Cache & Reload" - Cache clear karke reload karne ke liye

---

### Fix 2: Browser Console Check Karo

1. **Open Console:**
   - Press `F12` or `Cmd+Option+I` (Mac)
   - Go to "Console" tab

2. **Check for Errors:**
   ```javascript
   // Look for red error messages
   // Common errors:
   // - "FRAAssistant is not defined"
   // - "Cannot read property of undefined"
   // - "Failed to load resource"
   ```

3. **Manual Check:**
   ```javascript
   // Type in console:
   console.log(window.fraAssistant);
   console.log(typeof FRAAssistant);
   console.log(document.querySelector('.chatbot-button'));
   ```

---

### Fix 3: Force Create Chatbot

**In Browser Console:**
```javascript
// Create chatbot manually
window.fraAssistant = new FRAAssistant();

// Initialize icons
if (typeof lucide !== 'undefined') {
    lucide.createIcons();
}

// Check if button appears
console.log(document.querySelector('.chatbot-button'));
```

---

### Fix 4: Check Files Are Loading

**Test URLs:**
```
http://localhost:8080/chatbot.css
http://localhost:8080/chatbot.js
http://localhost:8080/chatbot-map-integration.js
```

All should return 200 OK.

**In Console:**
```javascript
// Check if scripts loaded
console.log('Lucide:', typeof lucide);
console.log('API:', typeof api);
console.log('FRAAssistant:', typeof FRAAssistant);
```

---

### Fix 5: Clear Cache & Hard Reload

**Chrome/Edge:**
```
Ctrl+Shift+Delete (Windows)
Cmd+Shift+Delete (Mac)

Then:
Ctrl+Shift+R (Windows)
Cmd+Shift+R (Mac)
```

**Or:**
```
Right-click on reload button → "Empty Cache and Hard Reload"
```

---

### Fix 6: Check Z-Index Issues

**In Console:**
```javascript
const button = document.querySelector('.chatbot-button');
if (button) {
    button.style.zIndex = '99999';
    button.style.display = 'flex';
    console.log('Button forced to show');
}
```

---

### Fix 7: Verify Script Order

Scripts should load in this order:
```html
1. api.js
2. script.js
3. chatbot-map-integration.js
4. chatbot.js
```

Check in `index.html`:
```html
<script src="api.js"></script>
<script src="script.js"></script>
<script src="chatbot-map-integration.js"></script>
<script src="chatbot.js"></script>
```

---

## 🐛 Common Issues & Solutions

### Issue 1: "FRAAssistant is not defined"
**Solution:**
```javascript
// Reload chatbot.js
const script = document.createElement('script');
script.src = 'chatbot.js';
document.body.appendChild(script);
```

### Issue 2: Button Exists But Not Visible
**Solution:**
```javascript
const button = document.getElementById('chatbot-button');
button.style.display = 'flex';
button.style.position = 'fixed';
button.style.bottom = '2rem';
button.style.right = '2rem';
button.style.zIndex = '9999';
```

### Issue 3: DOMContentLoaded Already Fired
**Solution:**
```javascript
// Create immediately
if (document.readyState === 'complete') {
    window.fraAssistant = new FRAAssistant();
    lucide.createIcons();
}
```

### Issue 4: CSS Not Loading
**Solution:**
```javascript
// Add CSS manually
const link = document.createElement('link');
link.rel = 'stylesheet';
link.href = 'chatbot.css';
document.head.appendChild(link);
```

---

## 🔧 Manual Chatbot Creation

If nothing works, create chatbot manually:

```javascript
// 1. Check if class exists
if (typeof FRAAssistant === 'undefined') {
    console.error('FRAAssistant class not loaded!');
    // Reload the script
    const script = document.createElement('script');
    script.src = 'chatbot.js';
    script.onload = () => {
        window.fraAssistant = new FRAAssistant();
        lucide.createIcons();
    };
    document.body.appendChild(script);
} else {
    // 2. Create instance
    window.fraAssistant = new FRAAssistant();
    
    // 3. Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // 4. Force show button
    setTimeout(() => {
        const button = document.getElementById('chatbot-button');
        if (button) {
            button.style.display = 'flex';
            console.log('✅ Chatbot button shown!');
        } else {
            console.error('❌ Button element not found!');
        }
    }, 500);
}
```

---

## 📊 Verification Steps

### Step 1: Check Elements
```javascript
console.log('Button:', document.querySelector('.chatbot-button'));
console.log('Window:', document.querySelector('.chatbot-window'));
console.log('Badge:', document.querySelector('.chatbot-badge'));
```

### Step 2: Check Classes
```javascript
console.log('FRAAssistant:', typeof FRAAssistant);
console.log('Instance:', window.fraAssistant);
```

### Step 3: Check Styles
```javascript
const button = document.querySelector('.chatbot-button');
if (button) {
    const styles = window.getComputedStyle(button);
    console.log('Display:', styles.display);
    console.log('Position:', styles.position);
    console.log('Z-Index:', styles.zIndex);
    console.log('Bottom:', styles.bottom);
    console.log('Right:', styles.right);
}
```

---

## 🚀 Quick Test Commands

**Test in Console:**
```javascript
// 1. Check everything
console.log({
    fraAssistant: window.fraAssistant,
    FRAAssistant: typeof FRAAssistant,
    button: document.querySelector('.chatbot-button'),
    window: document.querySelector('.chatbot-window'),
    lucide: typeof lucide,
    api: typeof api
});

// 2. Force create
window.fraAssistant = new FRAAssistant();

// 3. Toggle chat
window.fraAssistant.toggleChat();

// 4. Send test message
window.fraAssistant.addMessage('Test message', 'user');
```

---

## 📱 Mobile Issues

If chatbot not showing on mobile:

```css
/* Check mobile styles */
@media (max-width: 768px) {
    .chatbot-button {
        display: flex !important;
        bottom: 1rem !important;
        right: 1rem !important;
    }
}
```

---

## ✅ Success Checklist

- [ ] Debug page shows all green checkmarks
- [ ] Console has no errors
- [ ] Button visible in bottom-right
- [ ] Clicking button opens chat window
- [ ] Icons are rendering
- [ ] Messages can be sent
- [ ] Quick replies work

---

## 📞 Still Not Working?

### Last Resort:
1. Stop servers
2. Clear browser cache completely
3. Restart servers
4. Open in incognito/private window
5. Try different browser

### Commands:
```bash
# Stop servers
kill -9 $(lsof -ti:8080)
kill -9 $(lsof -ti:5001)

# Restart
cd server && npm start &
python3 -m http.server 8080 &

# Open fresh
open http://localhost:8080
```

---

## 🎯 Quick Links

- **Debug Page:** http://localhost:8080/debug-chatbot.html
- **Main App:** http://localhost:8080
- **Test Chatbot:** http://localhost:8080/test-chatbot.html

---

**Status:** Troubleshooting Guide
**Date:** October 28, 2025
**Purpose:** Fix chatbot visibility issues

🔧 **Follow these steps and your chatbot will appear!**
