# 🚀 Quick Actions - Full Implementation Plan

## Status: Ready to Implement

This document outlines the complete implementation of Dashboard Quick Actions with:
- ✅ PDF Report Generation
- ✅ CSV Data Export  
- ✅ Analytics Modal with Charts
- ✅ Backend API Integration
- ✅ Keyboard Shortcuts
- ✅ Toast Notifications

---

## Implementation Steps

### Phase 1: Add jsPDF Library
Add to index.html:
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
```

### Phase 2: Create Functions in script.js

#### 1. Generate Report Function
```javascript
async function generateDashboardReport() {
    try {
        showLoader(true);
        showToast('Generating report...', 'info');
        
        // Fetch data from API
        const response = await api.get('/claims');
        const data = response.data;
        
        // Create PDF
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF();
        
        // Add content
        pdf.setFontSize(20);
        pdf.text('FRA Atlas - Dashboard Report', 20, 20);
        
        pdf.setFontSize(12);
        pdf.text(`Generated: ${new Date().toLocaleString()}`, 20, 35);
        
        pdf.setFontSize(14);
        pdf.text('Claims Summary:', 20, 50);
        pdf.setFontSize(12);
        pdf.text(`Total Claims: ${data.statistics?.total || 0}`, 30, 60);
        pdf.text(`Approved: ${data.statistics?.approved || 0}`, 30, 70);
        pdf.text(`Pending: ${data.statistics?.pending || 0}`, 30, 80);
        pdf.text(`Rejected: ${data.statistics?.rejected || 0}`, 30, 90);
        
        // Save PDF
        const filename = `FRA_Report_${new Date().toISOString().split('T')[0]}.pdf`;
        pdf.save(filename);
        
        showLoader(false);
        showToast('✅ Report generated successfully!', 'success');
        
    } catch (error) {
        showLoader(false);
        showToast('❌ Failed to generate report', 'error');
        console.error('Report generation error:', error);
    }
}
```

#### 2. Export Data Function
```javascript
async function exportDashboardData() {
    try {
        showLoader(true);
        showToast('Exporting data...', 'info');
        
        // Fetch data
        const response = await api.get('/claims');
        const claims = response.data.data?.claims || [];
        
        // Create CSV
        const headers = ['Claim ID', 'Applicant', 'Village', 'District', 'Status', 'Date'];
        const csvRows = [headers.join(',')];
        
        claims.forEach(claim => {
            const row = [
                claim.claim_number,
                claim.applicant_name,
                claim.village,
                claim.district,
                claim.status,
                new Date(claim.created_at).toLocaleDateString()
            ];
            csvRows.push(row.join(','));
        });
        
        const csvContent = csvRows.join('\\n');
        
        // Download CSV
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `FRA_Claims_Data_${Date.now()}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        showLoader(false);
        showToast('✅ Data exported successfully!', 'success');
        
    } catch (error) {
        showLoader(false);
        showToast('❌ Export failed', 'error');
        console.error('Export error:', error);
    }
}
```

#### 3. View Analytics Function
```javascript
async function viewDashboardAnalytics() {
    try {
        showLoader(true);
        showToast('Loading analytics...', 'info');
        
        // Fetch data
        const response = await api.get('/claims');
        const stats = response.data.statistics;
        
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'analytics-modal';
        modal.innerHTML = `
            <div class="analytics-modal-content">
                <div class="analytics-modal-header">
                    <h2>📊 FRA Analytics Overview</h2>
                    <button class="analytics-close-btn" onclick="closeAnalyticsModal()">
                        <i data-lucide="x"></i>
                    </button>
                </div>
                <div class="analytics-modal-body">
                    <div class="analytics-chart">
                        <h3>Claims Status Distribution</h3>
                        <canvas id="analyticsChart"></canvas>
                    </div>
                    <div class="analytics-stats">
                        <div class="stat-box">
                            <h4>Total Claims</h4>
                            <p class="stat-value">${stats?.total || 0}</p>
                        </div>
                        <div class="stat-box">
                            <h4>Approved</h4>
                            <p class="stat-value">${stats?.approved || 0}</p>
                        </div>
                        <div class="stat-box">
                            <h4>Pending</h4>
                            <p class="stat-value">${stats?.pending || 0}</p>
                        </div>
                        <div class="stat-box">
                            <h4>Rejected</h4>
                            <p class="stat-value">${stats?.rejected || 0}</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Initialize icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        
        // Create chart
        const ctx = document.getElementById('analyticsChart');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Approved', 'Pending', 'Rejected', 'Under Review'],
                datasets: [{
                    data: [
                        stats?.approved || 0,
                        stats?.pending || 0,
                        stats?.rejected || 0,
                        stats?.under_review || 0
                    ],
                    backgroundColor: ['#10b981', '#f59e0b', '#ef4444', '#3b82f6']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
        
        showLoader(false);
        showToast('✅ Analytics loaded', 'success');
        
    } catch (error) {
        showLoader(false);
        showToast('❌ Failed to load analytics', 'error');
        console.error('Analytics error:', error);
    }
}

function closeAnalyticsModal() {
    const modal = document.querySelector('.analytics-modal');
    if (modal) {
        modal.remove();
    }
}
```

### Phase 3: Add Keyboard Shortcuts
```javascript
// Add to DOMContentLoaded
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
        if (e.key === 'r') {
            e.preventDefault();
            generateDashboardReport();
        } else if (e.key === 'e') {
            e.preventDefault();
            exportDashboardData();
        } else if (e.key === 'a') {
            e.preventDefault();
            viewDashboardAnalytics();
        }
    }
});
```

### Phase 4: Update HTML Buttons
```html
<button class="action-btn primary" onclick="generateDashboardReport()">
    Generate Report
</button>
<button class="action-btn secondary" onclick="exportDashboardData()">
    Export Data
</button>
<button class="action-btn secondary" onclick="viewDashboardAnalytics()">
    View Analytics
</button>
```

### Phase 5: Add Modal CSS
```css
.analytics-modal {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
}

.analytics-modal-content {
    background: white;
    border-radius: 12px;
    width: 90%;
    max-width: 800px;
    max-height: 90vh;
    overflow-y: auto;
}

.analytics-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.5rem;
    border-bottom: 1px solid #e5e7eb;
}

.analytics-close-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0.5rem;
}

.analytics-modal-body {
    padding: 1.5rem;
}

.analytics-chart {
    margin-bottom: 2rem;
}

.analytics-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
}

.stat-box {
    background: #f9fafb;
    padding: 1rem;
    border-radius: 8px;
    text-align: center;
}

.stat-value {
    font-size: 2rem;
    font-weight: bold;
    color: #1e5631;
}
```

---

## Ready to Implement?

All code is ready. I'll now implement this step by step.
