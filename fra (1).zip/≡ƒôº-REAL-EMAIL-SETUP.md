# 📧 Real Email Setup Guide

## Problem
Notifications show "Schedule activated!" but emails don't actually send because:
1. Email credentials are placeholders
2. Using demo SMTP settings

## Solution: Real Email Integration

### Option 1: Gmail (Easiest for Testing)

#### Step 1: Enable 2-Factor Authentication
1. Go to Google Account: https://myaccount.google.com
2. Security → 2-Step Verification → Turn On

#### Step 2: Generate App Password
1. Go to: https://myaccount.google.com/apppasswords
2. Select "Mail" and "Other (Custom name)"
3. Name it: "FRA Atlas"
4. Click "Generate"
5. Copy the 16-character password

#### Step 3: Update .env File
```bash
# In server/.env
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-actual-email@gmail.com
EMAIL_PASS=your-16-char-app-password
```

#### Step 4: Restart Server
```bash
cd server
npm start
```

### Option 2: Government Email (Production)

For official government deployment:

```bash
# In server/.env
EMAIL_HOST=smtp.gov.in
EMAIL_PORT=587
EMAIL_USER=fra.atlas@tribal.gov.in
EMAIL_PASS=official_password
```

### Option 3: SendGrid (Scalable)

For high-volume emails:

1. Sign up: https://sendgrid.com
2. Get API key
3. Update code to use SendGrid API

## Testing Real Emails

### Test 1: Manual Email Test

Create `server/test-email.js`:
```javascript
const nodemailer = require('nodemailer');
require('dotenv').config();

async function testEmail() {
    const transporter = nodemailer.createTransporter({
        host: process.env.EMAIL_HOST,
        port: process.env.EMAIL_PORT,
        secure: false,
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    try {
        const info = await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: 'your-test-email@gmail.com',
            subject: 'FRA Atlas Test Email',
            text: 'If you receive this, email is working!',
            html: '<h1>Success!</h1><p>Email configuration is working.</p>'
        });

        console.log('✅ Email sent:', info.messageId);
    } catch (error) {
        console.error('❌ Email failed:', error.message);
    }
}

testEmail();
```

Run test:
```bash
cd server
node test-email.js
```

### Test 2: Test via API

```bash
curl -X POST http://localhost:5001/api/reports/share \
  -H "Content-Type: application/json" \
  -d '{
    "email": "your-email@gmail.com",
    "format": "pdf",
    "startDate": "2025-01-01",
    "endDate": "2025-01-31"
  }'
```

## Current Status

### ✅ What's Working:
- PDF generation
- Excel generation
- Email template creation
- API endpoints

### ⚠️ What Needs Real Credentials:
- Actual email sending
- Weekly cron job emails

## Quick Fix for Demo

If you don't want to setup real email but want realistic notifications:

### Update emailReports.js to log instead of send:

```javascript
// In server/utils/emailReports.js
async function sendReportEmail(recipientEmail, format, reportData, startDate, endDate) {
    try {
        // Generate report file
        let attachment;
        let filename;
        
        if (format === 'pdf') {
            attachment = await generatePDFReport(reportData, startDate, endDate);
            filename = `FRA_Report_${startDate}_${endDate}.pdf`;
        } else {
            attachment = await generateExcelReport(reportData, startDate, endDate);
            filename = `FRA_Report_${startDate}_${endDate}.xlsx`;
        }
        
        // FOR DEMO: Log instead of sending
        console.log(`
📧 EMAIL WOULD BE SENT:
To: ${recipientEmail}
Subject: FRA Atlas Report - ${startDate} to ${endDate}
Attachment: ${filename} (${attachment.length} bytes)
        `);
        
        // Simulate success
        return { 
            success: true, 
            messageId: `demo-${Date.now()}`,
            note: 'Email logged (not sent) - configure SMTP for real sending'
        };
        
    } catch (error) {
        console.error('❌ Error preparing email:', error);
        throw error;
    }
}
```

## Production Checklist

Before deploying to production:

- [ ] Real email credentials configured
- [ ] Test email sending works
- [ ] Verify email deliverability
- [ ] Check spam folder
- [ ] Add SPF/DKIM records (for government domain)
- [ ] Set up email monitoring
- [ ] Configure bounce handling
- [ ] Add unsubscribe option (if needed)

## Troubleshooting

### Error: "Invalid login"
- Check email/password are correct
- Ensure 2FA is enabled
- Generate new app password

### Error: "Connection timeout"
- Check firewall settings
- Verify SMTP port (587 or 465)
- Try different network

### Emails go to spam
- Add SPF record to domain
- Set up DKIM signing
- Use verified sender address

## Alternative: File-based Reports

If email is not critical, save reports to disk:

```javascript
// Save report to file instead of emailing
const fs = require('fs');
const reportPath = `./reports/${filename}`;
fs.writeFileSync(reportPath, attachment);
console.log(`✅ Report saved: ${reportPath}`);
```

## Status

**Current**: Mock email (logs only)
**To Enable Real Emails**: Add Gmail app password to `.env`
**For Production**: Use government SMTP server

Choose the option that fits your needs!
