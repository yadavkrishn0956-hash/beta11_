# 🚀 How to Start FRA Atlas Application

## ✅ Both Servers Are Now Running!

### Backend Server
- **Status**: ✅ Running
- **Port**: 5001
- **URL**: http://localhost:5001
- **Health**: http://localhost:5001/api/health

### Frontend Server
- **Status**: ✅ Running
- **Port**: 8080
- **URL**: http://localhost:8080

## 🌐 Access Application

**Open in browser:**
```
http://localhost:8080/index.html
```

**OR just:**
```
http://localhost:8080
```

## 🔍 Verify Servers

### Check Backend:
```bash
curl http://localhost:5001/api/health
```

Should return:
```json
{"success":true,"status":"running",...}
```

### Check Frontend:
```bash
curl http://localhost:8080
```

Should return HTML content.

## 📊 Current Status

```
✅ Backend:  http://localhost:5001 (Running)
✅ Frontend: http://localhost:8080 (Running)
✅ Cron Jobs: Active (Weekly reports Sunday 9 AM)
✅ WebSocket: Enabled
✅ All APIs: Working
```

## 🎯 Quick Links

- **Main App**: http://localhost:8080/index.html
- **API Health**: http://localhost:5001/api/health
- **Test API Connection**: http://localhost:8080/test-api-connection.html
- **Test Geo Hierarchy**: http://localhost:8080/test-geo-hierarchy.html

## 🛑 If Servers Stop

### Restart Backend:
```bash
cd server
npm start
```

### Restart Frontend:
```bash
# In project root
python3 -m http.server 8080
```

## 💡 Common Issues

### Issue 1: Port Already in Use
```bash
# Kill process on port 5001
lsof -ti:5001 | xargs kill -9

# Kill process on port 8080
lsof -ti:8080 | xargs kill -9
```

### Issue 2: Dependencies Missing
```bash
cd server
npm install
```

### Issue 3: Python Not Found
```bash
# Try python instead of python3
python -m http.server 8080

# Or use Node.js
npx http-server -p 8080
```

## 📝 Features Available

### ✅ Working Features:
1. **Dashboard** - Analytics and KPIs
2. **Map** - Interactive claim mapping
3. **Draw Claim** - Create claims by drawing polygons
4. **Claims** - View and manage all claims
5. **Geo Hierarchy** - States/Districts/Villages
6. **Reports** - PDF/Excel generation (backend ready)
7. **Real-time Notifications** - WebSocket enabled
8. **Weekly Reports** - Automated (Sunday 9 AM)

### 🎨 Demo Mode:
- No login required
- Mock data used
- All features accessible

## 🎉 You're All Set!

Open your browser and go to:
**http://localhost:8080/index.html**

Enjoy the FRA Atlas & DSS! 🚀
