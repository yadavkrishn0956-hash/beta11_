# 🧪 Testing New Claim Form

## How to Test

### 1. Open the Application
Navigate to: **http://localhost:3000/index.html**

### 2. Go to Map Page
- Click on "Map" in the navigation menu
- Wait for map to load

### 3. Draw a Claim
1. Click the **"Draw Claim"** button (green button with pencil icon)
2. Click on the map to create polygon points
3. Complete the polygon by clicking on the first point again

### 4. Verify Auto-Fill
The form should open automatically with these fields **pre-filled**:

✅ **Area (Hectares)** - Calculated from polygon
✅ **Latitude** - Center of polygon
✅ **Longitude** - Center of polygon
✅ **State** - From reverse geocoding (or "Madhya Pradesh" as fallback)
✅ **District** - From reverse geocoding (or "Balaghat" as fallback)

### 5. Complete the Form
Fill in the remaining fields:
- **Claimant Name**: Enter any name (e.g., "Test User")
- **Claim Type**: Select IFR, CFR, or CR
- **Village**: Select from dropdown
- **Linked Scheme**: Optional
- **Additional Notes**: Optional

### 6. Submit the Claim
Click **"Submit Claim"** button

### 7. Verify Claim Appears

#### On Map:
- Yellow polygon should appear
- Click polygon to see popup with claim details

#### In Claims Page:
- Navigate to "Claims" page
- New claim should appear at top of table
- Should show all details including State, District, Lat/Lng

#### In Review Section:
- Navigate to "Review" page (if available)
- New claim should appear in review table
- Status should be "Pending"
- Should show all location details

## Expected Results

### Form Display:
- ✅ Modal is fully visible (not cut off)
- ✅ All fields are accessible
- ✅ Scroll works if needed
- ✅ Form is centered on screen

### Auto-Fill:
- ✅ Area shows calculated value
- ✅ Latitude shows decimal number (e.g., 21.234567)
- ✅ Longitude shows decimal number (e.g., 80.123456)
- ✅ State shows text (e.g., "Madhya Pradesh")
- ✅ District shows text (e.g., "Balaghat")

### Submission:
- ✅ Success toast message appears
- ✅ Form closes automatically
- ✅ Polygon turns yellow on map
- ✅ Claim ID is generated (e.g., "FRA-1730826000000")

### Data Persistence:
- ✅ Claim appears in Claims table
- ✅ Claim appears in Review table
- ✅ All fields are populated correctly
- ✅ Latitude/Longitude are visible in review details

## Troubleshooting

### Form is cut off:
- Check browser zoom (should be 100%)
- Try different screen size
- Check console for CSS errors

### Auto-fill not working:
- Check browser console for errors
- Verify polygon was drawn successfully
- Check network tab for geocoding API call

### Claim not appearing:
- Check console for submission errors
- Verify you're on the correct page
- Try refreshing the page

### Geocoding fails:
- Should fallback to default values
- Check internet connection
- Nominatim API might be rate-limited

## Console Commands for Testing

Open browser console (F12) and run:

```javascript
// Check if DrawClaimManager is initialized
console.log(window.drawClaimManager);

// Check claims database
console.log(claimsDatabase);

// Check review database
console.log(reviewDatabase);

// Check last drawn polygon
console.log(window.drawClaimManager?.drawnLayer);

// Check calculated area
console.log(window.drawClaimManager?.calculatedArea);
```

## Sample Test Data

### Test Polygon Coordinates (Madhya Pradesh):
```
Point 1: 21.8, 80.2
Point 2: 21.8, 80.3
Point 3: 21.9, 80.3
Point 4: 21.9, 80.2
```

### Expected Auto-Fill Values:
- **Area**: ~1200 hectares (approximate)
- **Latitude**: ~21.85
- **Longitude**: ~80.25
- **State**: Madhya Pradesh
- **District**: Balaghat (or nearby district)

## Known Issues

1. **Reverse Geocoding Delay**: May take 1-2 seconds
2. **Nominatim Rate Limit**: Max 1 request per second
3. **Fallback Values**: Used if geocoding fails
4. **Village Dropdown**: May be empty if API not configured

## Success Criteria

- [x] Form displays completely
- [x] All new fields are visible
- [x] Auto-fill works for Area, Lat, Lng
- [x] Auto-fill works for State, District (or fallback)
- [x] Form validation works
- [x] Submission succeeds
- [x] Claim appears on map
- [x] Claim appears in Claims page
- [x] Claim appears in Review section
- [x] No console errors

---

**Test Status**: Ready for Testing
**Last Updated**: November 5, 2025
