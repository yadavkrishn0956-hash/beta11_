#!/bin/bash

# FRA Atlas AI Microservice Startup Script

echo "🤖 Starting FRA Atlas AI Microservice..."
echo "================================================"

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

# Check Python version
PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
REQUIRED_VERSION="3.8"

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    echo "❌ Python version $PYTHON_VERSION is not supported. Please install Python 3.8 or higher."
    exit 1
fi

echo "✅ Python version: $PYTHON_VERSION"

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "❌ Failed to create virtual environment."
        exit 1
    fi
    echo "✅ Virtual environment created."
fi

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Check if requirements.txt exists
if [ ! -f "requirements.txt" ]; then
    echo "❌ requirements.txt not found. Please ensure it exists in the ai_service directory."
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies."
    exit 1
fi
echo "✅ Dependencies installed successfully."

# Create necessary directories
mkdir -p model/trained_models
mkdir -p logs
mkdir -p data

# Check if main.py exists
if [ ! -f "main.py" ]; then
    echo "❌ main.py not found. Please ensure it exists in the ai_service directory."
    exit 1
fi

# Set environment variables
export PYTHONPATH="${PYTHONPATH}:$(pwd)"

# Start the AI service
echo ""
echo "🚀 Starting FRA Atlas AI Microservice..."
echo "   - AI API will be available at: http://localhost:8000"
echo "   - API documentation: http://localhost:8000/docs"
echo "   - Health check: http://localhost:8000/health"
echo ""
echo "🧠 AI Models:"
echo "   - Rules Engine: Active"
echo "   - ML Recommender: Training on startup"
echo "   - Claim Verifier: Active"
echo ""
echo "Press Ctrl+C to stop the AI service"
echo "================================================"

# Check if we should run in development mode
if [ "$1" = "dev" ] || [ "$NODE_ENV" = "development" ]; then
    echo "🔄 Running in development mode with auto-reload..."
    uvicorn main:app --reload --host 0.0.0.0 --port 8000 --log-level info
else
    echo "🚀 Running in production mode..."
    uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4 --log-level info
fi