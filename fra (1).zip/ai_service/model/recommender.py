"""
ML-based scheme recommender using scikit-learn
"""

import logging
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import joblib
import os
from typing import Dict, List, Any, Tuple

logger = logging.getLogger(__name__)

class SchemeRecommender:
    """
    Machine Learning based scheme recommender
    """
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.scheme_encoder = LabelEncoder()
        self.feature_columns = ['land_area', 'forest_cover', 'water_index', 'soil_quality_encoded', 'tribal_area', 'employment_needed']
        self._ready = False
        
        # Initialize with sample data and train model
        self._initialize_model()
    
    def _initialize_model(self):
        """Initialize and train the ML model with sample data"""
        try:
            # Check if pre-trained model exists
            model_path = "model/trained_model.pkl"
            if os.path.exists(model_path):
                self._load_model(model_path)
            else:
                # Generate sample training data and train model
                self._train_model_with_sample_data()
            
            self._ready = True
            logger.info("ML Recommender initialized successfully")
            
        except Exception as e:
            logger.error(f"Error initializing ML model: {str(e)}")
            self._ready = False
    
    def _generate_sample_data(self) -> pd.DataFrame:
        """Generate sample training data for the model"""
        np.random.seed(42)
        n_samples = 1000
        
        # Generate features
        data = {
            'land_area': np.random.exponential(2, n_samples),  # Most farmers have small land
            'forest_cover': np.random.beta(2, 3, n_samples) * 100,  # Forest cover 0-100%
            'water_index': np.random.beta(2, 2, n_samples),  # Water index 0-1
            'soil_quality': np.random.choice(['good', 'degraded', 'poor'], n_samples, p=[0.4, 0.4, 0.2]),
            'tribal_area': np.random.choice([True, False], n_samples, p=[0.7, 0.3]),
            'employment_needed': np.random.choice([True, False], n_samples, p=[0.6, 0.4])
        }
        
        df = pd.DataFrame(data)
        
        # Generate target schemes based on rules
        schemes = []
        for _, row in df.iterrows():
            eligible_schemes = []
            
            # Rule-based scheme assignment
            if row['land_area'] <= 3.0:
                eligible_schemes.append('PM-KISAN')
            
            if row['water_index'] <= 0.4:
                eligible_schemes.append('Jal Jeevan Mission')
            
            if row['soil_quality'] in ['degraded', 'poor']:
                eligible_schemes.append('MGNREGA')
            
            if row['forest_cover'] >= 60:
                eligible_schemes.append('Green India Mission')
            
            if row['tribal_area']:
                eligible_schemes.append('DAJGUA')
            
            if row['employment_needed']:
                eligible_schemes.append('MGNREGA')
            
            # Select primary scheme (most relevant)
            if eligible_schemes:
                primary_scheme = eligible_schemes[0]  # Take first eligible scheme
            else:
                primary_scheme = 'General Support'
            
            schemes.append(primary_scheme)
        
        df['primary_scheme'] = schemes
        return df
    
    def _train_model_with_sample_data(self):
        """Train the ML model with generated sample data"""
        try:
            # Generate sample data
            df = self._generate_sample_data()
            
            # Prepare features
            X = self._prepare_features(df)
            
            # Prepare target
            y = self.scheme_encoder.fit_transform(df['primary_scheme'])
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Scale features
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Train model
            self.model = RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=42,
                class_weight='balanced'
            )
            
            self.model.fit(X_train_scaled, y_train)
            
            # Evaluate model
            y_pred = self.model.predict(X_test_scaled)
            accuracy = accuracy_score(y_test, y_pred)
            
            logger.info(f"Model trained successfully with accuracy: {accuracy:.3f}")
            
            # Save model
            self._save_model("model/trained_model.pkl")
            
        except Exception as e:
            logger.error(f"Error training model: {str(e)}")
            raise
    
    def _prepare_features(self, df: pd.DataFrame) -> np.ndarray:
        """Prepare features for ML model"""
        # Encode categorical variables
        if 'soil_quality' in df.columns:
            if 'soil_quality' not in self.label_encoders:
                self.label_encoders['soil_quality'] = LabelEncoder()
                df['soil_quality_encoded'] = self.label_encoders['soil_quality'].fit_transform(df['soil_quality'])
            else:
                df['soil_quality_encoded'] = self.label_encoders['soil_quality'].transform(df['soil_quality'])
        
        # Convert boolean to int
        df['tribal_area'] = df['tribal_area'].astype(int)
        df['employment_needed'] = df['employment_needed'].astype(int)
        
        # Select feature columns
        X = df[self.feature_columns].values
        return X
    
    def predict_schemes(self, claim_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Predict schemes using ML model"""
        try:
            if not self._ready or self.model is None:
                logger.warning("ML model not ready, returning empty predictions")
                return []
            
            # Convert claim data to DataFrame
            df = pd.DataFrame([claim_data])
            
            # Handle missing soil_quality
            if 'soil_quality' not in df.columns:
                df['soil_quality'] = 'good'
            
            # Prepare features
            X = self._prepare_features(df)
            X_scaled = self.scaler.transform(X)
            
            # Get predictions and probabilities
            predictions = self.model.predict(X_scaled)
            probabilities = self.model.predict_proba(X_scaled)
            
            # Get top predictions
            top_indices = np.argsort(probabilities[0])[::-1][:3]  # Top 3 predictions
            
            recommendations = []
            scheme_names = self.scheme_encoder.classes_
            
            for idx in top_indices:
                if probabilities[0][idx] > 0.1:  # Only include if probability > 10%
                    scheme_name = scheme_names[idx]
                    confidence = probabilities[0][idx]
                    
                    recommendations.append({
                        "scheme_name": scheme_name,
                        "scheme_code": scheme_name.replace(" ", "_").replace("-", "_").upper(),
                        "description": f"ML-recommended scheme: {scheme_name}",
                        "eligibility_score": confidence * 100,
                        "priority": "high" if confidence > 0.7 else "medium" if confidence > 0.4 else "low",
                        "benefits": "As per scheme guidelines",
                        "ministry": "Various Ministries",
                        "application_process": "Through designated channels",
                        "estimated_benefit": "Variable",
                        "confidence": confidence
                    })
            
            logger.info(f"Generated {len(recommendations)} ML-based recommendations")
            return recommendations
            
        except Exception as e:
            logger.error(f"Error in ML prediction: {str(e)}")
            return []
    
    def combine_recommendations(self, rules_recs: List[Dict], ml_recs: List[Dict], claim_data: Dict) -> List[Dict]:
        """Combine rule-based and ML recommendations"""
        try:
            # Create a combined list
            all_recommendations = []
            
            # Add rule-based recommendations with higher weight
            for rec in rules_recs:
                rec['source'] = 'rules'
                rec['combined_score'] = rec['confidence'] * 0.7  # 70% weight for rules
                all_recommendations.append(rec)
            
            # Add ML recommendations with lower weight
            for rec in ml_recs:
                rec['source'] = 'ml'
                rec['combined_score'] = rec['confidence'] * 0.3  # 30% weight for ML
                
                # Check if scheme already exists from rules
                existing = next((r for r in all_recommendations if r['scheme_code'] == rec['scheme_code']), None)
                if existing:
                    # Boost confidence if both methods agree
                    existing['combined_score'] += rec['combined_score']
                    existing['confidence'] = min(1.0, existing['confidence'] + rec['confidence'] * 0.2)
                    existing['source'] = 'hybrid'
                else:
                    all_recommendations.append(rec)
            
            # Sort by combined score
            sorted_recs = sorted(all_recommendations, key=lambda x: x['combined_score'], reverse=True)
            
            # Update eligibility scores based on combined scoring
            for rec in sorted_recs:
                rec['eligibility_score'] = min(100, rec['combined_score'] * 100)
            
            logger.info(f"Combined {len(rules_recs)} rule-based and {len(ml_recs)} ML recommendations into {len(sorted_recs)} final recommendations")
            
            return sorted_recs[:5]  # Return top 5
            
        except Exception as e:
            logger.error(f"Error combining recommendations: {str(e)}")
            return rules_recs  # Fallback to rules-based only
    
    def _save_model(self, filepath: str):
        """Save trained model to file"""
        try:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            model_data = {
                'model': self.model,
                'scaler': self.scaler,
                'label_encoders': self.label_encoders,
                'scheme_encoder': self.scheme_encoder,
                'feature_columns': self.feature_columns
            }
            
            joblib.dump(model_data, filepath)
            logger.info(f"Model saved to {filepath}")
            
        except Exception as e:
            logger.error(f"Error saving model: {str(e)}")
    
    def _load_model(self, filepath: str):
        """Load trained model from file"""
        try:
            model_data = joblib.load(filepath)
            
            self.model = model_data['model']
            self.scaler = model_data['scaler']
            self.label_encoders = model_data['label_encoders']
            self.scheme_encoder = model_data['scheme_encoder']
            self.feature_columns = model_data['feature_columns']
            
            logger.info(f"Model loaded from {filepath}")
            
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            raise
    
    def retrain_model(self, new_data: pd.DataFrame):
        """Retrain model with new data"""
        try:
            # Prepare features and target
            X = self._prepare_features(new_data)
            y = self.scheme_encoder.fit_transform(new_data['primary_scheme'])
            
            # Scale features
            X_scaled = self.scaler.fit_transform(X)
            
            # Retrain model
            self.model.fit(X_scaled, y)
            
            # Save updated model
            self._save_model("model/trained_model.pkl")
            
            logger.info("Model retrained successfully")
            
        except Exception as e:
            logger.error(f"Error retraining model: {str(e)}")
            raise
    
    def get_feature_importance(self) -> Dict[str, float]:
        """Get feature importance from the trained model"""
        if self.model is None:
            return {}
        
        importance = self.model.feature_importances_
        return dict(zip(self.feature_columns, importance))
    
    def is_ready(self) -> bool:
        """Check if ML recommender is ready"""
        return self._ready and self.model is not None