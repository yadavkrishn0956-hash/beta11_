"""
AI-powered claim verification system
"""

import logging
import numpy as np
from typing import Dict, List, Any
import re

logger = logging.getLogger(__name__)

class ClaimVerifier:
    """
    AI-powered claim verification system
    """
    
    def __init__(self):
        self.verification_rules = self._initialize_verification_rules()
        self._ready = True
        logger.info("Claim Verifier initialized successfully")
    
    def _initialize_verification_rules(self) -> Dict[str, Any]:
        """Initialize verification rules and thresholds"""
        return {
            "land_area": {
                "min_area": 0.1,
                "max_area": 100.0,
                "typical_range": (0.5, 10.0)
            },
            "forest_cover": {
                "min_cover": 0.0,
                "max_cover": 100.0,
                "high_threshold": 80.0
            },
            "coordinates": {
                "india_bounds": {
                    "lat_min": 6.0,
                    "lat_max": 37.0,
                    "lon_min": 68.0,
                    "lon_max": 98.0
                }
            },
            "name_patterns": {
                "min_length": 2,
                "max_length": 100,
                "invalid_chars": r'[^a-zA-Z\s\.]'
            }
        }
    
    def verify_claim(self, claim_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Comprehensive claim verification
        """
        try:
            verification_result = {
                "claim_id": claim_data.get("claim_id", ""),
                "verification_status": "pending",
                "confidence": 0.0,
                "issues_found": [],
                "recommendations": []
            }
            
            issues = []
            confidence_scores = []
            
            # Verify applicant name
            name_score, name_issues = self._verify_applicant_name(claim_data.get("applicant_name", ""))
            confidence_scores.append(name_score)
            issues.extend(name_issues)
            
            # Verify land area
            area_score, area_issues = self._verify_land_area(claim_data.get("land_area", 0))
            confidence_scores.append(area_score)
            issues.extend(area_issues)
            
            # Verify forest cover
            forest_score, forest_issues = self._verify_forest_cover(claim_data.get("forest_cover", 0))
            confidence_scores.append(forest_score)
            issues.extend(forest_issues)
            
            # Verify coordinates if provided
            if claim_data.get("coordinates"):
                coord_score, coord_issues = self._verify_coordinates(claim_data["coordinates"])
                confidence_scores.append(coord_score)
                issues.extend(coord_issues)
            
            # Verify documents if provided
            if claim_data.get("documents"):
                doc_score, doc_issues = self._verify_documents(claim_data["documents"])
                confidence_scores.append(doc_score)
                issues.extend(doc_issues)
            
            # Calculate overall confidence
            overall_confidence = np.mean(confidence_scores) if confidence_scores else 0.0
            
            # Determine verification status
            if overall_confidence >= 0.8:
                status = "verified"
            elif overall_confidence >= 0.6:
                status = "needs_review"
            else:
                status = "rejected"
            
            # Generate recommendations
            recommendations = self._generate_verification_recommendations(issues, overall_confidence)
            
            verification_result.update({
                "verification_status": status,
                "confidence": round(overall_confidence, 3),
                "issues_found": issues,
                "recommendations": recommendations
            })
            
            logger.info(f"Claim {claim_data.get('claim_id')} verified with status: {status}")
            return verification_result
            
        except Exception as e:
            logger.error(f"Error in claim verification: {str(e)}")
            return {
                "claim_id": claim_data.get("claim_id", ""),
                "verification_status": "error",
                "confidence": 0.0,
                "issues_found": [f"Verification error: {str(e)}"],
                "recommendations": ["Please resubmit the claim with correct information"]
            }
    
    def _verify_applicant_name(self, name: str) -> tuple[float, List[str]]:
        """Verify applicant name"""
        issues = []
        score = 1.0
        
        if not name or len(name.strip()) == 0:
            issues.append("Applicant name is missing")
            return 0.0, issues
        
        name = name.strip()
        
        # Check length
        if len(name) < self.verification_rules["name_patterns"]["min_length"]:
            issues.append("Applicant name is too short")
            score -= 0.3
        
        if len(name) > self.verification_rules["name_patterns"]["max_length"]:
            issues.append("Applicant name is too long")
            score -= 0.2
        
        # Check for invalid characters
        invalid_chars = re.search(self.verification_rules["name_patterns"]["invalid_chars"], name)
        if invalid_chars:
            issues.append("Applicant name contains invalid characters")
            score -= 0.3
        
        # Check for reasonable name pattern
        if not re.match(r'^[A-Za-z\s\.]+$', name):
            issues.append("Applicant name format appears invalid")
            score -= 0.2
        
        return max(0.0, score), issues
    
    def _verify_land_area(self, land_area: float) -> tuple[float, List[str]]:
        """Verify land area"""
        issues = []
        score = 1.0
        
        rules = self.verification_rules["land_area"]
        
        # Check if area is within valid range
        if land_area < rules["min_area"]:
            issues.append(f"Land area ({land_area} ha) is below minimum threshold")
            score -= 0.5
        
        if land_area > rules["max_area"]:
            issues.append(f"Land area ({land_area} ha) exceeds maximum threshold")
            score -= 0.3
        
        # Check if area is within typical range
        if not (rules["typical_range"][0] <= land_area <= rules["typical_range"][1]):
            if land_area < rules["typical_range"][0]:
                issues.append("Land area is unusually small - requires additional verification")
                score -= 0.2
            else:
                issues.append("Land area is unusually large - requires additional verification")
                score -= 0.2
        
        return max(0.0, score), issues
    
    def _verify_forest_cover(self, forest_cover: float) -> tuple[float, List[str]]:
        """Verify forest cover percentage"""
        issues = []
        score = 1.0
        
        rules = self.verification_rules["forest_cover"]
        
        # Check if forest cover is within valid range
        if forest_cover < rules["min_cover"] or forest_cover > rules["max_cover"]:
            issues.append(f"Forest cover ({forest_cover}%) is outside valid range (0-100%)")
            score -= 0.4
        
        # Check for unusually high forest cover
        if forest_cover > rules["high_threshold"]:
            issues.append("Very high forest cover - requires satellite verification")
            score -= 0.1
        
        return max(0.0, score), issues
    
    def _verify_coordinates(self, coordinates: Dict[str, float]) -> tuple[float, List[str]]:
        """Verify geographical coordinates"""
        issues = []
        score = 1.0
        
        lat = coordinates.get("latitude")
        lon = coordinates.get("longitude")
        
        if lat is None or lon is None:
            issues.append("Incomplete coordinate information")
            return 0.5, issues
        
        bounds = self.verification_rules["coordinates"]["india_bounds"]
        
        # Check if coordinates are within India
        if not (bounds["lat_min"] <= lat <= bounds["lat_max"]):
            issues.append(f"Latitude ({lat}) is outside India's boundaries")
            score -= 0.5
        
        if not (bounds["lon_min"] <= lon <= bounds["lon_max"]):
            issues.append(f"Longitude ({lon}) is outside India's boundaries")
            score -= 0.5
        
        # Check for precision (coordinates should not be too precise for manual entry)
        if len(str(lat).split('.')[-1]) > 6 or len(str(lon).split('.')[-1]) > 6:
            issues.append("Coordinates appear artificially precise - possible data entry error")
            score -= 0.1
        
        return max(0.0, score), issues
    
    def _verify_documents(self, documents: List[str]) -> tuple[float, List[str]]:
        """Verify document list"""
        issues = []
        score = 1.0
        
        if not documents or len(documents) == 0:
            issues.append("No supporting documents provided")
            return 0.3, issues
        
        # Check for required document types
        required_docs = ["land_record", "identity_proof", "address_proof"]
        provided_doc_types = [doc.lower() for doc in documents]
        
        missing_docs = []
        for req_doc in required_docs:
            if not any(req_doc in doc_type for doc_type in provided_doc_types):
                missing_docs.append(req_doc.replace("_", " ").title())
        
        if missing_docs:
            issues.append(f"Missing required documents: {', '.join(missing_docs)}")
            score -= 0.3 * len(missing_docs)
        
        return max(0.0, score), issues
    
    def _generate_verification_recommendations(self, issues: List[str], confidence: float) -> List[str]:
        """Generate recommendations based on verification results"""
        recommendations = []
        
        if confidence >= 0.8:
            recommendations.append("Claim appears valid - proceed with approval process")
        elif confidence >= 0.6:
            recommendations.append("Claim requires manual review before approval")
            recommendations.append("Conduct field verification if necessary")
        else:
            recommendations.append("Claim has significant issues - consider rejection or request resubmission")
        
        # Specific recommendations based on issues
        if any("name" in issue.lower() for issue in issues):
            recommendations.append("Verify applicant identity with additional documents")
        
        if any("land area" in issue.lower() for issue in issues):
            recommendations.append("Cross-check land area with revenue records")
        
        if any("forest cover" in issue.lower() for issue in issues):
            recommendations.append("Verify forest cover using satellite imagery")
        
        if any("coordinate" in issue.lower() for issue in issues):
            recommendations.append("Validate geographical coordinates with GPS survey")
        
        if any("document" in issue.lower() for issue in issues):
            recommendations.append("Request missing or additional supporting documents")
        
        return recommendations
    
    def batch_verify_claims(self, claims: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Verify multiple claims in batch"""
        results = []
        
        for claim in claims:
            try:
                result = self.verify_claim(claim)
                results.append(result)
            except Exception as e:
                logger.error(f"Error verifying claim {claim.get('claim_id', 'unknown')}: {str(e)}")
                results.append({
                    "claim_id": claim.get("claim_id", ""),
                    "verification_status": "error",
                    "confidence": 0.0,
                    "issues_found": [f"Verification error: {str(e)}"],
                    "recommendations": ["Please resubmit the claim"]
                })
        
        return results
    
    def get_verification_statistics(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get statistics from verification results"""
        if not results:
            return {}
        
        total_claims = len(results)
        verified = len([r for r in results if r["verification_status"] == "verified"])
        needs_review = len([r for r in results if r["verification_status"] == "needs_review"])
        rejected = len([r for r in results if r["verification_status"] == "rejected"])
        errors = len([r for r in results if r["verification_status"] == "error"])
        
        avg_confidence = np.mean([r["confidence"] for r in results if r["confidence"] > 0])
        
        return {
            "total_claims": total_claims,
            "verified": verified,
            "needs_review": needs_review,
            "rejected": rejected,
            "errors": errors,
            "verification_rate": (verified / total_claims) * 100 if total_claims > 0 else 0,
            "average_confidence": round(avg_confidence, 3) if not np.isnan(avg_confidence) else 0.0
        }
    
    def is_ready(self) -> bool:
        """Check if claim verifier is ready"""
        return self._ready