"""
Rules-based recommendation engine for FRA scheme recommendations
"""

import logging
from typing import Dict, List, Any
from datetime import datetime

logger = logging.getLogger(__name__)

class RulesEngine:
    """
    Rule-based engine for scheme recommendations based on FRA claim data
    """
    
    def __init__(self):
        self.rules = self._initialize_rules()
        self.schemes_db = self._initialize_schemes_database()
        self._ready = True
        logger.info("Rules Engine initialized successfully")
    
    def _initialize_rules(self) -> Dict[str, Any]:
        """Initialize the rules for scheme recommendations"""
        return {
            "land_area_rules": {
                "small_farmer": {"max_area": 3.0, "schemes": ["PM-KISAN"]},
                "marginal_farmer": {"max_area": 1.0, "schemes": ["PM-KISAN", "PMAY-G"]},
                "large_farmer": {"min_area": 5.0, "schemes": ["Crop Insurance"]}
            },
            "water_rules": {
                "water_scarce": {"max_index": 0.3, "schemes": ["Jal Jeevan Mission", "Watershed Development"]},
                "moderate_water": {"min_index": 0.3, "max_index": 0.7, "schemes": ["Micro Irrigation"]},
                "water_abundant": {"min_index": 0.7, "schemes": ["Fisheries Development"]}
            },
            "soil_rules": {
                "poor": {"schemes": ["MGNREGA", "Soil Health Card", "Organic Farming"]},
                "degraded": {"schemes": ["MGNREGA", "Land Reclamation", "Watershed Development"]},
                "good": {"schemes": ["Crop Diversification", "Organic Certification"]}
            },
            "forest_rules": {
                "high_forest": {"min_cover": 70, "schemes": ["Green India Mission", "Forest Conservation"]},
                "moderate_forest": {"min_cover": 40, "max_cover": 70, "schemes": ["Agroforestry", "NTFP Development"]},
                "low_forest": {"max_cover": 40, "schemes": ["Afforestation", "Tree Plantation"]}
            },
            "tribal_rules": {
                "tribal_area": {"schemes": ["DAJGUA", "Tribal Development", "Skill Development"]},
                "employment_needed": {"schemes": ["MGNREGA", "Skill Development", "SHG Formation"]},
                "housing_needed": {"schemes": ["PMAY-G", "IAY", "Tribal Housing"]}
            }
        }
    
    def _initialize_schemes_database(self) -> Dict[str, Dict]:
        """Initialize comprehensive schemes database"""
        return {
            "PM-KISAN": {
                "name": "Pradhan Mantri Kisan Samman Nidhi",
                "code": "PM_KISAN",
                "description": "Income support to farmers",
                "ministry": "Ministry of Agriculture and Farmers Welfare",
                "benefits": "Rs. 6,000 per year in three installments",
                "eligibility": {"land_area": {"max": 3.0}},
                "priority": "high",
                "application_process": "Online through PM-KISAN portal",
                "estimated_benefit": "Rs. 6,000/year"
            },
            "Jal Jeevan Mission": {
                "name": "Jal Jeevan Mission",
                "code": "JJM",
                "description": "Providing tap water connection to every household",
                "ministry": "Ministry of Jal Shakti",
                "benefits": "Functional household tap connection",
                "eligibility": {"water_index": {"max": 0.5}},
                "priority": "high",
                "application_process": "Through Gram Panchayat",
                "estimated_benefit": "Tap water connection"
            },
            "MGNREGA": {
                "name": "Mahatma Gandhi National Rural Employment Guarantee Act",
                "code": "MGNREGA",
                "description": "Employment guarantee scheme",
                "ministry": "Ministry of Rural Development",
                "benefits": "100 days guaranteed employment",
                "eligibility": {"employment_needed": True},
                "priority": "medium",
                "application_process": "Job card registration at Gram Panchayat",
                "estimated_benefit": "Rs. 200-300/day for 100 days"
            },
            "Green India Mission": {
                "name": "National Mission for a Green India",
                "code": "GIM",
                "description": "Forest conservation and enhancement",
                "ministry": "Ministry of Environment, Forest and Climate Change",
                "benefits": "Forest conservation support and livelihood",
                "eligibility": {"forest_cover": {"min": 70}},
                "priority": "medium",
                "application_process": "Through Forest Department",
                "estimated_benefit": "Conservation incentives"
            },
            "DAJGUA": {
                "name": "Development Action Plan for Scheduled Tribes",
                "code": "DAJGUA",
                "description": "Comprehensive tribal development",
                "ministry": "Ministry of Tribal Affairs",
                "benefits": "Multi-sectoral development support",
                "eligibility": {"tribal_area": True},
                "priority": "high",
                "application_process": "Through Tribal Development Office",
                "estimated_benefit": "Comprehensive support"
            },
            "PMAY-G": {
                "name": "Pradhan Mantri Awas Yojana - Gramin",
                "code": "PMAY_G",
                "description": "Rural housing scheme",
                "ministry": "Ministry of Rural Development",
                "benefits": "Financial assistance for house construction",
                "eligibility": {"housing_needed": True},
                "priority": "medium",
                "application_process": "Through Gram Panchayat",
                "estimated_benefit": "Rs. 1.2-1.3 lakh"
            }
        }
    
    def recommend_schemes(self, claim_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Generate scheme recommendations based on rules
        """
        try:
            recommendations = []
            
            # Extract claim data
            land_area = claim_data.get("land_area", 0)
            forest_cover = claim_data.get("forest_cover", 0)
            water_index = claim_data.get("water_index", 0.5)
            soil_quality = claim_data.get("soil_quality", "good").lower()
            tribal_area = claim_data.get("tribal_area", True)
            employment_needed = claim_data.get("employment_needed", False)
            housing_needed = claim_data.get("housing_needed", False)
            
            # Apply land area rules
            if land_area <= 3.0:
                recommendations.extend(self._create_recommendations(["PM-KISAN"], 0.9))
            
            if land_area <= 1.0:
                recommendations.extend(self._create_recommendations(["PMAY-G"], 0.8))
            
            # Apply water rules
            if water_index <= 0.3:
                recommendations.extend(self._create_recommendations(["Jal Jeevan Mission"], 0.95))
            elif water_index <= 0.7:
                recommendations.extend(self._create_recommendations(["Micro Irrigation"], 0.7))
            
            # Apply soil quality rules
            if soil_quality in ["poor", "degraded"]:
                recommendations.extend(self._create_recommendations(["MGNREGA"], 0.85))
            
            # Apply forest cover rules
            if forest_cover >= 70:
                recommendations.extend(self._create_recommendations(["Green India Mission"], 0.8))
            
            # Apply tribal area rules
            if tribal_area:
                recommendations.extend(self._create_recommendations(["DAJGUA"], 0.9))
            
            # Apply employment rules
            if employment_needed:
                recommendations.extend(self._create_recommendations(["MGNREGA"], 0.85))
            
            # Apply housing rules
            if housing_needed:
                recommendations.extend(self._create_recommendations(["PMAY-G"], 0.8))
            
            # Remove duplicates and sort by confidence
            unique_recommendations = self._remove_duplicates(recommendations)
            sorted_recommendations = sorted(unique_recommendations, key=lambda x: x["confidence"], reverse=True)
            
            logger.info(f"Generated {len(sorted_recommendations)} rule-based recommendations")
            return sorted_recommendations[:5]  # Return top 5 recommendations
            
        except Exception as e:
            logger.error(f"Error in rules engine: {str(e)}")
            return []
    
    def _create_recommendations(self, scheme_codes: List[str], base_confidence: float) -> List[Dict[str, Any]]:
        """Create recommendation objects from scheme codes"""
        recommendations = []
        
        for code in scheme_codes:
            if code in self.schemes_db:
                scheme = self.schemes_db[code]
                recommendations.append({
                    "scheme_name": scheme["name"],
                    "scheme_code": scheme["code"],
                    "description": scheme["description"],
                    "eligibility_score": base_confidence * 100,
                    "priority": scheme["priority"],
                    "benefits": scheme["benefits"],
                    "ministry": scheme["ministry"],
                    "application_process": scheme["application_process"],
                    "estimated_benefit": scheme["estimated_benefit"],
                    "confidence": base_confidence
                })
        
        return recommendations
    
    def _remove_duplicates(self, recommendations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove duplicate recommendations and keep the one with highest confidence"""
        seen_schemes = {}
        
        for rec in recommendations:
            scheme_code = rec["scheme_code"]
            if scheme_code not in seen_schemes or rec["confidence"] > seen_schemes[scheme_code]["confidence"]:
                seen_schemes[scheme_code] = rec
        
        return list(seen_schemes.values())
    
    def generate_insights(self, claim_data: Dict[str, Any], recommendations: List[Dict[str, Any]]) -> List[str]:
        """Generate AI insights based on claim data and recommendations"""
        insights = []
        
        land_area = claim_data.get("land_area", 0)
        forest_cover = claim_data.get("forest_cover", 0)
        water_index = claim_data.get("water_index", 0.5)
        soil_quality = claim_data.get("soil_quality", "good").lower()
        
        # Land area insights
        if land_area <= 1.0:
            insights.append("🏠 Small landholding detected - prioritizing income support and housing schemes")
        elif land_area <= 3.0:
            insights.append("🌾 Marginal farmer category - eligible for direct benefit transfer schemes")
        
        # Water insights
        if water_index <= 0.3:
            insights.append("💧 Water scarcity identified - water security schemes highly recommended")
        
        # Soil insights
        if soil_quality in ["poor", "degraded"]:
            insights.append("🌱 Soil improvement needed - employment generation through land development recommended")
        
        # Forest insights
        if forest_cover >= 70:
            insights.append("🌳 High forest cover - conservation and sustainable livelihood opportunities available")
        
        # Recommendation insights
        if len(recommendations) >= 3:
            insights.append("✅ Multiple scheme eligibility - consider integrated development approach")
        
        return insights
    
    def generate_next_steps(self, claim_data: Dict[str, Any], recommendations: List[Dict[str, Any]]) -> List[str]:
        """Generate actionable next steps"""
        steps = [
            "📋 Review all eligible schemes and their specific requirements",
            "📄 Gather required documents (Aadhaar, land records, bank details)",
            "🏛️ Visit nearest Common Service Center or Gram Panchayat",
            "📱 Download relevant mobile apps for scheme applications",
            "📞 Contact scheme helplines for detailed guidance"
        ]
        
        # Add specific steps based on recommendations
        if any(rec["scheme_code"] == "PM_KISAN" for rec in recommendations):
            steps.append("🌾 For PM-KISAN: Ensure land records are updated and linked to Aadhaar")
        
        if any(rec["scheme_code"] == "JJM" for rec in recommendations):
            steps.append("💧 For Jal Jeevan Mission: Contact Village Water and Sanitation Committee")
        
        return steps
    
    def get_rules_count(self) -> int:
        """Get total number of rules in the engine"""
        total_rules = 0
        for category in self.rules.values():
            if isinstance(category, dict):
                total_rules += len(category)
        return total_rules
    
    def is_ready(self) -> bool:
        """Check if rules engine is ready"""
        return self._ready