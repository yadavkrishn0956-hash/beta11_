#!/bin/bash

echo "🛑 Stopping FRA Atlas & DSS System..."

# Kill processes using PID files
if [ -f "logs/backend.pid" ]; then
    BACKEND_PID=$(cat logs/backend.pid)
    if kill -0 $BACKEND_PID 2>/dev/null; then
        kill $BACKEND_PID
        echo "✅ Backend API Server stopped"
    fi
    rm logs/backend.pid
fi

if [ -f "logs/ai_service.pid" ]; then
    AI_PID=$(cat logs/ai_service.pid)
    if kill -0 $AI_PID 2>/dev/null; then
        kill $AI_PID
        echo "✅ AI Microservice stopped"
    fi
    rm logs/ai_service.pid
fi

# Fallback: kill by port
pkill -f "uvicorn main:app" 2>/dev/null
pkill -f "node app.js" 2>/dev/null

echo "🎉 All services stopped successfully!"
