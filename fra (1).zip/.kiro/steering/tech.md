# Technology Stack

## Core Technologies
- **Kiro AI Assistant**: Primary development environment with AI-powered code assistance
- **Model Context Protocol (MCP)**: Server integration for enhanced tooling capabilities
- **VSCode**: Code editor with Kiro integration

## Configuration
- **MCP Configuration**: Managed through `.kiro/settings/mcp.json`
- **VSCode Settings**: Project-specific settings in `.vscode/settings.json`
- **Kiro Settings**: AI assistant configuration in `.kiro/` directory

## Common Commands
Since this is primarily a Kiro workspace, most operations are handled through the AI assistant interface. Key interactions include:

- Use `#File` or `#Folder` to reference specific files/folders in chat
- MCP servers can be managed through Kiro's MCP Server view
- Configuration changes auto-reconnect MCP servers
- Use command palette to search for 'MCP' related commands

## Development Workflow
- Primary development through Kiro AI assistant
- MCP servers provide additional tooling capabilities
- VSCode integration for enhanced editing experience