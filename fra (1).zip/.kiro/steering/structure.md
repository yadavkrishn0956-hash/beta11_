# Project Structure

## Directory Organization

```
.
├── .kiro/                  # Kiro AI assistant configuration
│   ├── settings/          # Configuration files
│   │   └── mcp.json      # MCP server configuration
│   └── steering/         # AI guidance documents
│       ├── product.md    # Product overview
│       ├── tech.md       # Technology stack
│       └── structure.md  # This file
└── .vscode/              # VSCode configuration
    └── settings.json     # Editor settings
```

## Key Directories

### `.kiro/`
- **Purpose**: Kiro AI assistant configuration and guidance
- **settings/**: Configuration files for MCP and other Kiro features
- **steering/**: Markdown files that guide AI behavior and provide project context

### `.vscode/`
- **Purpose**: VSCode editor configuration
- **Contains**: Project-specific editor settings and Kiro integration config

## File Conventions

- **Configuration files**: JSON format for settings
- **Steering documents**: Markdown format for AI guidance
- **Naming**: Use lowercase with hyphens for multi-word files
- **Organization**: Keep configuration separate from guidance documents

## Adding New Components

When extending this workspace:
- Add new steering rules in `.kiro/steering/`
- Update MCP configuration in `.kiro/settings/mcp.json`
- VSCode settings go in `.vscode/settings.json`
- Follow existing naming and organization patterns