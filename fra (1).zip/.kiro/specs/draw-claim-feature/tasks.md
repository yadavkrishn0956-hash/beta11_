# Implementation Plan: Draw New Claim Feature

- [x] 1. Set up dependencies and libraries
  - Add Leaflet.draw CDN links to index.html
  - Add Turf.js CDN link to index.html
  - Verify Leaflet map is initialized before adding draw control
  - _Requirements: 1.1, 7.1_

- [x] 2. Implement DrawClaimManager class
- [x] 2.1 Create DrawClaimManager class structure
  - Create class with properties for map, drawControl, drawnLayer, coordinates, area
  - Initialize in script.js after map is ready
  - Add role-based access check in constructor
  - _Requirements: 1.1, 6.1_

- [x] 2.2 Implement polygon drawing functionality
  - Initialize Leaflet.draw control with polygon-only mode
  - Add draw control to map
  - Implement handleDrawCreated event handler
  - Store drawn coordinates and layer reference
  - _Requirements: 1.1, 1.2, 1.4_

- [x] 2.3 Implement area calculation
  - Create calculateArea method using Turf.js
  - Convert square meters to hectares
  - Format to 2 decimal places
  - Add area validation (min 0.1 ha, max 10 ha)
  - _Requirements: 1.3, 7.1, 7.2, 7.3, 7.4_

- [x] 2.4 Implement form display logic
  - Create showClaimForm method
  - Pre-fill area field with calculated value
  - Load villages dropdown from API
  - Display modal with fade-in animation
  - _Requirements: 1.5, 2.1_

- [x] 3. Create claim submission form UI
- [x] 3.1 Add HTML modal structure
  - Create modal container in index.html
  - Add form with all required fields (claimant, type, village, area, scheme, notes)
  - Add close button and cancel/submit actions
  - Style modal with CSS (centered, overlay, responsive)
  - _Requirements: 2.1, 2.2, 2.3, 10.1, 10.2, 10.3_

- [x] 3.2 Implement form validation
  - Create validateClaimForm function
  - Validate required fields (claimant name, claim type, village)
  - Validate claimant name length (min 3 characters)
  - Check area limits and display warnings
  - Display inline error messages for invalid fields
  - _Requirements: 2.4, 2.5, 7.3, 7.4_

- [x] 3.3 Add form event handlers
  - Implement form submit handler
  - Implement cancel button handler
  - Implement close modal (X button) handler
  - Add keyboard support (ESC to close)
  - Prevent form submission on Enter key in text inputs
  - _Requirements: 2.4, 8.1_

- [x] 4. Implement backend API endpoint
- [x] 4.1 Create role check middleware
  - Create server/middleware/roleCheck.js
  - Implement role verification logic
  - Check for allowed roles (District Officer, State Officer, Admin)
  - Return 403 for unauthorized access
  - _Requirements: 6.1, 6.2, 6.3, 6.4_

- [x] 4.2 Add claim creation endpoint
  - Add POST /api/claims/create route in server/routes/claims.js
  - Apply auth and roleCheck middleware
  - Validate request body (geometry, claimant_name, claim_type, village)
  - Generate unique claim ID in format FRA-{STATE}-{DISTRICT}-{YEAR}-{NUMBER}
  - _Requirements: 3.1, 3.2, 3.3, 6.3_

- [x] 4.3 Implement claim ID generation
  - Create generateClaimId helper function
  - Fetch village data to get state and district codes
  - Query database for claim count in current year
  - Format ID with zero-padded number (001, 002, etc.)
  - _Requirements: 3.3_

- [x] 4.4 Implement database save logic
  - Create saveClaim function
  - Store all claim fields including geometry as JSONB
  - Set initial status as "Pending"
  - Store created_by user ID and created_date timestamp
  - Return saved claim with generated ID
  - _Requirements: 3.2, 3.4, 3.5, 9.1, 9.4_

- [ ] 5. Integrate AI verification service
- [ ] 5.1 Create AI verification trigger function
  - Create triggerAIVerification async function
  - Make POST request to AI service /ai/verify-claim endpoint
  - Pass claim_id, geometry, claim_type, area_ha
  - Don't wait for response (fire and forget)
  - _Requirements: 4.1, 4.2_

- [ ] 5.2 Implement AI verification endpoint in Python service
  - Add /ai/verify-claim route in ai_service/main.py
  - Implement analyze_geometry function (placeholder with random score 70-95)
  - Implement check_overlaps function (return empty array for now)
  - Implement recommend_scheme function based on claim type
  - Return JSON with ai_verification_score, confidence_level, recommended_scheme
  - _Requirements: 4.2, 4.3, 4.4_

- [ ] 5.3 Handle AI verification response
  - Create updateClaimAIScore function
  - Update claim record with AI score, confidence, and recommendation
  - Broadcast update to connected clients (if WebSocket implemented)
  - Log verification completion
  - _Requirements: 4.5_

- [ ] 5.4 Implement AI verification error handling
  - Wrap AI call in try-catch
  - If AI service unavailable, log error and queue for retry
  - Create queueAIVerification function to store failed attempts
  - Implement retry mechanism (check queue every 5 minutes)
  - _Requirements: 8.2_

- [x] 6. Implement frontend claim submission
- [x] 6.1 Create submitClaim function
  - Collect form data (claimant_name, claim_type, village, linked_scheme, notes)
  - Add geometry from drawn polygon
  - Add calculated area
  - Validate form data before submission
  - _Requirements: 2.4, 8.1_

- [x] 6.2 Implement API call to create claim
  - Make POST request to /api/claims/create
  - Include JWT token in Authorization header
  - Handle loading state (disable submit button, show spinner)
  - Implement timeout (30 seconds)
  - _Requirements: 3.1, 8.1_

- [x] 6.3 Handle successful submission
  - Create handleSubmitSuccess function
  - Display success toast with claim ID
  - Close form modal
  - Add new polygon to map with "Pending" status (yellow color)
  - Zoom map to fit new polygon
  - Clear drawing state
  - _Requirements: 5.1, 5.2, 5.5, 8.3_

- [x] 6.4 Handle submission errors
  - Create handleSubmitError function
  - Display error toast with descriptive message
  - Retain form data (don't clear form)
  - Enable retry (keep submit button active)
  - Implement automatic retry for network errors (max 2 attempts)
  - _Requirements: 8.1, 8.2, 8.5_

- [x] 7. Implement real-time map updates
- [x] 7.1 Add new claim polygon to map
  - Create addClaimToMap function
  - Parse geometry from API response
  - Create GeoJSON layer with status-based color
  - Add popup with claim details
  - Add layer to map
  - _Requirements: 5.1, 5.2_

- [x] 7.2 Implement status-based coloring
  - Yellow (#f59e0b) for "Pending" status
  - Green (#10b981) for "Approved" status (after AI verification if score >= 80)
  - Red (#ef4444) for "Rejected" status (if score < 60)
  - Blue (#3b82f6) for "Under Review" status
  - _Requirements: 5.2, 5.4_

- [x] 7.3 Create claim popup content
  - Display claim ID, claimant name, type, status
  - Show area in hectares
  - Display "AI Verification: In Progress" initially
  - Update popup when AI verification completes
  - Add "View Details" button linking to claim details page
  - _Requirements: 5.3_

- [x] 7.4 Implement zoom to new claim
  - Calculate bounds from polygon geometry
  - Use map.flyToBounds with 50px padding
  - Animate zoom over 1 second
  - Open popup automatically after zoom
  - _Requirements: 5.5_

- [x] 8. Add role-based UI controls
- [x] 8.1 Create "Draw New Claim" button
  - Add button to map controls area in index.html
  - Style button with primary color and icon
  - Position button in top-left corner below zoom controls
  - Make button responsive (full-width on mobile)
  - _Requirements: 6.1, 10.1_

- [x] 8.2 Implement role-based visibility
  - Check user role on page load
  - Show button only for District Officer, State Officer, Admin roles
  - Hide button for Citizen, NGO, Viewer roles
  - Add tooltip explaining access restriction if hidden
  - _Requirements: 6.1, 6.2_

- [x] 8.3 Add button click handler
  - Implement enableDrawing function
  - Verify user is logged in
  - Verify user has required role
  - Activate Leaflet.draw polygon tool
  - Display instruction toast "Click on map to draw polygon boundary"
  - _Requirements: 1.1, 6.1_

- [x] 9. Implement area validation and warnings
- [x] 9.1 Add area validation logic
  - Check if area < 0.1 hectares
  - Check if area > 10 hectares
  - Display warning messages in form
  - Allow submission despite warnings (flag for manual review)
  - _Requirements: 7.3, 7.4, 7.5_

- [x] 9.2 Add visual warning indicators
  - Show yellow warning icon for area issues
  - Display warning text below area field
  - Add "Flag for Manual Review" checkbox if warnings present
  - Style warnings with yellow background
  - _Requirements: 7.3, 7.4_

- [ ] 10. Add database schema updates
- [ ] 10.1 Update fra_claims table schema
  - Add geometry column as JSONB if not exists
  - Add created_by column as VARCHAR(255)
  - Add notes column as TEXT
  - Add ai_confidence column as VARCHAR(50)
  - Add recommended_scheme column as VARCHAR(100)
  - _Requirements: 9.1_

- [ ] 10.2 Add database indexes
  - Create GIN index on geometry column for spatial queries
  - Create index on created_by for user query performance
  - Create index on created_date for date range queries
  - _Requirements: 9.1_

- [x] 11. Implement error handling and logging
- [x] 11.1 Add frontend error handling
  - Wrap all async operations in try-catch
  - Display user-friendly error messages
  - Log errors to console for debugging
  - Implement error boundary for critical failures
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 11.2 Add backend error handling
  - Validate all request inputs
  - Return appropriate HTTP status codes
  - Log all errors with timestamps and user context
  - Implement error response format consistency
  - _Requirements: 8.1, 8.2, 8.3_

- [x] 11.3 Implement audit logging
  - Log all claim creation attempts
  - Store user ID, timestamp, claim ID, success/failure
  - Log AI verification triggers and results
  - Create audit log table if needed
  - _Requirements: 9.4_

- [x] 12. Add mobile responsiveness
- [x] 12.1 Make form mobile-friendly
  - Stack form fields vertically on mobile
  - Increase input height to 44px minimum
  - Make modal full-screen on mobile (< 768px)
  - Adjust font sizes for readability
  - _Requirements: 10.1, 10.2, 10.3_

- [x] 12.2 Optimize drawing for touch devices
  - Test polygon drawing with touch events
  - Increase vertex touch target size
  - Add visual feedback for touch interactions
  - Prevent accidental map panning while drawing
  - _Requirements: 10.4_

- [x] 12.3 Adjust button positioning for mobile
  - Move "Draw New Claim" button to bottom on mobile
  - Make button sticky at bottom of screen
  - Ensure button doesn't overlap with keyboard
  - Test on various mobile screen sizes
  - _Requirements: 10.5_

- [ ] 13. Integration and testing
- [ ] 13.1 Test complete user flow
  - Test drawing polygon → filling form → submitting → viewing on map
  - Verify area calculation accuracy
  - Verify claim ID generation
  - Verify AI verification trigger
  - Test with different user roles
  - _Requirements: All_

- [ ] 13.2 Test error scenarios
  - Test network failure during submission
  - Test invalid form data
  - Test unauthorized access attempt
  - Test AI service unavailable
  - Test database connection failure
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [ ] 13.3 Test mobile functionality
  - Test on iOS Safari and Android Chrome
  - Test touch-based polygon drawing
  - Test form submission on mobile
  - Test button visibility and positioning
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [ ] 13.4 Performance testing
  - Measure form submission time (should be < 2 seconds)
  - Measure AI verification time (should complete within 10 seconds)
  - Test with complex polygons (100+ vertices)
  - Test concurrent claim submissions
  - _Requirements: 1.5, 4.1_

