# Design Document: Draw New Claim Feature

## Overview

The Draw New Claim feature enables authorized users to create FRA claims by drawing polygons directly on the map interface. The system integrates Leaflet.draw for polygon creation, provides a modal form for claim details, automatically calculates area using Turf.js, triggers AI verification, and displays the new claim in real-time.

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Frontend (Browser)                       │
│  ┌────────────────┐  ┌──────────────┐  ┌─────────────────┐ │
│  │ Draw Control   │  │ Claim Form   │  │ Map Display     │ │
│  │ - Leaflet.draw │  │ - Modal      │  │ - New Polygon   │ │
│  │ - Polygon Tool │──│ - Validation │──│ - Status Color  │ │
│  │ - Area Calc    │  │ - Submit     │  │ - Popup Info    │ │
│  └────────────────┘  └──────────────┘  └─────────────────┘ │
│           │                  │                   │           │
│           └──────────────────┴───────────────────┘           │
│                              │                                │
└──────────────────────────────┼────────────────────────────────┘
                               │ HTTP/REST
┌──────────────────────────────┼────────────────────────────────┐
│                     Backend (Node.js)                         │
│  ┌────────────────┐  ┌──────────────┐  ┌─────────────────┐ │
│  │ Claims Routes  │  │ Claims Ctrl  │  │ Auth Middleware │ │
│  │ POST /create   │──│ - Validate   │──│ - Role Check    │ │
│  │                │  │ - Save DB    │  │ - JWT Verify    │ │
│  │                │  │ - Trigger AI │  │                 │ │
│  └────────────────┘  └──────────────┘  └─────────────────┘ │
│           │                  │                   │           │
│           └──────────────────┴───────────────────┘           │
│                              │                                │
└──────────────────────────────┼────────────────────────────────┘
                               │
┌──────────────────────────────┼────────────────────────────────┐
│                        Services                               │
│  ┌────────────────┐  ┌──────────────┐  ┌─────────────────┐ │
│  │ AI Service     │  │ Database     │  │ Turf.js         │ │
│  │ - Verify Claim │  │ - PostgreSQL │  │ - Area Calc     │ │
│  │ - Score 0-100  │  │ - JSONB Geo  │  │ - Validation    │ │
│  │ - Recommend    │  │              │  │                 │ │
│  └────────────────┘  └──────────────┘  └─────────────────┘ │
└───────────────────────────────────────────────────────────────┘
```

### Data Flow

1. **User Clicks "Draw New Claim"**: Activates Leaflet.draw polygon tool
2. **User Draws Polygon**: Each click adds vertex, double-click completes
3. **Polygon Complete**: Calculate area with Turf.js, open claim form modal
4. **User Fills Form**: Enter claimant name, type, village, scheme
5. **User Submits**: Validate form → POST to /api/claims/create
6. **Backend Processes**: Verify role → Save to DB → Trigger AI service
7. **AI Verification**: Analyze geometry → Calculate score → Recommend scheme
8. **Response Returns**: Display success toast → Add polygon to map → Update with AI results

## Components and Interfaces

### 1. Frontend Components

#### DrawClaimManager (JavaScript Class)

**Purpose**: Manages polygon drawing, form display, and claim submission

**Properties**:
```javascript
{
  map: L.Map,
  drawControl: L.Control.Draw,
  drawnLayer: L.Layer | null,
  drawnCoords: Array<[lat, lng]>,
  calculatedArea: Number,
  isDrawing: Boolean,
  formModal: HTMLElement,
  currentUser: User
}
```

**Methods**:
- `initializeDrawControl()`: Sets up Leaflet.draw with polygon-only mode
- `enableDrawing()`: Activates drawing mode (checks user role first)
- `handleDrawCreated(event)`: Callback when polygon is completed
- `calculateArea(coordinates)`: Uses Turf.js to calculate area in hectares
- `showClaimForm()`: Displays modal form with pre-filled area
- `validateForm(formData)`: Validates required fields and area limits
- `submitClaim(formData)`: Sends POST request to backend
- `handleSubmitSuccess(claim)`: Adds polygon to map, shows success message
- `handleSubmitError(error)`: Displays error toast, retains form data
- `clearDrawing()`: Removes drawn polygon and resets state

#### ClaimFormModal (HTML + JavaScript)

**Purpose**: Modal form for capturing claim details

**HTML Structure**:
```html
<div id="claimFormModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2>📋 New FRA Claim</h2>
    <form id="claimForm">
      <div class="form-group">
        <label>Claimant Name *</label>
        <input type="text" name="claimant_name" required>
      </div>
      
      <div class="form-group">
        <label>Claim Type *</label>
        <select name="claim_type" required>
          <option value="">Select Type</option>
          <option value="IFR">Individual Forest Rights (IFR)</option>
          <option value="CFR">Community Forest Rights (CFR)</option>
          <option value="CR">Community Rights (CR)</option>
        </select>
      </div>
      
      <div class="form-group">
        <label>Village *</label>
        <select name="village" id="villageSelect" required>
          <option value="">Select Village</option>
        </select>
      </div>
      
      <div class="form-group">
        <label>Area (Hectares)</label>
        <input type="number" name="area_ha" id="areaInput" readonly>
      </div>
      
      <div class="form-group">
        <label>Linked Scheme (Optional)</label>
        <select name="linked_scheme">
          <option value="">None</option>
          <option value="PM-KISAN">PM-KISAN</option>
          <option value="MGNREGA">MGNREGA</option>
          <option value="DAJGUA">DAJGUA</option>
          <option value="Jal Jeevan Mission">Jal Jeevan Mission</option>
        </select>
      </div>
      
      <div class="form-group">
        <label>Additional Notes</label>
        <textarea name="notes" rows="3"></textarea>
      </div>
      
      <div class="form-actions">
        <button type="button" class="btn-secondary" onclick="closeClaimForm()">Cancel</button>
        <button type="submit" class="btn-primary">Submit Claim</button>
      </div>
    </form>
  </div>
</div>
```

**JavaScript Functions**:
```javascript
function showClaimForm(area) {
  document.getElementById('areaInput').value = area.toFixed(2);
  document.getElementById('claimFormModal').style.display = 'block';
  loadVillagesForForm();
}

function closeClaimForm() {
  document.getElementById('claimFormModal').style.display = 'none';
  clearDrawing();
}

function validateClaimForm(formData) {
  const errors = [];
  
  if (!formData.claimant_name || formData.claimant_name.trim().length < 3) {
    errors.push('Claimant name must be at least 3 characters');
  }
  
  if (!formData.claim_type) {
    errors.push('Please select a claim type');
  }
  
  if (!formData.village) {
    errors.push('Please select a village');
  }
  
  if (formData.area_ha < 0.1) {
    errors.push('Area is too small for FRA claim (minimum 0.1 hectares)');
  }
  
  if (formData.area_ha > 10) {
    errors.push('Area exceeds typical FRA claim size (maximum 10 hectares)');
  }
  
  return errors;
}
```

### 2. Backend Components

#### Claims Routes (`server/routes/claims.js`)

**New Endpoint**:

```javascript
// @route   POST /api/claims/create
// @desc    Create new FRA claim with polygon geometry
// @access  Private (District Officer, State Officer, Admin only)
router.post('/create', auth, roleCheck(['District Officer', 'State Officer', 'Admin']), async (req, res) => {
  try {
    const { claimant_name, claim_type, village, linked_scheme, notes, geometry } = req.body;
    
    // Validate geometry
    if (!geometry || !geometry.coordinates) {
      return res.status(400).json({
        success: false,
        error: 'Invalid geometry data'
      });
    }
    
    // Calculate area using Turf.js
    const area_ha = turf.area(geometry) / 10000; // Convert m² to hectares
    
    // Generate claim ID
    const claim_id = await generateClaimId(village);
    
    // Create claim record
    const newClaim = {
      claim_id,
      claimant_name,
      claim_type,
      status: 'Pending',
      village,
      area_ha: area_ha.toFixed(2),
      linked_scheme: linked_scheme || null,
      notes: notes || null,
      geometry: JSON.stringify(geometry),
      created_by: req.user.id,
      created_date: new Date().toISOString()
    };
    
    // Save to database
    const savedClaim = await saveClaim(newClaim);
    
    // Trigger AI verification (async, don't wait)
    triggerAIVerification(savedClaim.claim_id, geometry, claim_type, area_ha);
    
    res.status(201).json({
      success: true,
      message: 'Claim created successfully',
      data: savedClaim
    });
    
  } catch (error) {
    console.error('Error creating claim:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create claim'
    });
  }
});

// Helper function to generate claim ID
async function generateClaimId(village) {
  const villageData = await getVillageData(village);
  const year = new Date().getFullYear();
  const count = await getClaimCountForYear(villageData.district_code, year);
  
  return `FRA-${villageData.state_code}-${villageData.district_code}-${year}-${String(count + 1).padStart(3, '0')}`;
}

// Helper function to trigger AI verification
async function triggerAIVerification(claim_id, geometry, claim_type, area_ha) {
  try {
    const response = await axios.post('http://localhost:5000/ai/verify-claim', {
      claim_id,
      geometry,
      claim_type,
      area_ha
    });
    
    // Update claim with AI results
    await updateClaimAIScore(claim_id, response.data);
    
  } catch (error) {
    console.error('AI verification failed:', error);
    // Queue for retry
    await queueAIVerification(claim_id);
  }
}
```

#### Role Check Middleware (`server/middleware/roleCheck.js`)

```javascript
module.exports = function roleCheck(allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !req.user.role) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: No role assigned'
      });
    }
    
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: Insufficient permissions'
      });
    }
    
    next();
  };
};
```

### 3. AI Service Integration

#### AI Verification Endpoint (`ai_service/main.py`)

```python
@app.route('/ai/verify-claim', methods=['POST'])
def verify_claim():
    data = request.json
    claim_id = data.get('claim_id')
    geometry = data.get('geometry')
    claim_type = data.get('claim_type')
    area_ha = data.get('area_ha')
    
    # Analyze geometry against satellite imagery
    verification_score = analyze_geometry(geometry)
    
    # Check for overlaps with existing claims
    overlaps = check_overlaps(geometry)
    
    # Recommend schemes based on location and type
    recommended_scheme = recommend_scheme(claim_type, geometry)
    
    # Calculate confidence level
    confidence = calculate_confidence(verification_score, overlaps)
    
    return jsonify({
        'claim_id': claim_id,
        'ai_verification_score': verification_score,
        'confidence_level': confidence,
        'recommended_scheme': recommended_scheme,
        'overlaps': overlaps,
        'verified_at': datetime.now().isoformat()
    })

def analyze_geometry(geometry):
    # Placeholder for satellite imagery analysis
    # In production, integrate with Bhuvan/Sentinel APIs
    base_score = random.uniform(70, 95)
    return round(base_score, 1)

def check_overlaps(geometry):
    # Check if polygon overlaps with existing approved claims
    # Return list of overlapping claim IDs
    return []

def recommend_scheme(claim_type, geometry):
    schemes = {
        'IFR': 'PM-KISAN',
        'CFR': 'MGNREGA',
        'CR': 'DAJGUA'
    }
    return schemes.get(claim_type, 'PM-KISAN')
```

## Data Models

### Claim Model (Database)

```javascript
{
  claim_id: String,           // "FRA-MP-BHO-2025-001"
  claimant_name: String,      // "Ramesh Patel"
  claim_type: String,         // "IFR" | "CFR" | "CR"
  status: String,             // "Pending" | "Approved" | "Rejected"
  village: String,            // "Berasia"
  district: String,           // "Bhopal"
  state: String,              // "Madhya Pradesh"
  area_ha: Number,            // 2.45
  linked_scheme: String,      // "PM-KISAN" | null
  notes: String,              // Optional notes
  geometry: JSONB,            // GeoJSON polygon
  ai_score: Number,           // 0-100 | null
  ai_confidence: String,      // "High" | "Medium" | "Low" | null
  recommended_scheme: String, // AI recommendation
  created_by: String,         // User ID
  created_date: Date,         // ISO timestamp
  verified_date: Date,        // ISO timestamp | null
  approved_date: Date,        // ISO timestamp | null
  rejected_date: Date         // ISO timestamp | null
}
```

### GeoJSON Geometry Format

```json
{
  "type": "Polygon",
  "coordinates": [
    [
      [77.405, 23.545],
      [77.415, 23.545],
      [77.415, 23.540],
      [77.405, 23.540],
      [77.405, 23.545]
    ]
  ]
}
```

## Error Handling

### Frontend Error Handling

1. **Network Errors**: Display toast, retain form data, enable retry
2. **Validation Errors**: Show inline error messages, highlight invalid fields
3. **Area Warnings**: Display warning but allow submission
4. **Unauthorized Access**: Hide draw button, show "Access Denied" if attempted

### Backend Error Handling

1. **Invalid Geometry**: Return 400 with descriptive error
2. **Unauthorized Role**: Return 403 with permission error
3. **Database Errors**: Return 500, log error, queue for retry
4. **AI Service Down**: Create claim without AI score, queue verification

## Testing Strategy

### Unit Tests

1. **DrawClaimManager**:
   - Test polygon drawing activation
   - Test area calculation accuracy
   - Test form validation logic
   - Test role-based access

2. **Backend API**:
   - Test claim creation with valid data
   - Test role-based access control
   - Test geometry validation
   - Test claim ID generation

### Integration Tests

1. **Full Flow**:
   - Draw polygon → Fill form → Submit → Verify DB save → Check map update
   - Test AI verification trigger and response handling
   - Test error scenarios (network failure, invalid data)

### Manual Testing

1. **User Roles**: Test with different user roles (Officer, Citizen, Admin)
2. **Mobile**: Test drawing on touch devices
3. **Edge Cases**: Very small polygons, very large polygons, complex shapes

## Implementation Notes

### Leaflet.draw Integration

```javascript
// Add Leaflet.draw CSS and JS
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"></script>

// Initialize draw control
const drawControl = new L.Control.Draw({
  draw: {
    polygon: {
      allowIntersection: false,
      showArea: true,
      shapeOptions: {
        color: '#f59e0b',
        weight: 3
      }
    },
    polyline: false,
    rectangle: false,
    circle: false,
    marker: false,
    circlemarker: false
  },
  edit: {
    featureGroup: drawnItems,
    remove: true
  }
});
```

### Turf.js Area Calculation

```javascript
// Install Turf.js
<script src="https://cdn.jsdelivr.net/npm/@turf/turf@6/turf.min.js"></script>

// Calculate area
function calculateArea(coordinates) {
  const polygon = turf.polygon(coordinates);
  const areaInSquareMeters = turf.area(polygon);
  const areaInHectares = areaInSquareMeters / 10000;
  return areaInHectares;
}
```

### Database Schema Update

```sql
-- Add geometry column if not exists
ALTER TABLE fra_claims 
ADD COLUMN IF NOT EXISTS geometry JSONB;

-- Add index for geometry queries
CREATE INDEX IF NOT EXISTS idx_fra_claims_geometry 
ON fra_claims USING GIN (geometry);

-- Add created_by column
ALTER TABLE fra_claims 
ADD COLUMN IF NOT EXISTS created_by VARCHAR(255);
```

## Security Considerations

1. **Role Verification**: Always verify user role on backend, never trust frontend
2. **Geometry Validation**: Validate polygon complexity and size limits
3. **SQL Injection**: Use parameterized queries for all database operations
4. **XSS Prevention**: Sanitize all user inputs (claimant name, notes)
5. **Rate Limiting**: Limit claim creation to 10 per hour per user

## Performance Optimization

1. **Async AI Verification**: Don't block claim creation waiting for AI
2. **Geometry Simplification**: Simplify complex polygons to reduce storage
3. **Caching**: Cache village dropdown data
4. **Debouncing**: Debounce form validation
5. **Lazy Loading**: Load Leaflet.draw only when needed

