# Draw New Claim Feature Specification

## Overview

This specification defines the implementation of a polygon drawing tool that enables authorized users to create new FRA (Forest Rights Act) claims directly on the map interface. The feature integrates Leaflet.draw for polygon creation, provides a comprehensive claim submission form, automatically calculates land area, triggers AI verification, and displays claims in real-time.

## Feature Summary

**Goal**: Empower District Officers and State Officers to create, visualize, and verify new FRA claims directly from the WebGIS map with real-time AI validation, automatic DSS recommendations, and role-based controls.

**Key Capabilities**:
- 🗺️ Interactive polygon drawing on map
- 📋 Comprehensive claim submission form
- 🤖 Automatic AI verification and scoring
- 📊 Real-time map updates with status colors
- 🔐 Role-based access control
- 📱 Mobile-responsive design
- ⚡ Area calculation using Turf.js
- 🛰️ Integration with Bhuvan satellite imagery

## Documents

- **[requirements.md](./requirements.md)**: Detailed requirements with user stories and acceptance criteria
- **[design.md](./design.md)**: Technical design, architecture, and component specifications
- **[tasks.md](./tasks.md)**: Implementation task list with step-by-step instructions

## Quick Start

### Prerequisites

- Leaflet map already initialized
- User authentication system in place
- Backend API server running
- AI verification service available
- PostgreSQL database with fra_claims table

### Implementation Steps

1. **Review Requirements**: Read requirements.md to understand feature scope
2. **Study Design**: Review design.md for technical architecture
3. **Execute Tasks**: Follow tasks.md sequentially for implementation
4. **Test**: Verify all functionality works as expected

### Estimated Timeline

- **Setup & Dependencies**: 1 hour
- **Frontend Implementation**: 8 hours
- **Backend Implementation**: 6 hours
- **AI Integration**: 4 hours
- **Testing & Polish**: 4 hours
- **Total**: ~23 hours (3 days)

## Key Technologies

- **Leaflet.draw**: Polygon drawing interface
- **Turf.js**: Geospatial calculations (area, validation)
- **Node.js/Express**: Backend API
- **PostgreSQL**: Database with JSONB geometry storage
- **Python/Flask**: AI verification service
- **Vanilla JavaScript**: Frontend logic (no React/Vue)

## User Roles

| Role | Can Draw Claims | Can View Claims | Can Approve Claims |
|------|----------------|-----------------|-------------------|
| District Officer | ✅ | ✅ | ✅ |
| State Officer | ✅ | ✅ | ✅ |
| Admin | ✅ | ✅ | ✅ |
| Citizen | ❌ | ✅ | ❌ |
| NGO | ❌ | ✅ | ❌ |
| Viewer | ❌ | ✅ | ❌ |

## Feature Flow

```
1. User clicks "Draw New Claim" button
   ↓
2. Polygon drawing mode activates
   ↓
3. User draws polygon on map (click vertices, double-click to finish)
   ↓
4. System calculates area using Turf.js
   ↓
5. Claim form modal opens with pre-filled area
   ↓
6. User enters claim details (claimant, type, village, scheme)
   ↓
7. User submits form
   ↓
8. Backend validates and saves claim (status: Pending)
   ↓
9. AI verification triggered (async)
   ↓
10. New polygon appears on map (yellow = pending)
    ↓
11. AI verification completes
    ↓
12. Polygon color updates based on AI score
    ↓
13. Claim ready for officer review
```

## API Endpoints

### Create Claim
```
POST /api/claims/create
Authorization: Bearer {token}
Content-Type: application/json

Request Body:
{
  "claimant_name": "Ramesh Patel",
  "claim_type": "IFR",
  "village": "Berasia",
  "linked_scheme": "PM-KISAN",
  "notes": "Traditional cultivation area",
  "geometry": {
    "type": "Polygon",
    "coordinates": [[[77.405, 23.545], ...]]
  }
}

Response (201):
{
  "success": true,
  "message": "Claim created successfully",
  "data": {
    "claim_id": "FRA-MP-BHO-2025-001",
    "claimant_name": "Ramesh Patel",
    "status": "Pending",
    "area_ha": 2.45,
    "created_date": "2025-01-26T10:30:00Z"
  }
}
```

### AI Verification
```
POST /ai/verify-claim
Content-Type: application/json

Request Body:
{
  "claim_id": "FRA-MP-BHO-2025-001",
  "geometry": {...},
  "claim_type": "IFR",
  "area_ha": 2.45
}

Response (200):
{
  "claim_id": "FRA-MP-BHO-2025-001",
  "ai_verification_score": 84.5,
  "confidence_level": "High",
  "recommended_scheme": "PM-KISAN",
  "overlaps": [],
  "verified_at": "2025-01-26T10:30:15Z"
}
```

## Database Schema

```sql
CREATE TABLE fra_claims (
  id SERIAL PRIMARY KEY,
  claim_id VARCHAR(50) UNIQUE NOT NULL,
  claimant_name VARCHAR(255) NOT NULL,
  claim_type VARCHAR(10) NOT NULL,
  status VARCHAR(50) DEFAULT 'Pending',
  village VARCHAR(255) NOT NULL,
  district VARCHAR(255),
  state VARCHAR(255),
  area_ha DECIMAL(10, 2),
  linked_scheme VARCHAR(100),
  notes TEXT,
  geometry JSONB,
  ai_score DECIMAL(5, 2),
  ai_confidence VARCHAR(50),
  recommended_scheme VARCHAR(100),
  created_by VARCHAR(255),
  created_date TIMESTAMP DEFAULT NOW(),
  verified_date TIMESTAMP,
  approved_date TIMESTAMP,
  rejected_date TIMESTAMP
);

CREATE INDEX idx_fra_claims_geometry ON fra_claims USING GIN (geometry);
CREATE INDEX idx_fra_claims_created_by ON fra_claims (created_by);
CREATE INDEX idx_fra_claims_status ON fra_claims (status);
```

## Status Colors

| Status | Color | Hex Code | Meaning |
|--------|-------|----------|---------|
| Pending | Yellow | #f59e0b | Awaiting AI verification |
| Approved | Green | #10b981 | AI score >= 80, verified |
| Rejected | Red | #ef4444 | AI score < 60, needs review |
| Under Review | Blue | #3b82f6 | Manual review in progress |

## Validation Rules

### Area Limits
- **Minimum**: 0.1 hectares (warning if below)
- **Maximum**: 10 hectares (warning if above)
- **Warnings**: Display but allow submission with flag

### Form Validation
- **Claimant Name**: Required, min 3 characters
- **Claim Type**: Required, must be IFR/CFR/CR
- **Village**: Required, must exist in database
- **Linked Scheme**: Optional
- **Notes**: Optional, max 500 characters

### Geometry Validation
- **Type**: Must be Polygon or MultiPolygon
- **Coordinates**: Must have at least 3 vertices
- **Complexity**: Max 1000 vertices (simplified if exceeded)
- **Self-intersection**: Not allowed

## Error Handling

### Frontend Errors
- Network failure → Toast + Retry button
- Validation error → Inline error messages
- Unauthorized → Hide button + Access denied message
- Area warning → Yellow warning box

### Backend Errors
- Invalid geometry → 400 Bad Request
- Unauthorized role → 403 Forbidden
- Database error → 500 Internal Server Error + Retry queue
- AI service down → Create claim, queue verification

## Testing Checklist

- [ ] Draw polygon with 4 vertices
- [ ] Draw complex polygon with 20+ vertices
- [ ] Submit claim with all fields filled
- [ ] Submit claim with only required fields
- [ ] Test area calculation accuracy
- [ ] Test with area < 0.1 ha (warning)
- [ ] Test with area > 10 ha (warning)
- [ ] Test as District Officer (should work)
- [ ] Test as Citizen (should be blocked)
- [ ] Test network failure scenario
- [ ] Test AI service unavailable
- [ ] Verify claim appears on map
- [ ] Verify claim ID format
- [ ] Test on mobile device
- [ ] Test form validation errors

## Success Criteria

✅ District Officers can draw polygons on map  
✅ Area is calculated automatically and accurately  
✅ Claim form validates all inputs  
✅ Claims are saved to database with geometry  
✅ AI verification triggers automatically  
✅ New claims appear on map in real-time  
✅ Status colors update based on AI score  
✅ Role-based access control works  
✅ Mobile-responsive design functions properly  
✅ Error handling provides clear feedback  

## Next Steps After Implementation

1. **User Training**: Create tutorial for District Officers
2. **Performance Monitoring**: Track claim creation times
3. **AI Model Improvement**: Refine verification algorithms
4. **Bulk Import**: Add CSV upload for multiple claims
5. **Offline Support**: Enable offline polygon drawing
6. **Advanced Editing**: Allow editing of existing claim boundaries

## Support & Documentation

- **User Guide**: Create step-by-step guide with screenshots
- **API Documentation**: Document all endpoints with examples
- **Troubleshooting**: Common issues and solutions
- **Video Tutorial**: Record demo of drawing and submitting claim

---

**Status**: Ready for Implementation  
**Priority**: High  
**Complexity**: Medium-High  
**Dependencies**: Map integration, User authentication, AI service  

