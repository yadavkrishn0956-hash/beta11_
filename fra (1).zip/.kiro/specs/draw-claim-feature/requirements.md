# Requirements Document: Draw New Claim Feature

## Introduction

This document outlines the requirements for implementing a polygon drawing tool that enables authorized users (District Officers, State Officers) to create new FRA claims directly on the map by drawing boundaries, entering claim details, and submitting for AI verification.

## Glossary

- **DrawingTool**: Interactive polygon drawing interface using Leaflet.draw library
- **ClaimForm**: Modal form for capturing FRA claim details after polygon is drawn
- **ClaimPolygon**: User-drawn polygon representing the land boundary of an FRA claim
- **AIVerification**: Automated verification service that validates claim geometry and recommends schemes
- **RoleBasedAccess**: Permission system restricting drawing capability to authorized users only
- **GeoJSON**: Standard format for encoding geographic data structures

## Requirements

### Requirement 1: Polygon Drawing Interface

**User Story:** As a District Officer, I want to draw a polygon on the map to mark claim boundaries, so that I can create new FRA claims with accurate geographic data.

#### Acceptance Criteria

1. WHEN a District Officer clicks "Draw New Claim" button, THE DrawingTool SHALL activate polygon drawing mode
2. WHEN the user draws a polygon, THE DrawingTool SHALL display the polygon on the map with visual feedback
3. WHEN the polygon is completed, THE DrawingTool SHALL calculate the area in hectares automatically
4. THE DrawingTool SHALL support only polygon drawing (no circles, markers, or lines)
5. WHEN a polygon is drawn, THE DrawingTool SHALL open the ClaimForm modal within 500 milliseconds

### Requirement 2: Claim Submission Form

**User Story:** As a District Officer, I want to enter claim details after drawing a boundary, so that the claim can be properly documented and verified.

#### Acceptance Criteria

1. WHEN a polygon is drawn, THE ClaimForm SHALL display with pre-filled area calculation
2. THE ClaimForm SHALL require claimant name, claim type (IFR/CFR/CR), and village selection
3. THE ClaimForm SHALL provide optional fields for linked scheme and additional notes
4. WHEN the form is submitted, THE ClaimForm SHALL validate all required fields
5. IF validation fails, THEN THE ClaimForm SHALL display error messages for invalid fields

### Requirement 3: Backend API Integration

**User Story:** As a system, I want to save new claims to the database with geometry data, so that claims are persisted and can be retrieved later.

#### Acceptance Criteria

1. THE system SHALL provide POST endpoint at /api/claims/create for new claim submission
2. WHEN a claim is submitted, THE system SHALL store geometry as GeoJSON in the database
3. THE system SHALL generate a unique claim ID in format "FRA-{STATE}-{DISTRICT}-{YEAR}-{NUMBER}"
4. THE system SHALL set initial status as "Pending" for all new claims
5. THE system SHALL return the created claim with all fields including generated ID

### Requirement 4: AI Verification Integration

**User Story:** As a system, I want to automatically verify new claims using AI, so that claims are validated for accuracy and fraud detection.

#### Acceptance Criteria

1. WHEN a claim is created, THE system SHALL trigger AIVerification service within 2 seconds
2. THE AIVerification SHALL analyze polygon geometry against satellite imagery
3. THE AIVerification SHALL calculate verification score between 0-100
4. THE AIVerification SHALL recommend linked government schemes based on claim type and location
5. WHEN verification completes, THE system SHALL update claim record with AI score and recommendations

### Requirement 5: Real-time Map Updates

**User Story:** As a District Officer, I want to see my newly created claim appear on the map immediately, so that I can confirm the submission was successful.

#### Acceptance Criteria

1. WHEN a claim is successfully created, THE map SHALL display the new polygon within 1 second
2. THE new ClaimPolygon SHALL be colored yellow to indicate "Pending" status
3. WHEN clicked, THE ClaimPolygon SHALL display popup with claim details including "AI Verification: In Progress"
4. WHEN AI verification completes, THE ClaimPolygon SHALL update color based on AI score (green >= 80, yellow >= 60, red < 60)
5. THE map SHALL zoom to fit the new polygon boundary with 50px padding

### Requirement 6: Role-Based Access Control

**User Story:** As a system administrator, I want only authorized users to create claims, so that data integrity is maintained.

#### Acceptance Criteria

1. THE "Draw New Claim" button SHALL be visible only to users with roles: District Officer, State Officer, Admin
2. WHEN a Citizen or NGO user views the map, THE DrawingTool SHALL not be accessible
3. THE backend API SHALL verify user role before accepting claim creation requests
4. IF an unauthorized user attempts to create a claim, THEN THE system SHALL return 403 Forbidden error
5. THE system SHALL log all claim creation attempts with user ID and timestamp

### Requirement 7: Area Calculation and Validation

**User Story:** As a District Officer, I want the system to automatically calculate land area, so that I don't have to manually measure it.

#### Acceptance Criteria

1. WHEN a polygon is drawn, THE system SHALL calculate area using Turf.js library
2. THE calculated area SHALL be displayed in hectares with 2 decimal precision
3. IF the area is less than 0.1 hectares, THEN THE system SHALL display warning "Area too small for FRA claim"
4. IF the area exceeds 10 hectares, THEN THE system SHALL display warning "Area exceeds typical FRA claim size"
5. THE system SHALL allow submission regardless of warnings but flag for manual review

### Requirement 8: Error Handling and User Feedback

**User Story:** As a District Officer, I want clear feedback when something goes wrong, so that I can correct issues and successfully submit claims.

#### Acceptance Criteria

1. IF network error occurs during submission, THEN THE system SHALL display "Network error. Please try again." and retain form data
2. IF AI service is unavailable, THEN THE system SHALL create claim without AI score and queue for later verification
3. WHEN submission succeeds, THE system SHALL display success toast "Claim created successfully! ID: {claim_id}"
4. IF polygon intersects with existing approved claim, THEN THE system SHALL display warning "Overlaps with existing claim {claim_id}"
5. THE system SHALL implement automatic retry (max 2 attempts) for failed API calls

### Requirement 9: Data Persistence and Sync

**User Story:** As a system, I want to ensure all claim data is properly saved and synchronized, so that no data is lost.

#### Acceptance Criteria

1. THE system SHALL store claim geometry in database as JSONB column
2. WHEN a claim is created, THE system SHALL update the claims cache immediately
3. THE system SHALL broadcast new claim to all connected users via WebSocket (if implemented)
4. THE system SHALL maintain audit log of all claim creation events
5. IF database write fails, THEN THE system SHALL queue claim for retry and notify user

### Requirement 10: Mobile Responsiveness

**User Story:** As a field officer using a tablet, I want to draw claims on mobile devices, so that I can create claims while in the field.

#### Acceptance Criteria

1. THE DrawingTool SHALL support touch gestures for polygon drawing on mobile devices
2. THE ClaimForm SHALL be responsive and usable on screens >= 320px width
3. THE form inputs SHALL have minimum touch target size of 44px
4. THE polygon drawing SHALL work with touch events (tap to add vertices)
5. THE map controls SHALL be positioned to avoid overlap with mobile keyboards

