# Implementation Plan

- [x] 1. Set up data infrastructure and mock data
  - Create directory structure for GeoJSON files
  - Generate mock data for states, districts, and villages (Jharkhand focus)
  - Create sample GeoJSON files with realistic coordinates
  - _Requirements: 1.1, 6.5, 7.2_

- [x] 2. Implement backend API endpoints
- [x] 2.1 Create geo routes and controller structure
  - Create `server/routes/geo.js` with all route definitions
  - Create `server/controllers/geoController.js` with function stubs
  - Register geo routes in `server/app.js`
  - _Requirements: 7.3_

- [x] 2.2 Implement cache manager utility
  - Create `server/utils/cacheManager.js` with CacheManager class
  - Implement set, get, and clear methods with TTL support
  - Add cache statistics tracking
  - _Requirements: 4.3, 4.4_

- [x] 2.3 Implement getStates endpoint
  - Read states.json file
  - Implement caching logic
  - Return formatted response
  - _Requirements: 1.1, 4.3_

- [x] 2.4 Implement getDistricts endpoint
  - Read districts.json file
  - Filter by state_code parameter
  - Implement caching with state-specific keys
  - _Requirements: 1.2, 4.3_

- [x] 2.5 Implement getVillages endpoint
  - Read villages.json file
  - Filter by district_code parameter
  - Implement caching with district-specific keys
  - _Requirements: 1.3, 4.3_

- [x] 2.6 Implement search endpoint
  - Implement fuzzy search across all location types
  - Return top 10 results sorted by match score
  - Add debouncing on backend
  - _Requirements: 5.2, 5.3_

- [x] 3. Create frontend dropdown UI components
- [x] 3.1 Update HTML with dropdown structure
  - Add state, district, and village select elements to map page
  - Add loading spinners next to each dropdown
  - Add search bar with autocomplete container
  - Style dropdowns with consistent design
  - _Requirements: 1.1, 1.4, 8.1_

- [x] 3.2 Implement GeoDropdownManager class
  - Create class with properties for states, districts, villages
  - Implement loadStates() method
  - Implement loadDistricts(stateCode) method
  - Implement loadVillages(districtCode) method
  - Add event handlers for dropdown changes
  - _Requirements: 1.1, 1.2, 1.3_

- [x] 3.3 Implement dropdown change handlers
  - Handle state selection → load districts
  - Handle district selection → load villages
  - Handle village selection → trigger map update
  - Disable dependent dropdowns while loading
  - _Requirements: 1.2, 1.3, 8.4_

- [x] 3.4 Add loading states and animations
  - Show spinner during data fetch
  - Animate dropdown transitions with fade effect
  - Add visual confirmation on selection
  - _Requirements: 1.4, 8.1, 8.2, 8.3_

- [x] 4. Implement map integration
- [x] 4.1 Create MapIntegration class
  - Initialize class with map instance
  - Create properties for claim and boundary layers
  - Implement layer management methods
  - _Requirements: 2.1, 2.2_

- [x] 4.2 Implement Bhuvan satellite layer
  - Add ISRO Bhuvan WMS tile layer
  - Configure layer options and attribution
  - Set as default base layer
  - _Requirements: 2.3_

- [x] 4.3 Implement zoom to village functionality
  - Parse village geometry from API response
  - Calculate bounds from coordinates
  - Animate map zoom to bounds
  - _Requirements: 2.1, 2.4_

- [x] 4.4 Implement boundary highlighting
  - Add GeoJSON layer for village boundary
  - Style boundary with highlight color
  - Clear previous boundary on new selection
  - _Requirements: 2.4_

- [x] 4.5 Implement claim layer updates
  - Fetch claims for selected village
  - Filter and display claim markers/polygons
  - Color code by claim status
  - _Requirements: 2.2, 2.5, 3.2_

- [ ] 5. Implement data synchronization
- [ ] 5.1 Create claims fetch function
  - Call /api/claims with village filter
  - Handle response and errors
  - Trigger map and stats updates
  - _Requirements: 3.1_

- [ ] 5.2 Update map summary statistics
  - Calculate total claims, approval %, AI score
  - Update DOM elements with new values
  - Animate number changes
  - _Requirements: 3.2, 3.4_

- [ ] 5.3 Update claim types pie chart
  - Parse claim types from data
  - Update Chart.js pie chart
  - Animate chart transitions
  - _Requirements: 3.3_

- [ ] 5.4 Handle no data scenarios
  - Display "No data available" message
  - Show empty state UI
  - Provide helpful guidance
  - _Requirements: 3.5_

- [ ] 6. Implement caching and persistence
- [ ] 6.1 Implement localStorage cache for filters
  - Save selected state, district, village on change
  - Add timestamp to cache entries
  - _Requirements: 4.1_

- [ ] 6.2 Implement cache restoration on load
  - Read cached filters from localStorage
  - Restore dropdown selections
  - Trigger data load for cached selections
  - _Requirements: 4.2_

- [ ] 6.3 Implement API response caching
  - Cache states, districts, villages in localStorage
  - Set 24-hour expiry on cached data
  - Check cache before making API calls
  - _Requirements: 4.3, 4.4_

- [ ] 6.4 Add cache refresh functionality
  - Add refresh button to UI
  - Clear all cached data on click
  - Reload data from API
  - _Requirements: 4.5_

- [x] 7. Implement search functionality
- [x] 7.1 Create SearchBar class
  - Initialize with search input element
  - Set up event listeners
  - Create suggestions container
  - _Requirements: 5.1_

- [x] 7.2 Implement search with debouncing
  - Add 300ms debounce to search input
  - Call search API endpoint
  - Handle empty and error states
  - _Requirements: 5.2_

- [x] 7.3 Implement autocomplete suggestions
  - Display search results in dropdown
  - Highlight matching text
  - Handle keyboard navigation
  - _Requirements: 5.2_

- [x] 7.4 Implement result selection
  - Parse selected result
  - Auto-populate dropdowns
  - Trigger map zoom
  - _Requirements: 5.3, 5.4_

- [x] 7.5 Add fuzzy search support
  - Implement Levenshtein distance algorithm
  - Support partial matches
  - Rank results by relevance
  - _Requirements: 5.5_

- [ ] 8. Implement offline capability
- [ ] 8.1 Create GeoJSON file loader
  - Load states.geojson on app init
  - Load districts.geojson on app init
  - Load villages.geojson on app init
  - Store in memory for offline use
  - _Requirements: 6.1_

- [ ] 8.2 Implement offline detection
  - Listen for online/offline events
  - Update UI with offline indicator
  - Switch to cached data when offline
  - _Requirements: 6.2, 6.3_

- [ ] 8.3 Implement data sync on reconnection
  - Detect when connection is restored
  - Sync any pending updates
  - Refresh cached data
  - _Requirements: 6.4_

- [ ] 9. Add error handling and validation
- [ ] 9.1 Implement frontend error handling
  - Add try-catch blocks to all API calls
  - Display toast notifications for errors
  - Implement automatic retry logic
  - _Requirements: 1.5_

- [ ] 9.2 Implement backend validation
  - Validate state/district/village codes
  - Return appropriate error codes
  - Add input sanitization
  - _Requirements: 7.3_

- [ ] 9.3 Add error recovery mechanisms
  - Clear corrupted cache on error
  - Fallback to default selections
  - Provide user guidance
  - _Requirements: 1.5_

- [ ] 10. Implement responsive design
- [ ] 10.1 Add mobile-specific styles
  - Stack dropdowns vertically on mobile
  - Adjust map height for mobile
  - Make search bar full-width
  - _Requirements: 8.5_

- [ ] 10.2 Implement touch-friendly interactions
  - Increase dropdown item height to 44px
  - Add touch event handlers
  - Optimize for touch scrolling
  - _Requirements: 8.5_

- [ ] 11. Integration and testing
- [ ] 11.1 Test complete user flow
  - Test state → district → village selection
  - Verify map updates correctly
  - Verify statistics update
  - Test on multiple browsers
  - _Requirements: All_

- [ ] 11.2 Test caching functionality
  - Verify cache saves correctly
  - Verify cache restores on reload
  - Verify cache expiry works
  - Test cache refresh button
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

- [ ] 11.3 Test search functionality
  - Test autocomplete suggestions
  - Test result selection
  - Test fuzzy matching
  - Test keyboard navigation
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [ ] 11.4 Test offline mode
  - Disconnect network
  - Verify cached data loads
  - Verify offline indicator shows
  - Reconnect and verify sync
  - _Requirements: 6.1, 6.2, 6.3, 6.4_

- [ ] 11.5 Test error scenarios
  - Test with invalid codes
  - Test with network errors
  - Test with empty data
  - Verify error messages display
  - _Requirements: 1.5_

- [ ] 11.6 Performance testing
  - Measure state load time (< 500ms)
  - Measure district/village load time (< 2s)
  - Measure map zoom time (< 1s)
  - Measure search response time (< 300ms)
  - _Requirements: 1.1, 1.2, 1.3, 2.1, 5.2_
