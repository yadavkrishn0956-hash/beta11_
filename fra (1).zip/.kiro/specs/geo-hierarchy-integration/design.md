# Design Document: Geographic Hierarchy Integration

## Overview

The Geographic Hierarchy Integration system provides a seamless, hierarchical filtering mechanism for navigating India's administrative structure within the FRA Atlas application. The system consists of three main components: Frontend UI with cascading dropdowns, Backend API for data retrieval, and Map Integration for visual representation.

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Frontend (Browser)                       │
│  ┌────────────────┐  ┌──────────────┐  ┌─────────────────┐ │
│  │ Dropdown UI    │  │ Map View     │  │ Search Bar      │ │
│  │ - State        │  │ - Leaflet    │  │ - Autocomplete  │ │
│  │ - District     │──│ - Bhuvan     │──│ - Quick Nav     │ │
│  │ - Village      │  │ - Claim Layer│  │                 │ │
│  └────────────────┘  └──────────────┘  └─────────────────┘ │
│           │                  │                   │           │
│           └──────────────────┴───────────────────┘           │
│                              │                                │
└──────────────────────────────┼────────────────────────────────┘
                               │ HTTP/REST
┌──────────────────────────────┼────────────────────────────────┐
│                     Backend (Node.js)                         │
│  ┌────────────────┐  ┌──────────────┐  ┌─────────────────┐ │
│  │ Geo Routes     │  │ Geo Controller│  │ Cache Manager   │ │
│  │ /api/geo/*     │──│ - getStates  │──│ - Redis/Memory  │ │
│  │                │  │ - getDistricts│  │ - 24hr TTL      │ │
│  │                │  │ - getVillages │  │                 │ │
│  └────────────────┘  └──────────────┘  └─────────────────┘ │
│           │                  │                   │           │
│           └──────────────────┴───────────────────┘           │
│                              │                                │
└──────────────────────────────┼────────────────────────────────┘
                               │
┌──────────────────────────────┼────────────────────────────────┐
│                        Data Sources                           │
│  ┌────────────────┐  ┌──────────────┐  ┌─────────────────┐ │
│  │ data.gov.in    │  │ Local GeoJSON│  │ Claims Database │ │
│  │ API            │  │ Files        │  │ (PostgreSQL)    │ │
│  └────────────────┘  └──────────────┘  └─────────────────┘ │
└───────────────────────────────────────────────────────────────┘
```

### Data Flow

1. **Initial Load**: Frontend requests states → Backend returns cached/fresh data → Frontend populates dropdown
2. **State Selection**: User selects state → Frontend requests districts → Backend filters by state_code → Frontend updates district dropdown
3. **District Selection**: User selects district → Frontend requests villages → Backend filters by district_code → Frontend updates village dropdown
4. **Village Selection**: User selects village → Frontend requests claims → Map zooms to boundary → Statistics update

## Components and Interfaces

### 1. Frontend Components

#### GeoDropdownManager (JavaScript Class)

**Purpose**: Manages the state of all three dropdowns and coordinates data fetching

**Properties**:
```javascript
{
  states: Array<State>,
  districts: Array<District>,
  villages: Array<Village>,
  selectedState: State | null,
  selectedDistrict: District | null,
  selectedVillage: Village | null,
  isLoading: boolean,
  cache: LocalStorageCache
}
```

**Methods**:
- `loadStates()`: Fetches and populates states dropdown
- `loadDistricts(stateCode)`: Fetches districts for selected state
- `loadVillages(districtCode)`: Fetches villages for selected district
- `handleStateChange(stateCode)`: Event handler for state selection
- `handleDistrictChange(districtCode)`: Event handler for district selection
- `handleVillageChange(villageCode)`: Event handler for village selection
- `restoreFromCache()`: Restores last selected filters from localStorage
- `saveToCache()`: Saves current selection to localStorage

#### MapIntegration (JavaScript Class)

**Purpose**: Handles map updates, zoom, and layer management

**Properties**:
```javascript
{
  map: L.Map,
  claimLayer: L.GeoJSON,
  boundaryLayer: L.GeoJSON,
  currentBounds: L.LatLngBounds | null
}
```

**Methods**:
- `zoomToVillage(geometry)`: Zooms map to village boundary
- `updateClaimLayer(claims)`: Updates claim markers/polygons on map
- `highlightBoundary(geometry)`: Highlights selected village boundary
- `clearLayers()`: Removes all dynamic layers
- `addBhuvanLayer()`: Adds ISRO Bhuvan satellite base layer

#### SearchBar (JavaScript Class)

**Purpose**: Provides quick search and navigation functionality

**Properties**:
```javascript
{
  searchInput: HTMLInputElement,
  suggestions: Array<SearchResult>,
  debounceTimer: number
}
```

**Methods**:
- `handleSearch(query)`: Performs search with debouncing
- `showSuggestions(results)`: Displays autocomplete suggestions
- `selectResult(result)`: Navigates to selected location
- `clearSearch()`: Clears search input and suggestions

### 2. Backend Components

#### Geo Routes (`server/routes/geo.js`)

**Endpoints**:

```javascript
// Get all states
GET /api/geo/states
Response: {
  success: true,
  data: [
    {
      state_code: "JH",
      state_name: "Jharkhand",
      total_districts: 24,
      total_villages: 32620
    },
    ...
  ]
}

// Get districts by state
GET /api/geo/districts/:stateCode
Response: {
  success: true,
  data: [
    {
      district_code: "JH-DH",
      district_name: "Dhanbad",
      state_code: "JH",
      total_villages: 1456,
      geometry: { type: "Polygon", coordinates: [...] }
    },
    ...
  ]
}

// Get villages by district
GET /api/geo/villages/:districtCode
Response: {
  success: true,
  data: [
    {
      village_code: "JH-DH-001",
      village_name: "Jharia",
      district_code: "JH-DH",
      population: 12500,
      geometry: { type: "Polygon", coordinates: [...] }
    },
    ...
  ]
}

// Search locations
GET /api/geo/search?q=jharia
Response: {
  success: true,
  data: [
    {
      type: "village",
      village_code: "JH-DH-001",
      village_name: "Jharia",
      district_name: "Dhanbad",
      state_name: "Jharkhand",
      match_score: 0.95
    },
    ...
  ]
}
```

#### Geo Controller (`server/controllers/geoController.js`)

**Functions**:

```javascript
// Get all states
exports.getStates = async (req, res) => {
  // 1. Check cache
  // 2. If not cached, read from states.json
  // 3. Cache for 24 hours
  // 4. Return data
}

// Get districts by state code
exports.getDistricts = async (req, res) => {
  const { stateCode } = req.params;
  // 1. Check cache for this state
  // 2. If not cached, read from districts.json and filter
  // 3. Cache for 24 hours
  // 4. Return filtered data
}

// Get villages by district code
exports.getVillages = async (req, res) => {
  const { districtCode } = req.params;
  // 1. Check cache for this district
  // 2. If not cached, read from villages.json and filter
  // 3. Cache for 24 hours
  // 4. Return filtered data
}

// Search locations
exports.searchLocations = async (req, res) => {
  const { q } = req.query;
  // 1. Search across states, districts, villages
  // 2. Use fuzzy matching (Levenshtein distance)
  // 3. Return top 10 results sorted by match score
}
```

#### Cache Manager (`server/utils/cacheManager.js`)

**Purpose**: Manages in-memory caching with TTL

```javascript
class CacheManager {
  constructor() {
    this.cache = new Map();
  }

  set(key, value, ttl = 86400000) { // 24 hours default
    this.cache.set(key, {
      value,
      expires: Date.now() + ttl
    });
  }

  get(key) {
    const item = this.cache.get(key);
    if (!item) return null;
    if (Date.now() > item.expires) {
      this.cache.delete(key);
      return null;
    }
    return item.value;
  }

  clear() {
    this.cache.clear();
  }
}
```

### 3. Data Models

#### State Model
```javascript
{
  state_code: String,      // "JH"
  state_name: String,      // "Jharkhand"
  total_districts: Number, // 24
  total_villages: Number,  // 32620
  geometry: GeoJSON        // State boundary polygon
}
```

#### District Model
```javascript
{
  district_code: String,   // "JH-DH"
  district_name: String,   // "Dhanbad"
  state_code: String,      // "JH"
  total_villages: Number,  // 1456
  geometry: GeoJSON        // District boundary polygon
}
```

#### Village Model
```javascript
{
  village_code: String,    // "JH-DH-001"
  village_name: String,    // "Jharia"
  district_code: String,   // "JH-DH"
  population: Number,      // 12500
  geometry: GeoJSON        // Village boundary polygon
}
```

## Data Models

### GeoJSON Structure

All geographic data follows the GeoJSON specification:

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {
        "code": "JH-DH-001",
        "name": "Jharia",
        "type": "village"
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [
          [
            [86.4139, 23.7461],
            [86.4150, 23.7470],
            ...
          ]
        ]
      }
    }
  ]
}
```

### Local Storage Schema

```javascript
{
  "fra_geo_filters": {
    "selectedState": "JH",
    "selectedDistrict": "JH-DH",
    "selectedVillage": "JH-DH-001",
    "timestamp": 1706123456789
  },
  "fra_geo_cache": {
    "states": [...],
    "districts_JH": [...],
    "villages_JH-DH": [...],
    "expires": 1706209856789
  }
}
```

## Error Handling

### Frontend Error Handling

1. **Network Errors**: Display toast notification, retry once automatically
2. **Empty Data**: Show "No data available" message in dropdown
3. **Invalid Selection**: Reset dependent dropdowns and show warning
4. **Cache Corruption**: Clear cache and reload from API

### Backend Error Handling

1. **File Not Found**: Return 404 with helpful error message
2. **Invalid State/District Code**: Return 400 with validation error
3. **API Rate Limit**: Return 429 with retry-after header
4. **Server Error**: Return 500 with generic error message, log details

### Error Response Format

```javascript
{
  success: false,
  error: {
    code: "DISTRICT_NOT_FOUND",
    message: "District with code 'JH-XX' not found",
    details: "Please verify the district code and try again"
  }
}
```

## Testing Strategy

### Unit Tests

1. **GeoDropdownManager**:
   - Test state loading
   - Test district filtering by state
   - Test village filtering by district
   - Test cache save/restore

2. **MapIntegration**:
   - Test zoom to boundary
   - Test layer updates
   - Test boundary highlighting

3. **Backend Controllers**:
   - Test getStates returns all states
   - Test getDistricts filters correctly
   - Test getVillages filters correctly
   - Test search functionality

### Integration Tests

1. **Full Flow Test**:
   - Load states → Select state → Load districts → Select district → Load villages → Select village → Verify map updates

2. **Cache Test**:
   - Make API call → Verify cache → Make same call → Verify cache hit

3. **Offline Test**:
   - Disconnect network → Verify cached data loads → Verify offline indicator

### Performance Tests

1. **Load Time**: States should load in < 500ms
2. **Filter Time**: Districts/Villages should load in < 2s
3. **Map Zoom**: Should complete in < 1s
4. **Search**: Autocomplete should respond in < 300ms

## Implementation Notes

### Bhuvan Integration

ISRO's Bhuvan WMS service URL:
```javascript
const bhuvanLayer = L.tileLayer.wms('https://bhuvan-vec1.nrsc.gov.in/bhuvan/wms', {
  layers: 'india3',
  format: 'image/png',
  transparent: true,
  attribution: 'ISRO Bhuvan'
});
```

### Data Source Priority

1. **Primary**: In-memory cache (instant)
2. **Secondary**: Local GeoJSON files (< 100ms)
3. **Tertiary**: data.gov.in API (2-5s)

### Mobile Responsiveness

- Dropdowns stack vertically on screens < 768px
- Map height adjusts to 60vh on mobile
- Search bar becomes full-width on mobile
- Touch-friendly dropdown items (min 44px height)

## Security Considerations

1. **Input Validation**: Sanitize all state/district/village codes
2. **Rate Limiting**: Max 100 requests per minute per IP
3. **CORS**: Restrict to allowed origins only
4. **XSS Prevention**: Escape all user-generated content
5. **SQL Injection**: Use parameterized queries (if using database)

## Performance Optimization

1. **Lazy Loading**: Load villages only when district is selected
2. **Debouncing**: Search input debounced to 300ms
3. **Compression**: Gzip all API responses
4. **CDN**: Serve GeoJSON files from CDN if possible
5. **Pagination**: Limit villages to 1000 per request, implement pagination if needed
