# 🎯 Quick Reference Card

## 🚀 Start Application

```bash
# Already running at:
Frontend: http://localhost:3000
Backend:  http://localhost:5001
```

---

## 📝 Create New Claim (3 Steps)

### Step 1: Draw Polygon
```
Map Page → "Draw Claim" Button → Click points on map → Close polygon
```

### Step 2: Auto-Fill Happens
```
✅ Area (Hectares)    → Auto-calculated
✅ Latitude           → Auto-filled
✅ Longitude          → Auto-filled
✅ State              → Auto-filled
✅ District           → Auto-filled
```

### Step 3: Fill & Submit
```
✏️ Claimant Name     → Type name
✏️ Claim Type        → Select IFR/CFR/CR
✏️ Village           → Select from dropdown
✏️ Notes (optional)  → Add notes
🚀 Submit Claim      → Click button
```

---

## 📋 Form Fields Reference

| Field | Type | Auto-Fill? | Required? |
|-------|------|-----------|-----------|
| Claimant Name | Text | ❌ | ✅ |
| Claim Type | Dropdown | ❌ | ✅ |
| State | Text | ✅ | ✅ |
| District | Text | ✅ | ✅ |
| Village | Dropdown | ❌ | ✅ |
| Area (Hectares) | Number | ✅ | ✅ |
| Latitude | Number | ✅ | ❌ |
| Longitude | Number | ✅ | ❌ |
| Linked Scheme | Dropdown | ❌ | ❌ |
| Notes | Textarea | ❌ | ❌ |

---

## 🗺️ Where Claims Appear

```
After Submit:
├── Map View (Yellow Polygon)
├── Claims Page (Table Row)
└── Review Section (Review Table) ← NEW!
```

---

## 🔧 Troubleshooting

| Problem | Solution |
|---------|----------|
| Form cut off | Zoom to 100% |
| Auto-fill not working | Check internet |
| Claim not showing | Refresh page |
| Geocoding fails | Uses default values |

---

## 📞 Quick Commands

```bash
# Check status
curl http://localhost:3000
curl http://localhost:5001/api/health

# View logs
tail -f logs/backend.log

# Stop services
./stop-all.sh

# Restart services
./start-all.sh
```

---

## ✅ Success Checklist

- [ ] Form opens completely
- [ ] Area auto-fills
- [ ] Lat/Lng auto-fills
- [ ] State/District auto-fills
- [ ] Can submit form
- [ ] Claim shows on map
- [ ] Claim shows in Claims page
- [ ] Claim shows in Review section

---

## 🎯 Key URLs

```
Main App:     http://localhost:3000/index.html
Map Page:     http://localhost:3000/index.html#map
Claims Page:  http://localhost:3000/index.html#claims
Review Page:  http://localhost:3000/index.html#review
Backend API:  http://localhost:5001
Health Check: http://localhost:5001/api/health
```

---

## 📊 Auto-Fill Example

```javascript
// When you draw polygon, form fills:
{
  area_ha: 573434.80,        // Calculated
  latitude: 21.234567,       // Center point
  longitude: 80.123456,      // Center point
  state: "Madhya Pradesh",   // Geocoded
  district: "Balaghat"       // Geocoded
}
```

---

## 🌟 Features

✅ Complete form visibility  
✅ 5 auto-filled fields  
✅ Reverse geocoding  
✅ Review section integration  
✅ Accurate coordinates  
✅ Fast submission (2 min)  

---

**Version**: 2.0  
**Status**: ✅ Working  
**Date**: Nov 5, 2025
