#!/bin/bash

echo "🚀 Starting FRA Atlas Application..."
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if backend is already running
if lsof -Pi :5001 -sTCP:LISTEN -t >/dev/null ; then
    echo -e "${YELLOW}⚠️  Backend server is already running on port 5001${NC}"
else
    echo "📦 Starting Backend Server..."
    cd server
    npm start &
    BACKEND_PID=$!
    cd ..
    echo -e "${GREEN}✅ Backend server started (PID: $BACKEND_PID)${NC}"
    sleep 3
fi

# Check if frontend is already running
if lsof -Pi :8080 -sTCP:LISTEN -t >/dev/null ; then
    echo -e "${YELLOW}⚠️  Frontend server is already running on port 8080${NC}"
else
    echo "🌐 Starting Frontend Server..."
    python3 -m http.server 8080 &
    FRONTEND_PID=$!
    echo -e "${GREEN}✅ Frontend server started (PID: $FRONTEND_PID)${NC}"
    sleep 2
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${GREEN}✨ FRA Atlas Application is Ready!${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📍 Access Points:"
echo "   🌐 Main Application:    http://localhost:8080"
echo "   🧪 Backend Test Page:   http://localhost:8080/test-backend.html"
echo "   🔧 Backend API:         http://localhost:5001"
echo "   📊 API Health Check:    http://localhost:5001/api/health"
echo ""
echo "📝 Quick Links:"
echo "   • Dashboard:            http://localhost:8080/index.html#dashboard"
echo "   • Map View:             http://localhost:8080/index.html#map"
echo "   • Claims:               http://localhost:8080/index.html#claims"
echo "   • DSS:                  http://localhost:8080/index.html#dss"
echo "   • Reports:              http://localhost:8080/index.html#reports"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "💡 Tips:"
echo "   • Press Ctrl+C to stop all servers"
echo "   • Check backend status at test page first"
echo "   • Database is using mock data (PostgreSQL not configured)"
echo ""

# Wait for user interrupt
wait
