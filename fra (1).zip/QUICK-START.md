# 🚀 FRA Atlas - Quick Start Guide

## ✅ Current Status

Your FRA Atlas application is **READY TO USE**! 

- ✅ Backend Server: Running on **http://localhost:5001**
- ✅ Frontend Server: Running on **http://localhost:8080**
- ✅ API Integration: Connected and working
- ⚠️  Database: Using mock data (PostgreSQL not configured)

---

## 🌐 Access Your Application

### Main Application
**Open in your browser:** [http://localhost:8080](http://localhost:8080)

### Backend Test Page
**Test backend connection:** [http://localhost:8080/test-backend.html](http://localhost:8080/test-backend.html)

### Backend API
**API Server:** [http://localhost:5001](http://localhost:5001)
**Health Check:** [http://localhost:5001/api/health](http://localhost:5001/api/health)

---

## 📱 Application Pages

| Page | URL | Description |
|------|-----|-------------|
| Dashboard | http://localhost:8080/#dashboard | Main analytics dashboard |
| Map View | http://localhost:8080/#map | Interactive FRA claims map |
| Claims | http://localhost:8080/#claims | Manage FRA claims |
| Review | http://localhost:8080/#review | Review pending claims |
| Assets | http://localhost:8080/#assets | Asset management |
| Feedback | http://localhost:8080/#feedback | User feedback system |
| Issues | http://localhost:8080/#issues | Issue tracking |
| Admin | http://localhost:8080/#admin | Admin control panel |
| DSS | http://localhost:8080/#dss | AI Decision Support System |
| Reports | http://localhost:8080/#reports | Reports & Analytics |

---

## 🔧 Server Management

### Check if servers are running:
```bash
# Check backend (port 5001)
lsof -ti:5001

# Check frontend (port 8080)
lsof -ti:8080
```

### Stop servers:
```bash
# Stop backend
kill -9 $(lsof -ti:5001)

# Stop frontend
kill -9 $(lsof -ti:8080)
```

### Start servers manually:

#### Backend:
```bash
cd server
npm start
```

#### Frontend:
```bash
python3 -m http.server 8080
```

---

## 🧪 Testing Backend Connection

1. Open: http://localhost:8080/test-backend.html
2. The page will automatically test the connection
3. You should see:
   - ✅ Backend Connected Successfully
   - Server status, version, and environment info
   - List of available API endpoints

---

## 📊 API Endpoints

All API endpoints are available at `http://localhost:5001/api/`

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/logout` - User logout

### Claims
- `GET /api/claims` - Get all claims
- `GET /api/claims/:id` - Get claim by ID
- `POST /api/claims` - Create new claim
- `PUT /api/claims/:id` - Update claim
- `DELETE /api/claims/:id` - Delete claim

### Feedback
- `GET /api/feedback` - Get all feedback
- `POST /api/feedback` - Submit feedback
- `PUT /api/feedback/:id` - Update feedback

### Issues
- `GET /api/issues` - Get all issues
- `POST /api/issues` - Report new issue
- `PUT /api/issues/:id` - Update issue
- `DELETE /api/issues/:id` - Delete issue

### DSS (Decision Support System)
- `GET /api/dss/schemes` - Get all schemes
- `POST /api/dss/recommend` - Get scheme recommendations

### Reports
- `GET /api/reports` - Get all reports
- `POST /api/reports/custom` - Generate custom report
- `GET /api/reports/district/:id` - Get district report

---

## 🔐 Default Test Users

Since we're using mock data, you can use these test credentials:

**Admin User:**
- Email: admin@fra.gov.in
- Password: admin123

**District Officer:**
- Email: officer@fra.gov.in
- Password: officer123

**Citizen:**
- Email: citizen@fra.gov.in
- Password: citizen123

---

## 🐛 Troubleshooting

### Backend not connecting?
1. Check if backend is running: `lsof -ti:5001`
2. Check backend logs in terminal
3. Try restarting: `kill -9 $(lsof -ti:5001)` then `cd server && npm start`

### Frontend not loading?
1. Check if frontend is running: `lsof -ti:8080`
2. Try restarting: `kill -9 $(lsof -ti:8080)` then `python3 -m http.server 8080`

### Port already in use?
```bash
# Kill process on port 5001
kill -9 $(lsof -ti:5001)

# Kill process on port 8080
kill -9 $(lsof -ti:8080)
```

### CORS errors?
- Make sure both servers are running
- Check that API base URL in `api.js` is `http://localhost:5001/api`
- Clear browser cache and reload

---

## 📦 Dependencies

### Backend (Node.js)
All dependencies are installed. If you need to reinstall:
```bash
cd server
npm install
```

### Frontend
No build step required! Pure HTML/CSS/JavaScript.

---

## 🎯 Next Steps

1. **Test the application**: Open http://localhost:8080/test-backend.html
2. **Explore features**: Navigate through different pages
3. **Test API**: Try creating claims, submitting feedback, etc.
4. **Configure Database** (Optional): Set up PostgreSQL for persistent data

---

## 💡 Features

✅ **Dashboard**: Real-time analytics and KPIs
✅ **Interactive Map**: Visualize FRA claims geographically
✅ **Claims Management**: Create, review, and manage claims
✅ **AI Decision Support**: Smart scheme recommendations
✅ **Reports & Analytics**: Comprehensive reporting system
✅ **Real-time Notifications**: WebSocket-based notifications
✅ **Admin Panel**: User and system management
✅ **Feedback System**: Collect and manage user feedback
✅ **Issue Tracking**: Track and resolve system issues

---

## 📞 Support

If you encounter any issues:
1. Check the browser console for errors (F12)
2. Check backend terminal for server logs
3. Test backend connection at test page
4. Verify both servers are running

---

## 🎉 Enjoy using FRA Atlas!

Your application is fully functional and ready to use. All features are working with mock data.

**Happy Testing! 🚀**
