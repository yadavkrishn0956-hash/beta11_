/**
 * AI Service Integration Utility
 * Connects Node.js backend with Python FastAPI AI microservice
 */

const axios = require('axios');

class AIServiceClient {
    constructor() {
        this.baseURL = process.env.AI_SERVICE_URL || 'http://localhost:8000';
        this.timeout = 30000; // 30 seconds timeout
        this.retryAttempts = 3;
        
        // Create axios instance
        this.client = axios.create({
            baseURL: this.baseURL,
            timeout: this.timeout,
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        // Add request interceptor for logging
        this.client.interceptors.request.use(
            (config) => {
                console.log(`🤖 AI Service Request: ${config.method?.toUpperCase()} ${config.url}`);
                return config;
            },
            (error) => {
                console.error('AI Service Request Error:', error);
                return Promise.reject(error);
            }
        );
        
        // Add response interceptor for logging
        this.client.interceptors.response.use(
            (response) => {
                console.log(`✅ AI Service Response: ${response.status} - ${response.config.url}`);
                return response;
            },
            (error) => {
                console.error(`❌ AI Service Error: ${error.response?.status} - ${error.config?.url}`);
                return Promise.reject(error);
            }
        );
    }
    
    /**
     * Check if AI service is healthy
     */
    async healthCheck() {
        try {
            const response = await this.client.get('/health');
            return {
                success: true,
                data: response.data,
                status: 'healthy'
            };
        } catch (error) {
            console.error('AI Service health check failed:', error.message);
            return {
                success: false,
                error: error.message,
                status: 'unhealthy'
            };
        }
    }
    
    /**
     * Get scheme recommendations from AI service
     */
    async getRecommendations(claimData) {
        try {
            // Validate required fields
            const requiredFields = ['land_area', 'forest_cover', 'water_index', 'soil_quality', 'state', 'district'];
            const missingFields = requiredFields.filter(field => !claimData[field]);
            
            if (missingFields.length > 0) {
                throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
            }
            
            // Prepare data for AI service
            const aiRequestData = {
                claim_id: claimData.claim_id || null,
                land_area: parseFloat(claimData.land_area),
                forest_cover: parseFloat(claimData.forest_cover || 50),
                water_index: parseFloat(claimData.water_index || 0.5),
                soil_quality: claimData.soil_quality || 'good',
                state: claimData.state,
                district: claimData.district,
                village: claimData.village || null,
                claim_type: claimData.claim_type || 'IFR',
                tribal_area: claimData.tribal_area !== false, // Default to true
                employment_needed: claimData.employment_needed === true,
                housing_needed: claimData.housing_needed === true,
                latitude: claimData.latitude ? parseFloat(claimData.latitude) : null,
                longitude: claimData.longitude ? parseFloat(claimData.longitude) : null
            };
            
            console.log('🧠 Sending data to AI service:', JSON.stringify(aiRequestData, null, 2));
            
            const response = await this.client.post('/recommend', aiRequestData);
            
            return {
                success: true,
                data: response.data,
                processing_time: response.data.processing_time_ms
            };
            
        } catch (error) {
            console.error('AI recommendation error:', error.message);
            
            // Return fallback recommendations if AI service fails
            return this.getFallbackRecommendations(claimData, error.message);
        }
    }
    
    /**
     * Verify claim using AI service
     */
    async verifyClaim(claimData) {
        try {
            const verificationData = {
                claim_id: claimData.claim_id || claimData.id,
                applicant_name: claimData.applicant_name,
                land_area: parseFloat(claimData.land_area),
                forest_cover: parseFloat(claimData.forest_cover || 50),
                coordinates: claimData.latitude && claimData.longitude ? {
                    latitude: parseFloat(claimData.latitude),
                    longitude: parseFloat(claimData.longitude)
                } : null,
                documents: claimData.documents || []
            };
            
            const response = await this.client.post('/verify', verificationData);
            
            return {
                success: true,
                data: response.data
            };
            
        } catch (error) {
            console.error('AI verification error:', error.message);
            
            return {
                success: false,
                error: error.message,
                data: {
                    claim_id: claimData.claim_id || claimData.id,
                    verification_status: 'error',
                    confidence: 0.0,
                    issues_found: [`AI verification failed: ${error.message}`],
                    recommendations: ['Manual verification required']
                }
            };
        }
    }
    
    /**
     * Process multiple claims for recommendations
     */
    async batchRecommendations(claimsArray) {
        try {
            const response = await this.client.post('/recommend/batch', claimsArray);
            
            return {
                success: true,
                data: response.data
            };
            
        } catch (error) {
            console.error('AI batch processing error:', error.message);
            
            return {
                success: false,
                error: error.message,
                data: {
                    total_processed: claimsArray.length,
                    successful: 0,
                    failed: claimsArray.length,
                    results: claimsArray.map(claim => ({
                        claim_id: claim.claim_id,
                        status: 'error',
                        error: error.message
                    }))
                }
            };
        }
    }
    
    /**
     * Get AI service analytics
     */
    async getAnalytics() {
        try {
            const response = await this.client.get('/analytics');
            
            return {
                success: true,
                data: response.data
            };
            
        } catch (error) {
            console.error('AI analytics error:', error.message);
            
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    /**
     * Get model status
     */
    async getModelStatus() {
        try {
            const response = await this.client.get('/models/status');
            
            return {
                success: true,
                data: response.data
            };
            
        } catch (error) {
            console.error('AI model status error:', error.message);
            
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    /**
     * Fallback recommendations when AI service is unavailable
     */
    getFallbackRecommendations(claimData, errorMessage) {
        console.log('🔄 Using fallback recommendations due to AI service error');
        
        const fallbackSchemes = [];
        const landArea = parseFloat(claimData.land_area || 0);
        const waterIndex = parseFloat(claimData.water_index || 0.5);
        const soilQuality = (claimData.soil_quality || 'good').toLowerCase();
        const forestCover = parseFloat(claimData.forest_cover || 50);
        
        // Simple rule-based fallback
        if (landArea <= 3.0) {
            fallbackSchemes.push({
                scheme_name: 'PM-KISAN',
                scheme_code: 'PM_KISAN',
                description: 'Pradhan Mantri Kisan Samman Nidhi Yojana',
                eligibility_score: 90,
                priority: 'high',
                benefits: 'Rs. 6000 per year in three installments',
                ministry: 'Ministry of Agriculture and Farmers Welfare',
                application_process: 'Online through PM-KISAN portal',
                estimated_benefit: 'Rs. 6,000/year',
                confidence: 0.9
            });
        }
        
        if (waterIndex <= 0.4) {
            fallbackSchemes.push({
                scheme_name: 'Jal Jeevan Mission',
                scheme_code: 'JJM',
                description: 'Providing tap water connection to every household',
                eligibility_score: 85,
                priority: 'high',
                benefits: 'Functional household tap connection',
                ministry: 'Ministry of Jal Shakti',
                application_process: 'Through Gram Panchayat',
                estimated_benefit: 'Tap water connection',
                confidence: 0.85
            });
        }
        
        if (soilQuality === 'poor' || soilQuality === 'degraded') {
            fallbackSchemes.push({
                scheme_name: 'MGNREGA',
                scheme_code: 'MGNREGA',
                description: 'Employment guarantee and land development',
                eligibility_score: 80,
                priority: 'medium',
                benefits: '100 days guaranteed employment',
                ministry: 'Ministry of Rural Development',
                application_process: 'Job card registration at Gram Panchayat',
                estimated_benefit: 'Rs. 200-300/day for 100 days',
                confidence: 0.8
            });
        }
        
        if (forestCover >= 70) {
            fallbackSchemes.push({
                scheme_name: 'Green India Mission',
                scheme_code: 'GIM',
                description: 'Forest conservation and enhancement',
                eligibility_score: 75,
                priority: 'medium',
                benefits: 'Forest conservation support',
                ministry: 'Ministry of Environment, Forest and Climate Change',
                application_process: 'Through Forest Department',
                estimated_benefit: 'Conservation incentives',
                confidence: 0.75
            });
        }
        
        return {
            success: true,
            data: {
                claim_id: claimData.claim_id,
                total_schemes: fallbackSchemes.length,
                schemes: fallbackSchemes,
                priority: fallbackSchemes.length >= 2 ? 'high' : 'medium',
                confidence_score: 0.7,
                processing_time_ms: 50,
                recommendation_date: new Date().toISOString(),
                ai_insights: [
                    '⚠️ AI service temporarily unavailable - using rule-based recommendations',
                    '🔄 Recommendations generated using fallback logic'
                ],
                next_steps: [
                    'Review eligible schemes and their requirements',
                    'Gather required documents',
                    'Visit nearest service center for applications'
                ]
            },
            fallback: true,
            ai_error: errorMessage
        };
    }
    
    /**
     * Retry mechanism for failed requests
     */
    async retryRequest(requestFn, maxRetries = 3) {
        let lastError;
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                return await requestFn();
            } catch (error) {
                lastError = error;
                console.log(`Attempt ${attempt} failed, retrying...`);
                
                if (attempt < maxRetries) {
                    // Exponential backoff
                    await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
                }
            }
        }
        
        throw lastError;
    }
}

// Create singleton instance
const aiServiceClient = new AIServiceClient();

module.exports = {
    aiServiceClient,
    AIServiceClient
};