const PDFDocument = require('pdfkit');
const fs = require('fs');

/**
 * Generate PDF Report
 * @param {Object} reportData - Report data to include in PDF
 * @param {String} startDate - Report start date
 * @param {String} endDate - Report end date
 * @returns {Buffer} PDF buffer
 */
async function generatePDFReport(reportData, startDate, endDate) {
    return new Promise((resolve, reject) => {
        try {
            const doc = new PDFDocument({ margin: 50 });
            const chunks = [];

            // Collect PDF data
            doc.on('data', chunk => chunks.push(chunk));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);

            // Header
            doc.fontSize(20)
               .fillColor('#2c5f2d')
               .text('FRA Atlas & DSS', { align: 'center' })
               .fontSize(16)
               .text('Comprehensive Report', { align: 'center' })
               .moveDown();

            // Report Period
            doc.fontSize(12)
               .fillColor('#000')
               .text(`Report Period: ${startDate} to ${endDate}`, { align: 'center' })
               .moveDown(2);

            // Summary Section
            doc.fontSize(14)
               .fillColor('#2c5f2d')
               .text('Executive Summary', { underline: true })
               .moveDown(0.5);

            doc.fontSize(11)
               .fillColor('#000')
               .text(`Total Claims Filed: ${reportData.totalClaims || 0}`)
               .text(`Approved Claims: ${reportData.approvedClaims || 0}`)
               .text(`Pending Claims: ${reportData.pendingClaims || 0}`)
               .text(`Rejected Claims: ${reportData.rejectedClaims || 0}`)
               .text(`Average Processing Time: ${reportData.avgProcessingDays || 0} days`)
               .moveDown(2);

            // District Performance
            if (reportData.districtPerformance && reportData.districtPerformance.length > 0) {
                doc.fontSize(14)
                   .fillColor('#2c5f2d')
                   .text('District Performance', { underline: true })
                   .moveDown(0.5);

                reportData.districtPerformance.forEach((district, index) => {
                    doc.fontSize(11)
                       .fillColor('#000')
                       .text(`${index + 1}. ${district.district}`)
                       .text(`   Filed: ${district.filed}, Approved: ${district.approved}, Pending: ${district.pending}`)
                       .text(`   Avg Processing: ${district.avgDays} days`)
                       .moveDown(0.5);
                });

                doc.moveDown();
            }

            // Scheme Impact
            if (reportData.schemeImpact && reportData.schemeImpact.length > 0) {
                doc.fontSize(14)
                   .fillColor('#2c5f2d')
                   .text('Scheme Impact Analysis', { underline: true })
                   .moveDown(0.5);

                reportData.schemeImpact.forEach((scheme, index) => {
                    doc.fontSize(11)
                       .fillColor('#000')
                       .text(`${index + 1}. ${scheme.scheme}`)
                       .text(`   Beneficiaries: ${scheme.beneficiaries}`)
                       .text(`   Budget: ${scheme.budget}`)
                       .text(`   Coverage: ${scheme.coverage}%`)
                       .moveDown(0.5);
                });
            }

            // Footer
            doc.fontSize(9)
               .fillColor('#666')
               .text(
                   `Generated on: ${new Date().toLocaleString()}`,
                   50,
                   doc.page.height - 50,
                   { align: 'center' }
               );

            doc.end();

        } catch (error) {
            reject(error);
        }
    });
}

module.exports = { generatePDFReport };
