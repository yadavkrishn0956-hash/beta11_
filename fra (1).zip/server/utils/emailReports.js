const nodemailer = require('nodemailer');
const { generatePDFReport } = require('./pdfGenerator');
const { generateExcelReport } = require('./excelGenerator');

/**
 * Create email transporter
 * For demo, using Gmail. In production, use official government SMTP
 */
function createTransporter() {
    // FOR DEMO: Using basic SMTP
    // In production, use OAuth2 or government email server
    return nodemailer.createTransporter({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: process.env.SMTP_PORT || 587,
        secure: false,
        auth: {
            user: process.env.EMAIL_USER || 'fra.atlas@example.com',
            pass: process.env.EMAIL_PASS || 'demo_password'
        }
    });
}

/**
 * Send report via email
 * @param {String} recipientEmail - Email address to send to
 * @param {String} format - 'pdf' or 'excel'
 * @param {Object} reportData - Report data
 * @param {String} startDate - Start date
 * @param {String} endDate - End date
 */
async function sendReportEmail(recipientEmail, format, reportData, startDate, endDate) {
    try {
        const transporter = createTransporter();
        
        // Generate report file
        let attachment;
        let filename;
        
        if (format === 'pdf') {
            attachment = await generatePDFReport(reportData, startDate, endDate);
            filename = `FRA_Report_${startDate}_${endDate}.pdf`;
        } else {
            attachment = await generateExcelReport(reportData, startDate, endDate);
            filename = `FRA_Report_${startDate}_${endDate}.xlsx`;
        }
        
        // Email options
        const mailOptions = {
            from: process.env.EMAIL_USER || 'fra.atlas@example.com',
            to: recipientEmail,
            subject: `FRA Atlas Report - ${startDate} to ${endDate}`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #2c5f2d;">FRA Atlas & Decision Support System</h2>
                    <p>Dear Officer,</p>
                    <p>Please find attached the FRA Atlas comprehensive report for the period <strong>${startDate}</strong> to <strong>${endDate}</strong>.</p>
                    
                    <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">Report Summary:</h3>
                        <ul>
                            <li>Total Claims: ${reportData.totalClaims || 0}</li>
                            <li>Approved: ${reportData.approvedClaims || 0}</li>
                            <li>Pending: ${reportData.pendingClaims || 0}</li>
                            <li>Rejected: ${reportData.rejectedClaims || 0}</li>
                        </ul>
                    </div>
                    
                    <p>For more details, please refer to the attached ${format.toUpperCase()} report.</p>
                    
                    <p style="color: #666; font-size: 12px; margin-top: 30px;">
                        This is an automated email from FRA Atlas DSS v2.0<br>
                        Ministry of Tribal Affairs, Government of India
                    </p>
                </div>
            `,
            attachments: [
                {
                    filename: filename,
                    content: attachment
                }
            ]
        };
        
        // Send email
        const info = await transporter.sendMail(mailOptions);
        
        console.log(`✅ Report email sent to ${recipientEmail}: ${info.messageId}`);
        return { success: true, messageId: info.messageId };
        
    } catch (error) {
        console.error('❌ Error sending report email:', error);
        throw error;
    }
}

/**
 * Send weekly reports to all district officers
 * Called by cron job every Sunday
 */
async function sendWeeklyReports() {
    try {
        console.log('📧 Starting weekly report distribution...');
        
        // FOR DEMO: Mock district officers
        // In production, fetch from database
        const districtOfficers = [
            { email: 'district.ranchi@mp.gov.in', district: 'Ranchi' },
            { email: 'district.dhanbad@mp.gov.in', district: 'Dhanbad' },
            { email: 'district.hazaribagh@mp.gov.in', district: 'Hazaribagh' }
        ];
        
        // Calculate last week dates
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - 7);
        
        const startDateStr = startDate.toISOString().split('T')[0];
        const endDateStr = endDate.toISOString().split('T')[0];
        
        // Mock report data
        const reportData = {
            totalClaims: 150,
            approvedClaims: 95,
            pendingClaims: 40,
            rejectedClaims: 15,
            avgProcessingDays: 12,
            districtPerformance: [
                { district: 'Ranchi', filed: 50, approved: 32, pending: 15, avgDays: 10 },
                { district: 'Dhanbad', filed: 60, approved: 38, pending: 18, avgDays: 11 },
                { district: 'Hazaribagh', filed: 40, approved: 25, pending: 7, avgDays: 14 }
            ]
        };
        
        // Send to each officer
        for (const officer of districtOfficers) {
            try {
                await sendReportEmail(
                    officer.email,
                    'pdf',
                    reportData,
                    startDateStr,
                    endDateStr
                );
                console.log(`✅ Weekly report sent to ${officer.district}`);
            } catch (error) {
                console.error(`❌ Failed to send report to ${officer.district}:`, error.message);
            }
        }
        
        console.log('✅ Weekly report distribution completed');
        
    } catch (error) {
        console.error('❌ Error in weekly report distribution:', error);
    }
}

module.exports = {
    sendReportEmail,
    sendWeeklyReports
};
