/**
 * Real-time Notifications Utility
 * Helper functions for broadcasting notifications via Socket.IO
 */

// Notification types
const NOTIFICATION_TYPES = {
    CLAIM_UPDATE: 'claimUpdate',
    NEW_FEEDBACK: 'newFeedback',
    REPORT_GENERATED: 'reportGenerated',
    ISSUE_RESOLVED: 'issueResolved',
    USER_LOGIN: 'userLogin',
    AI_RECOMMENDATION: 'aiRecommendation',
    SYSTEM_ALERT: 'systemAlert',
    DOCUMENT_UPLOADED: 'documentUploaded',
    VERIFICATION_COMPLETE: 'verificationComplete'
};

// Notification priorities
const PRIORITIES = {
    LOW: 'low',
    MEDIUM: 'medium',
    HIGH: 'high',
    URGENT: 'urgent'
};

// Role-based notification targets
const ROLE_TARGETS = {
    CITIZEN: ['citizen'],
    OFFICERS: ['district', 'state'],
    DISTRICT: ['district'],
    STATE: ['state'],
    ADMIN: ['admin'],
    ALL: ['citizen', 'district', 'state', 'admin']
};

/**
 * Create and broadcast a claim update notification
 */
function notifyClaimUpdate(req, claimData, status, message) {
    const broadcastNotification = req.app.get('broadcastNotification');
    
    if (!broadcastNotification) return;
    
    const notification = {
        type: NOTIFICATION_TYPES.CLAIM_UPDATE,
        title: 'Claim Status Update',
        message: message || `Claim ${claimData.claim_number || claimData.id} has been ${status}`,
        priority: status === 'approved' ? PRIORITIES.HIGH : PRIORITIES.MEDIUM,
        data: {
            claimId: claimData.id,
            claimNumber: claimData.claim_number,
            applicantName: claimData.applicant_name,
            status: status,
            district: claimData.district,
            state: claimData.state
        },
        targetRoles: [
            ...ROLE_TARGETS.OFFICERS,
            ...(claimData.user_id ? [] : ROLE_TARGETS.CITIZEN)
        ],
        userId: claimData.user_id, // Notify the claim owner
        district: claimData.district,
        state: claimData.state,
        icon: 'file-text',
        color: status === 'approved' ? 'success' : status === 'rejected' ? 'error' : 'info'
    };
    
    broadcastNotification(notification);
}

/**
 * Create and broadcast a new feedback notification
 */
function notifyNewFeedback(req, feedbackData) {
    const broadcastNotification = req.app.get('broadcastNotification');
    
    if (!broadcastNotification) return;
    
    const notification = {
        type: NOTIFICATION_TYPES.NEW_FEEDBACK,
        title: 'New Feedback Received',
        message: `New ${feedbackData.category} feedback: "${feedbackData.subject}"`,
        priority: feedbackData.priority === 'urgent' ? PRIORITIES.URGENT : PRIORITIES.MEDIUM,
        data: {
            feedbackId: feedbackData.id,
            category: feedbackData.category,
            subject: feedbackData.subject,
            rating: feedbackData.rating,
            priority: feedbackData.priority
        },
        targetRoles: ROLE_TARGETS.OFFICERS,
        icon: 'message-circle',
        color: 'info'
    };
    
    broadcastNotification(notification);
}

/**
 * Create and broadcast a report generated notification
 */
function notifyReportGenerated(req, reportData) {
    const broadcastNotification = req.app.get('broadcastNotification');
    
    if (!broadcastNotification) return;
    
    const notification = {
        type: NOTIFICATION_TYPES.REPORT_GENERATED,
        title: 'Report Generated',
        message: `${reportData.title} is ready for download`,
        priority: PRIORITIES.MEDIUM,
        data: {
            reportId: reportData.id,
            title: reportData.title,
            type: reportData.report_type,
            downloadUrl: reportData.download_url
        },
        targetRoles: ROLE_TARGETS.OFFICERS,
        userId: reportData.generated_by,
        icon: 'download',
        color: 'success'
    };
    
    broadcastNotification(notification);
}

/**
 * Create and broadcast an issue resolved notification
 */
function notifyIssueResolved(req, issueData) {
    const broadcastNotification = req.app.get('broadcastNotification');
    
    if (!broadcastNotification) return;
    
    const notification = {
        type: NOTIFICATION_TYPES.ISSUE_RESOLVED,
        title: 'Issue Resolved',
        message: `Issue "${issueData.title}" has been resolved`,
        priority: issueData.priority === 'critical' ? PRIORITIES.HIGH : PRIORITIES.MEDIUM,
        data: {
            issueId: issueData.id,
            title: issueData.title,
            category: issueData.category,
            resolution: issueData.resolution
        },
        targetRoles: ROLE_TARGETS.ALL,
        userId: issueData.reported_by,
        icon: 'check-circle',
        color: 'success'
    };
    
    broadcastNotification(notification);
}

/**
 * Create and broadcast an AI recommendation notification
 */
function notifyAIRecommendation(req, claimData, recommendationData) {
    const broadcastNotification = req.app.get('broadcastNotification');
    
    if (!broadcastNotification) return;
    
    const schemeCount = recommendationData.total_schemes || recommendationData.schemes?.length || 0;
    
    const notification = {
        type: NOTIFICATION_TYPES.AI_RECOMMENDATION,
        title: 'AI Recommendations Ready',
        message: `${schemeCount} eligible schemes found for claim ${claimData.claim_number || claimData.claim_id}`,
        priority: schemeCount >= 3 ? PRIORITIES.HIGH : PRIORITIES.MEDIUM,
        data: {
            claimId: claimData.claim_id,
            claimNumber: claimData.claim_number,
            schemeCount: schemeCount,
            priority: recommendationData.priority,
            confidence: recommendationData.confidence_score
        },
        targetRoles: ROLE_TARGETS.ALL,
        userId: claimData.user_id,
        district: claimData.district,
        state: claimData.state,
        icon: 'brain',
        color: 'info'
    };
    
    broadcastNotification(notification);
}

/**
 * Create and broadcast a system alert notification
 */
function notifySystemAlert(req, alertType, message, priority = PRIORITIES.MEDIUM) {
    const broadcastNotification = req.app.get('broadcastNotification');
    
    if (!broadcastNotification) return;
    
    const notification = {
        type: NOTIFICATION_TYPES.SYSTEM_ALERT,
        title: 'System Alert',
        message: message,
        priority: priority,
        data: {
            alertType: alertType,
            timestamp: new Date()
        },
        targetRoles: ROLE_TARGETS.ALL,
        icon: 'alert-triangle',
        color: priority === PRIORITIES.URGENT ? 'error' : 'warning'
    };
    
    broadcastNotification(notification);
}

/**
 * Create and broadcast a user login notification (for admin monitoring)
 */
function notifyUserLogin(req, userData) {
    const broadcastNotification = req.app.get('broadcastNotification');
    
    if (!broadcastNotification) return;
    
    const notification = {
        type: NOTIFICATION_TYPES.USER_LOGIN,
        title: 'User Login',
        message: `${userData.name} (${userData.role}) logged in`,
        priority: PRIORITIES.LOW,
        data: {
            userId: userData.id,
            userName: userData.name,
            userRole: userData.role,
            district: userData.district,
            state: userData.state
        },
        targetRoles: ROLE_TARGETS.ADMIN,
        icon: 'user',
        color: 'info'
    };
    
    broadcastNotification(notification);
}

/**
 * Create and broadcast a verification complete notification
 */
function notifyVerificationComplete(req, claimData, verificationResult) {
    const broadcastNotification = req.app.get('broadcastNotification');
    
    if (!broadcastNotification) return;
    
    const notification = {
        type: NOTIFICATION_TYPES.VERIFICATION_COMPLETE,
        title: 'Verification Complete',
        message: `Claim ${claimData.claim_number} verification: ${verificationResult.verification_status}`,
        priority: verificationResult.verification_status === 'verified' ? PRIORITIES.HIGH : PRIORITIES.MEDIUM,
        data: {
            claimId: claimData.id,
            claimNumber: claimData.claim_number,
            verificationStatus: verificationResult.verification_status,
            confidence: verificationResult.confidence,
            issuesFound: verificationResult.issues_found?.length || 0
        },
        targetRoles: ROLE_TARGETS.OFFICERS,
        userId: claimData.user_id,
        district: claimData.district,
        state: claimData.state,
        icon: 'shield-check',
        color: verificationResult.verification_status === 'verified' ? 'success' : 'warning'
    };
    
    broadcastNotification(notification);
}

/**
 * Get connected users count by role
 */
function getConnectedUsersStats(req) {
    const connectedUsers = req.app.get('connectedUsers');
    
    if (!connectedUsers) return {};
    
    const stats = {
        total: connectedUsers.size,
        citizen: 0,
        district: 0,
        state: 0,
        admin: 0
    };
    
    connectedUsers.forEach(user => {
        if (stats.hasOwnProperty(user.role)) {
            stats[user.role]++;
        }
    });
    
    return stats;
}

/**
 * Send a direct message to a specific user
 */
function sendDirectMessage(req, userId, message, type = 'info') {
    const broadcastNotification = req.app.get('broadcastNotification');
    
    if (!broadcastNotification) return;
    
    const notification = {
        type: 'directMessage',
        title: 'Direct Message',
        message: message,
        priority: PRIORITIES.MEDIUM,
        data: {
            messageType: type,
            timestamp: new Date()
        },
        userId: userId,
        icon: 'mail',
        color: type
    };
    
    broadcastNotification(notification);
}

module.exports = {
    NOTIFICATION_TYPES,
    PRIORITIES,
    ROLE_TARGETS,
    notifyClaimUpdate,
    notifyNewFeedback,
    notifyReportGenerated,
    notifyIssueResolved,
    notifyAIRecommendation,
    notifySystemAlert,
    notifyUserLogin,
    notifyVerificationComplete,
    getConnectedUsersStats,
    sendDirectMessage
};