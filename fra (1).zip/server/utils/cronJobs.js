const cron = require('node-cron');
const { sendWeeklyReports } = require('./emailReports');

/**
 * Initialize all cron jobs
 */
function initializeCronJobs() {
    console.log('⏰ Initializing cron jobs...');
    
    // Weekly Report - Every Sunday at 9:00 AM
    cron.schedule('0 9 * * SUN', () => {
        console.log('⏰ Cron: Weekly report job triggered');
        sendWeeklyReports();
    }, {
        timezone: "Asia/Kolkata"
    });
    
    console.log('✅ Cron jobs initialized:');
    console.log('   - Weekly Reports: Every Sunday at 9:00 AM IST');
    
    // FOR TESTING: Uncomment to run every minute
    // cron.schedule('* * * * *', () => {
    //     console.log('⏰ Test: Running weekly report (every minute for testing)');
    //     sendWeeklyReports();
    // });
}

module.exports = { initializeCronJobs };
