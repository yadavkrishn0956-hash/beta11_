const ExcelJS = require('exceljs');

/**
 * Generate Excel Report
 * @param {Object} reportData - Report data to include in Excel
 * @param {String} startDate - Report start date
 * @param {String} endDate - Report end date
 * @returns {Buffer} Excel buffer
 */
async function generateExcelReport(reportData, startDate, endDate) {
    const workbook = new ExcelJS.Workbook();
    
    // Summary Sheet
    const summarySheet = workbook.addWorksheet('Summary');
    
    // Header styling
    summarySheet.getCell('A1').value = 'FRA Atlas & DSS - Comprehensive Report';
    summarySheet.getCell('A1').font = { size: 16, bold: true, color: { argb: 'FF2c5f2d' } };
    summarySheet.mergeCells('A1:D1');
    
    summarySheet.getCell('A2').value = `Report Period: ${startDate} to ${endDate}`;
    summarySheet.getCell('A2').font = { size: 12 };
    summarySheet.mergeCells('A2:D2');
    
    // Summary Data
    summarySheet.addRow([]);
    summarySheet.addRow(['Metric', 'Value']);
    summarySheet.getRow(4).font = { bold: true };
    summarySheet.getRow(4).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE0E0E0' }
    };
    
    summarySheet.addRow(['Total Claims Filed', reportData.totalClaims || 0]);
    summarySheet.addRow(['Approved Claims', reportData.approvedClaims || 0]);
    summarySheet.addRow(['Pending Claims', reportData.pendingClaims || 0]);
    summarySheet.addRow(['Rejected Claims', reportData.rejectedClaims || 0]);
    summarySheet.addRow(['Average Processing Time (days)', reportData.avgProcessingDays || 0]);
    
    // Column widths
    summarySheet.getColumn(1).width = 30;
    summarySheet.getColumn(2).width = 20;
    
    // District Performance Sheet
    if (reportData.districtPerformance && reportData.districtPerformance.length > 0) {
        const districtSheet = workbook.addWorksheet('District Performance');
        
        // Headers
        districtSheet.addRow(['District', 'Filed', 'Approved', 'Pending', 'Avg Days']);
        districtSheet.getRow(1).font = { bold: true };
        districtSheet.getRow(1).fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FF2c5f2d' }
        };
        districtSheet.getRow(1).font = { color: { argb: 'FFFFFFFF' }, bold: true };
        
        // Data
        reportData.districtPerformance.forEach(district => {
            districtSheet.addRow([
                district.district,
                district.filed,
                district.approved,
                district.pending,
                district.avgDays
            ]);
        });
        
        // Column widths
        districtSheet.columns.forEach(column => {
            column.width = 15;
        });
        districtSheet.getColumn(1).width = 25;
    }
    
    // Scheme Impact Sheet
    if (reportData.schemeImpact && reportData.schemeImpact.length > 0) {
        const schemeSheet = workbook.addWorksheet('Scheme Impact');
        
        // Headers
        schemeSheet.addRow(['Scheme', 'Beneficiaries', 'Budget', 'Coverage %']);
        schemeSheet.getRow(1).font = { bold: true };
        schemeSheet.getRow(1).fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FF2c5f2d' }
        };
        schemeSheet.getRow(1).font = { color: { argb: 'FFFFFFFF' }, bold: true };
        
        // Data
        reportData.schemeImpact.forEach(scheme => {
            schemeSheet.addRow([
                scheme.scheme,
                scheme.beneficiaries,
                scheme.budget,
                scheme.coverage
            ]);
        });
        
        // Column widths
        schemeSheet.columns.forEach(column => {
            column.width = 20;
        });
        schemeSheet.getColumn(1).width = 30;
    }
    
    // Generate buffer
    const buffer = await workbook.xlsx.writeBuffer();
    return buffer;
}

module.exports = { generateExcelReport };
