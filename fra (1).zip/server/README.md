# FRA Atlas & DSS Backend API

Backend API server for the Forest Rights Act (FRA) Atlas & Decision Support System built with Node.js, Express, and PostgreSQL.

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- PostgreSQL (optional - uses mock data if not available)
- npm or yarn

### Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Environment Setup:**
   Copy `.env` file and update values as needed:
   ```bash
   cp .env .env.local
   ```

3. **Start the server:**
   ```bash
   # Development mode with auto-reload
   npm run dev

   # Production mode
   npm start
   ```

4. **Verify installation:**
   Visit: http://localhost:5000/api/health

## 📋 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/profile` - Get user profile
- `POST /api/auth/refresh` - Refresh JWT token
- `POST /api/auth/logout` - Logout user

### FRA Claims
- `GET /api/claims` - List claims (with filters)
- `POST /api/claims` - Create new claim (with file upload)
- `GET /api/claims/:id` - Get single claim
- `PUT /api/claims/:id` - Update claim status
- `DELETE /api/claims/:id` - Delete claim (admin only)

### Feedback System
- `POST /api/feedback` - Submit feedback
- `GET /api/feedback` - Get feedback list
- `GET /api/feedback/:id` - Get single feedback
- `PUT /api/feedback/:id` - Update feedback status

### Issues Tracking
- `POST /api/issues` - Report issue
- `GET /api/issues` - Get issues list
- `GET /api/issues/:id` - Get single issue
- `PUT /api/issues/:id` - Update issue
- `DELETE /api/issues/:id` - Delete issue (admin only)

### Decision Support System
- `POST /api/dss/recommend` - Get scheme recommendations

### Reports
- `GET /api/reports/district/:id` - Generate district report
- `POST /api/reports/custom` - Generate custom report
- `GET /api/reports` - List reports
- `GET /api/reports/download/:filename` - Download report
- `DELETE /api/reports/:id` - Delete report (admin only)

## 🔐 Authentication & Authorization

### User Roles
- **Citizen**: Can submit claims, feedback, and view own data
- **District Officer**: Can manage claims in their district
- **State Officer**: Can manage claims in their state
- **Admin**: Full system access

### JWT Token
Include in request headers:
```
Authorization: Bearer <your-jwt-token>
```

## 📊 Mock Data

The system includes comprehensive mock data for demo purposes:

### Demo Users
- **District Officer**: `rajesh@district.gov.in` / `password`
- **State Officer**: `priya@state.gov.in` / `password`
- **Admin**: `admin@fra.gov.in` / `password`
- **Citizen**: `ramesh@citizen.com` / `password`

### Sample Data
- 40+ FRA Claims with various statuses
- Government schemes (PM-KISAN, Jal Jeevan Mission, MGNREGA, etc.)
- Feedback and issues tracking
- Generated reports

## 🗄️ Database Schema

### Core Tables
- `users` - User accounts and roles
- `claims` - FRA claim submissions
- `feedback` - User feedback and ratings
- `issues` - Internal issue tracking
- `reports` - Generated reports
- `schemes` - Government schemes for DSS

## 🛡️ Security Features

- **JWT Authentication** with role-based access control
- **Rate Limiting** (100 requests per 15 minutes)
- **Input Validation** using Joi schemas
- **File Upload Security** with type and size restrictions
- **CORS Protection** with configurable origins
- **Helmet.js** for security headers
- **Audit Logging** for all user actions

## 📁 File Uploads

- **Supported formats**: PDF, JPEG, JPG, PNG
- **Max file size**: 10MB
- **Storage**: Local filesystem (`/uploads` directory)
- **Access**: Authenticated users only

## 🔧 Configuration

### Environment Variables
```env
# Server
PORT=5000
NODE_ENV=development

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=fra_atlas_db
DB_USER=postgres
DB_PASSWORD=password

# JWT
JWT_SECRET=your-secret-key
JWT_EXPIRES_IN=24h

# File Upload
MAX_FILE_SIZE=10485760

# Rate Limiting
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX_REQUESTS=100
```

## 🧪 Testing API

### Using curl:
```bash
# Health check
curl http://localhost:5000/api/health

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"rajesh@district.gov.in","password":"password"}'

# Get claims (with token)
curl http://localhost:5000/api/claims \
  -H "Authorization: Bearer <your-token>"
```

### Using Postman:
Import the API endpoints and test with the demo user credentials.

## 📈 Performance & Monitoring

- **Health Check**: `/api/health` endpoint for monitoring
- **Request Logging**: Morgan middleware for HTTP request logs
- **Error Handling**: Centralized error handling with detailed logging
- **Graceful Shutdown**: Proper cleanup on server termination

## 🚀 Deployment

### Production Setup
1. Set `NODE_ENV=production`
2. Configure PostgreSQL database
3. Set secure JWT secret
4. Configure CORS for your frontend domain
5. Set up reverse proxy (nginx/Apache)
6. Enable HTTPS

### Docker Support
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

## 🤝 Integration with Frontend

The API is designed to work seamlessly with the FRA Atlas frontend:

1. **CORS configured** for frontend domain
2. **Consistent JSON responses** with success/error structure
3. **File upload support** for claim documents
4. **Real-time data** through RESTful endpoints
5. **Role-based UI** data filtering

## 📞 Support

For technical support or questions:
- Check the health endpoint: `/api/health`
- Review server logs for errors
- Verify environment configuration
- Test with demo user credentials

---

**© 2025 FRA Atlas DSS – Powered by ISRO Bhuvan & AI4GovTech**