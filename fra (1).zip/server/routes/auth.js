const express = require('express');
const router = express.Router();
const { validate } = require('../middleware/validation');
const { verifyToken } = require('../middleware/auth');
const {
    register,
    login,
    getProfile,
    refreshToken,
    logout
} = require('../controllers/authController');

// @route   POST /api/auth/register
// @desc    Register new user
// @access  Public
router.post('/register', validate('register'), register);

// @route   POST /api/auth/login
// @desc    Login user
// @access  Public
router.post('/login', validate('login'), login);

// @route   GET /api/auth/profile
// @desc    Get current user profile
// @access  Private
router.get('/profile', verifyToken, getProfile);

// @route   POST /api/auth/refresh
// @desc    Refresh JWT token
// @access  Private
router.post('/refresh', verifyToken, refreshToken);

// @route   POST /api/auth/logout
// @desc    Logout user
// @access  Private
router.post('/logout', verifyToken, logout);

module.exports = router;