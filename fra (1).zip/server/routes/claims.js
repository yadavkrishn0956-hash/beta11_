const express = require('express');
const multer = require('multer');
const path = require('path');
const router = express.Router();
const { validate } = require('../middleware/validation');
const { verifyToken, roleCheck } = require('../middleware/auth');
const {
    getClaims,
    getClaimById,
    createClaim,
    createClaimWithGeometry,
    updateClaimStatus,
    deleteClaim
} = require('../controllers/claimsController');
const roleCheckMiddleware = require('../middleware/roleCheck');

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'claim-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: {
        fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10485760 // 10MB
    },
    fileFilter: (req, file, cb) => {
        const allowedTypes = /jpeg|jpg|png|pdf/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);

        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only PDF, JPEG, JPG, and PNG files are allowed'));
        }
    }
});

// @route   GET /api/claims
// @desc    Get all claims with filters
// @access  Public (for demo data)
router.get('/', getClaims);

// @route   GET /api/claims/export
// @desc    Export claims data as CSV
// @access  Public (for demo)
router.get('/export', (req, res) => {
    try {
        // Mock claims data for export
        const claims = [
            { id: 'FRA2025-JH-001', name: 'Ramesh Kumar', village: 'Jharia', district: 'Dhanbad', status: 'approved', area: 2.5 },
            { id: 'FRA2025-JH-002', name: 'Sunita Devi', village: 'Koderma', district: 'Koderma', status: 'pending', area: 1.8 },
            { id: 'FRA2025-JH-003', name: 'Arjun Singh', village: 'Hazaribagh', district: 'Hazaribagh', status: 'rejected', area: 3.2 },
            { id: 'FRA2025-JH-004', name: 'Priya Sharma', village: 'Ranchi', district: 'Ranchi', status: 'approved', area: 4.1 },
            { id: 'FRA2025-JH-005', name: 'Mohan Lal', village: 'Dhanbad', district: 'Dhanbad', status: 'under_review', area: 2.9 }
        ];

        // Create CSV header
        const csvHeader = 'Claim ID,Applicant Name,Village,District,Status,Land Area (hectares)\n';
        
        // Create CSV rows
        const csvRows = claims.map(claim => 
            `${claim.id},${claim.name},${claim.village},${claim.district},${claim.status},${claim.area}`
        ).join('\n');
        
        const csvContent = csvHeader + csvRows;
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="FRA_Claims_Export_${Date.now()}.csv"`);
        res.send(csvContent);
        
    } catch (error) {
        console.error('Export error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to export claims data',
            error: error.message
        });
    }
});

// @route   GET /api/claims/:id
// @desc    Get single claim by ID
// @access  Public (for demo data)
router.get('/:id', getClaimById);

// @route   POST /api/claims
// @desc    Create new claim
// @access  Private (Citizens and above)
router.post('/', 
    verifyToken, 
    roleCheck(['citizen', 'district', 'state', 'admin']),
    upload.single('document'),
    validate('claim'),
    createClaim
);

// @route   POST /api/claims/create
// @desc    Create new claim with polygon geometry (for draw feature)
// @access  Private (District Officer, State Officer, Admin only)
router.post('/create',
    verifyToken,
    roleCheckMiddleware(['district', 'state', 'admin']),
    createClaimWithGeometry
);

// @route   PUT /api/claims/:id
// @desc    Update claim status
// @access  Private (District officers and above)
router.put('/:id', 
    verifyToken, 
    roleCheck(['district', 'state', 'admin']),
    validate('updateStatus'),
    updateClaimStatus
);

// @route   DELETE /api/claims/:id
// @desc    Delete claim
// @access  Private (Admin only)
router.delete('/:id', 
    verifyToken, 
    roleCheck(['admin']),
    deleteClaim
);

module.exports = router;