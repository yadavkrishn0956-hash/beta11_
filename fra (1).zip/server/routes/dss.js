const express = require('express');
const router = express.Router();
const { verifyToken, roleCheck } = require('../middleware/auth');
const { 
    getSchemeRecommendations, 
    getAllSchemes, 
    getAIServiceStatus, 
    verifyClaimAI 
} = require('../controllers/dssController');

// @route   POST /api/dss/recommend
// @desc    Get AI-powered scheme recommendations based on claim data
// @access  Private
router.post('/recommend', verifyToken, getSchemeRecommendations);

// @route   GET /api/dss/schemes
// @desc    Get all available schemes
// @access  Private
router.get('/schemes', verifyToken, getAllSchemes);

// @route   GET /api/dss/ai/status
// @desc    Get AI service status and analytics
// @access  Private (Officers and admin)
router.get('/ai/status', verifyToken, roleCheck(['district', 'state', 'admin']), getAIServiceStatus);

// @route   POST /api/dss/verify
// @desc    AI-powered claim verification
// @access  Private (Officers and admin)
router.post('/verify', verifyToken, roleCheck(['district', 'state', 'admin']), verifyClaimAI);

module.exports = router;