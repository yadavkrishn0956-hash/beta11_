const express = require('express');
const router = express.Router();
const { validate } = require('../middleware/validation');
const { verifyToken, roleCheck } = require('../middleware/auth');
const {
    submitFeedback,
    getFeedback,
    updateFeedback,
    getFeedbackById
} = require('../controllers/feedbackController');

// @route   POST /api/feedback
// @desc    Submit citizen feedback
// @access  Private
router.post('/', 
    verifyToken,
    validate('feedback'),
    submitFeedback
);

// @route   GET /api/feedback
// @desc    Get feedback (for officers/admin)
// @access  Public (for demo data)
router.get('/', getFeedback);

// @route   GET /api/feedback/:id
// @desc    Get feedback by ID
// @access  Public (for demo data)
router.get('/:id', getFeedbackById);

// @route   PUT /api/feedback/:id
// @desc    Update feedback status/response
// @access  Private (Officers and admin only)
router.put('/:id', 
    verifyToken,
    roleCheck(['district', 'state', 'admin']),
    updateFeedback
);

module.exports = router;