const express = require('express');
const router = express.Router();
const {
    exportReport,
    generateComprehensive,
    shareReport,
    scheduleWeeklyReport,
    getReportHistory
} = require('../controllers/reportsController');

// @route   POST /api/reports/export
// @desc    Export report as PDF or Excel
// @access  Public (for demo)
// Query params: format (pdf/excel), startDate, endDate
router.post('/export', exportReport);

// @route   GET /api/reports/comprehensive
// @desc    Generate comprehensive analytics report
// @access  Public (for demo)
// Query params: startDate, endDate
router.get('/comprehensive', generateComprehensive);

// @route   POST /api/reports/share
// @desc    Share report via email
// @access  Public (for demo)
// Body: { email, format, startDate, endDate }
router.post('/share', shareReport);

// @route   POST /api/reports/schedule
// @desc    Schedule weekly report
// @access  Public (for demo)
// Body: { enabled, email }
router.post('/schedule', scheduleWeeklyReport);

// @route   GET /api/reports/history
// @desc    Get report generation history
// @access  Public (for demo)
router.get('/history', getReportHistory);

module.exports = router;