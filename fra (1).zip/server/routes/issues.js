const express = require('express');
const router = express.Router();
const { validate } = require('../middleware/validation');
const { verifyToken, roleCheck } = require('../middleware/auth');
const {
    reportIssue,
    getIssues,
    updateIssue,
    getIssueById,
    deleteIssue
} = require('../controllers/issuesController');

// @route   POST /api/issues
// @desc    Report internal issue
// @access  Private
router.post('/', 
    verifyToken,
    validate('issue'),
    reportIssue
);

// @route   GET /api/issues
// @desc    Get issues
// @access  Public (for demo)
router.get('/', getIssues);

// @route   GET /api/issues/:id
// @desc    Get issue by ID
// @access  Private
router.get('/:id', verifyToken, getIssueById);

// @route   PUT /api/issues/:id
// @desc    Update issue status/resolution
// @access  Private
router.put('/:id', verifyToken, updateIssue);

// @route   DELETE /api/issues/:id
// @desc    Delete issue
// @access  Private (Admin only)
router.delete('/:id', 
    verifyToken,
    roleCheck(['admin']),
    deleteIssue
);

module.exports = router;