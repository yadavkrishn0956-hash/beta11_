const express = require('express');
const router = express.Router();
const {
    getStates,
    getDistricts,
    getVillages,
    searchLocations,
    getCacheStats,
    clearCache
} = require('../controllers/geoController');

// @route   GET /api/geo/states
// @desc    Get all states
// @access  Public
router.get('/states', getStates);

// @route   GET /api/geo/districts/:stateCode
// @desc    Get districts by state code
// @access  Public
router.get('/districts/:stateCode', getDistricts);

// @route   GET /api/geo/villages/:districtCode
// @desc    Get villages by district code
// @access  Public
router.get('/villages/:districtCode', getVillages);

// @route   GET /api/geo/search
// @desc    Search locations (states, districts, villages)
// @access  Public
router.get('/search', searchLocations);

// @route   GET /api/geo/cache/stats
// @desc    Get cache statistics
// @access  Public
router.get('/cache/stats', getCacheStats);

// @route   POST /api/geo/cache/clear
// @desc    Clear cache
// @access  Public
router.post('/cache/clear', clearCache);

module.exports = router;
