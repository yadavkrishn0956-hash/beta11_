const express = require('express');
const router = express.Router();

// Mock chat logs storage (in production, use database)
let chatLogs = [];

/**
 * @route   POST /api/chatbot/message
 * @desc    Process chatbot message and return response
 * @access  Public
 */
router.post('/message', async (req, res) => {
    try {
        const { message, userId, userRole, language } = req.body;
        
        // Log the message
        const logEntry = {
            id: chatLogs.length + 1,
            userId: userId || 'anonymous',
            userRole: userRole || 'citizen',
            message,
            language: language || 'en',
            timestamp: new Date()
        };
        
        chatLogs.push(logEntry);
        
        // Process message and generate response
        const response = await processMessage(message, userRole, language);
        
        res.json({
            success: true,
            data: {
                response,
                timestamp: new Date()
            }
        });
        
    } catch (error) {
        console.error('Chatbot message error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to process message',
            error: error.message
        });
    }
});

/**
 * @route   GET /api/chatbot/logs
 * @desc    Get chat logs for analytics
 * @access  Admin only
 */
router.get('/logs', async (req, res) => {
    try {
        const { limit = 100, userId, startDate, endDate } = req.query;
        
        let filteredLogs = [...chatLogs];
        
        // Filter by userId if provided
        if (userId) {
            filteredLogs = filteredLogs.filter(log => log.userId === userId);
        }
        
        // Filter by date range if provided
        if (startDate) {
            filteredLogs = filteredLogs.filter(log => 
                new Date(log.timestamp) >= new Date(startDate)
            );
        }
        
        if (endDate) {
            filteredLogs = filteredLogs.filter(log => 
                new Date(log.timestamp) <= new Date(endDate)
            );
        }
        
        // Limit results
        filteredLogs = filteredLogs.slice(-limit);
        
        res.json({
            success: true,
            data: {
                logs: filteredLogs,
                total: filteredLogs.length
            }
        });
        
    } catch (error) {
        console.error('Get chat logs error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch chat logs',
            error: error.message
        });
    }
});

/**
 * @route   DELETE /api/chatbot/logs
 * @desc    Clear chat logs
 * @access  Admin only
 */
router.delete('/logs', async (req, res) => {
    try {
        const { userId } = req.body;
        
        if (userId) {
            // Clear logs for specific user
            chatLogs = chatLogs.filter(log => log.userId !== userId);
        } else {
            // Clear all logs
            chatLogs = [];
        }
        
        res.json({
            success: true,
            message: 'Chat logs cleared successfully'
        });
        
    } catch (error) {
        console.error('Clear chat logs error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to clear chat logs',
            error: error.message
        });
    }
});

/**
 * Process chatbot message and generate intelligent response
 */
async function processMessage(message, userRole, language) {
    const lowerMessage = message.toLowerCase();
    
    // Intent detection
    const intents = {
        claimStatus: ['claim', 'status', 'check', 'दावा', 'स्थिति'],
        scheme: ['scheme', 'योजना', 'eligible', 'पात्र', 'benefit'],
        document: ['document', 'upload', 'दस्तावेज़', 'अपलोड', 'file'],
        feedback: ['feedback', 'complaint', 'फीडबैक', 'शिकायत', 'issue'],
        report: ['report', 'रिपोर्ट', 'summary', 'सारांश', 'generate'],
        help: ['help', 'मदद', 'assist', 'सहायता']
    };
    
    // Detect intent
    let detectedIntent = 'general';
    for (const [intent, keywords] of Object.entries(intents)) {
        if (keywords.some(keyword => lowerMessage.includes(keyword))) {
            detectedIntent = intent;
            break;
        }
    }
    
    // Generate response based on intent and role
    return generateResponse(detectedIntent, userRole, language);
}

/**
 * Generate response based on intent and user role
 */
function generateResponse(intent, userRole, language) {
    const responses = {
        en: {
            citizen: {
                claimStatus: "I can help you check your claim status. Please provide your Claim ID (e.g., FRA-JH-RAN-2025-001).",
                scheme: "Here are some schemes you might be eligible for: PM-KISAN (₹6000/year), MGNREGA (100 days employment), Jal Jeevan Mission (tap water), and PMAY (housing).",
                document: "To upload documents, please visit the Claims page and click 'Upload Documents'. You can upload land proof, identity documents, and asset data.",
                feedback: "I'd be happy to help with your feedback or complaint. Please share the details, and I'll make sure it reaches the right team.",
                help: "I can help you with: checking claim status, finding eligible schemes, uploading documents, and submitting feedback. What would you like to do?",
                general: "I'm here to assist you with FRA claims, schemes, and documents. How can I help you today?"
            },
            officer: {
                claimStatus: "I can show you claim summaries and pending verifications. Would you like to see pending claims or generate a report?",
                report: "I can generate various reports for you: claim summary, pending verifications, district performance, or monthly reports. Which one would you like?",
                help: "I can help you with: claim summaries, pending verifications, unverified claims, and report generation. What do you need?",
                general: "I'm here to assist with claim management and reporting. What would you like to do?"
            },
            admin: {
                report: "I can generate state-level reports, FRA progress analytics, and DSS recommendations. What type of report do you need?",
                help: "I can provide: FRA progress data, monthly reports, DSS recommendations, and district analytics. How can I assist?",
                general: "I'm here to help with state-level analytics and strategic insights. What information do you need?"
            }
        },
        hi: {
            citizen: {
                claimStatus: "मैं आपकी दावा स्थिति जांचने में मदद कर सकता हूं। कृपया अपना दावा आईडी प्रदान करें (जैसे FRA-JH-RAN-2025-001)।",
                scheme: "यहां कुछ योजनाएं हैं जिनके लिए आप पात्र हो सकते हैं: PM-KISAN (₹6000/वर्ष), MGNREGA (100 दिन रोजगार), जल जीवन मिशन (नल का पानी), और PMAY (आवास)।",
                document: "दस्तावेज़ अपलोड करने के लिए, कृपया दावे पृष्ठ पर जाएं और 'दस्तावेज़ अपलोड करें' पर क्लिक करें।",
                feedback: "मैं आपकी प्रतिक्रिया या शिकायत में मदद करने के लिए खुश हूं। कृपया विवरण साझा करें।",
                help: "मैं आपकी मदद कर सकता हूं: दावा स्थिति जांचना, पात्र योजनाएं खोजना, दस्तावेज़ अपलोड करना, और फीडबैक देना। आप क्या करना चाहेंगे?",
                general: "मैं FRA दावों, योजनाओं और दस्तावेजों में आपकी सहायता के लिए यहां हूं। आज मैं आपकी कैसे मदद कर सकता हूं?"
            },
            officer: {
                claimStatus: "मैं आपको दावा सारांश और लंबित सत्यापन दिखा सकता हूं। क्या आप लंबित दावे देखना चाहेंगे या रिपोर्ट बनाना चाहेंगे?",
                report: "मैं आपके लिए विभिन्न रिपोर्ट बना सकता हूं: दावा सारांश, लंबित सत्यापन, जिला प्रदर्शन, या मासिक रिपोर्ट। आप कौन सी चाहेंगे?",
                help: "मैं आपकी मदद कर सकता हूं: दावा सारांश, लंबित सत्यापन, असत्यापित दावे, और रिपोर्ट बनाना। आपको क्या चाहिए?",
                general: "मैं दावा प्रबंधन और रिपोर्टिंग में सहायता के लिए यहां हूं। आप क्या करना चाहेंगे?"
            },
            admin: {
                report: "मैं राज्य-स्तरीय रिपोर्ट, FRA प्रगति विश्लेषण, और DSS सिफारिशें बना सकता हूं। आपको किस प्रकार की रिपोर्ट चाहिए?",
                help: "मैं प्रदान कर सकता हूं: FRA प्रगति डेटा, मासिक रिपोर्ट, DSS सिफारिशें, और जिला विश्लेषण। मैं कैसे सहायता कर सकता हूं?",
                general: "मैं राज्य-स्तरीय विश्लेषण और रणनीतिक अंतर्दृष्टि में मदद के लिए यहां हूं। आपको कौन सी जानकारी चाहिए?"
            }
        }
    };
    
    const roleResponses = responses[language]?.[userRole] || responses.en.citizen;
    return roleResponses[intent] || roleResponses.general;
}

module.exports = router;
