const express = require('express');
const { createServer } = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

// Import middleware
const errorHandler = require('./middleware/errorHandler');
const { auditLog } = require('./middleware/auth');

// Import database
const { testConnection, initializeTables } = require('./config/db');

// Import routes
const authRoutes = require('./routes/auth');
const claimsRoutes = require('./routes/claims');
const feedbackRoutes = require('./routes/feedback');
const issuesRoutes = require('./routes/issues');
const dssRoutes = require('./routes/dss');
const reportsRoutes = require('./routes/reports');
const geoRoutes = require('./routes/geo');
const chatbotRoutes = require('./routes/chatbot');

// Initialize Express app and HTTP server
const app = express();
const server = createServer(app);

// Initialize Socket.IO
const io = new Server(server, {
    cors: {
        origin: process.env.FRONTEND_URL || ["http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:8080"],
        methods: ["GET", "POST"],
        credentials: true
    },
    transports: ['websocket', 'polling']
});

// Make io available to routes
app.set('socketio', io);

// Security middleware
app.use(helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" }
}));

// Rate limiting - Relaxed for development
const limiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute window
    max: 1000, // 1000 requests per minute (very relaxed for development)
    message: {
        success: false,
        message: 'Too many requests from this IP, please try again later.'
    },
    skip: (req) => {
        // Skip rate limiting for development environment
        if (process.env.NODE_ENV === 'development') {
            return true; // Disable rate limiting in development
        }
        // Skip for geo endpoints
        return req.path.startsWith('/api/geo/');
    },
    standardHeaders: true,
    legacyHeaders: false,
});
app.use('/api/', limiter);

// CORS configuration
app.use(cors({
    origin: ['http://localhost:8080', 'http://localhost:3000', 'http://127.0.0.1:8080'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging middleware
if (process.env.NODE_ENV === 'development') {
    app.use(morgan('dev'));
} else {
    app.use(morgan('combined'));
}

// Audit logging middleware
app.use(auditLog);

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

// Serve static files
app.use('/uploads', express.static(uploadsDir));

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        status: 'running',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        environment: process.env.NODE_ENV || 'development'
    });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/claims', claimsRoutes);
app.use('/api/feedback', feedbackRoutes);
app.use('/api/issues', issuesRoutes);
app.use('/api/dss', dssRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/geo', geoRoutes);
app.use('/api/chatbot', chatbotRoutes);

// Analytics endpoint (Public for demo)
app.get('/api/analytics/dashboard', (req, res) => {
    res.json({
        success: true,
        data: {
            statusDistribution: {
                pending: 45,
                approved: 35,
                rejected: 12,
                under_review: 8
            },
            monthlyTrend: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                data: [120, 150, 180, 220, 190, 250]
            },
            schemeCoverage: {
                labels: ['PM-KISAN', 'MGNREGA', 'Jal Jeevan', 'Green India', 'DAJGUA'],
                data: [850, 720, 650, 580, 420]
            }
        }
    });
});

// Root endpoint
app.get('/', (req, res) => {
    res.json({
        success: true,
        message: 'FRA Atlas & DSS API Server',
        version: '1.0.0',
        documentation: '/api/health',
        endpoints: {
            auth: '/api/auth',
            claims: '/api/claims',
            feedback: '/api/feedback',
            issues: '/api/issues',
            dss: '/api/dss',
            reports: '/api/reports'
        }
    });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'API endpoint not found',
        path: req.originalUrl
    });
});

// Error handling middleware (must be last)
app.use(errorHandler);

// Socket.IO connection handling
const connectedUsers = new Map(); // Store connected users with their roles
const notifications = []; // Store recent notifications

io.on('connection', (socket) => {
    console.log(`🔌 User connected: ${socket.id}`);
    
    // Handle user authentication and role assignment
    socket.on('authenticate', (userData) => {
        if (userData && userData.user) {
            connectedUsers.set(socket.id, {
                userId: userData.user.id,
                name: userData.user.name,
                role: userData.user.role,
                district: userData.user.district,
                state: userData.user.state,
                connectedAt: new Date()
            });
            
            console.log(`👤 User authenticated: ${userData.user.name} (${userData.user.role})`);
            
            // Send recent notifications to newly connected user
            const userNotifications = getNotificationsForUser(userData.user);
            socket.emit('initialNotifications', userNotifications);
            
            // Join role-based rooms
            socket.join(userData.user.role);
            if (userData.user.district) {
                socket.join(`district_${userData.user.district}`);
            }
            if (userData.user.state) {
                socket.join(`state_${userData.user.state}`);
            }
        }
    });
    
    // Handle notification acknowledgment
    socket.on('markNotificationRead', (notificationId) => {
        const notification = notifications.find(n => n.id === notificationId);
        if (notification) {
            if (!notification.readBy) notification.readBy = [];
            const user = connectedUsers.get(socket.id);
            if (user && !notification.readBy.includes(user.userId)) {
                notification.readBy.push(user.userId);
            }
        }
    });
    
    // Handle mark all notifications as read
    socket.on('markAllNotificationsRead', () => {
        const user = connectedUsers.get(socket.id);
        if (user) {
            notifications.forEach(notification => {
                if (!notification.readBy) notification.readBy = [];
                if (!notification.readBy.includes(user.userId)) {
                    notification.readBy.push(user.userId);
                }
            });
            socket.emit('allNotificationsMarkedRead');
        }
    });
    
    // Handle disconnect
    socket.on('disconnect', () => {
        const user = connectedUsers.get(socket.id);
        if (user) {
            console.log(`👋 User disconnected: ${user.name} (${user.role})`);
        }
        connectedUsers.delete(socket.id);
    });
});

// Helper function to get notifications for a specific user based on role
function getNotificationsForUser(user) {
    return notifications.filter(notification => {
        // Admin sees all notifications
        if (user.role === 'admin') return true;
        
        // Role-based filtering
        if (notification.targetRoles && !notification.targetRoles.includes(user.role)) {
            return false;
        }
        
        // District-based filtering
        if (notification.district && user.district !== notification.district) {
            return false;
        }
        
        // State-based filtering
        if (notification.state && user.state !== notification.state) {
            return false;
        }
        
        // User-specific notifications
        if (notification.userId && notification.userId !== user.id) {
            return false;
        }
        
        return true;
    }).slice(-20); // Return last 20 notifications
}

// Helper function to broadcast notifications
function broadcastNotification(notification) {
    // Add to notifications array
    notification.id = Date.now().toString();
    notification.timestamp = new Date();
    notifications.push(notification);
    
    // Keep only last 100 notifications
    if (notifications.length > 100) {
        notifications.splice(0, notifications.length - 100);
    }
    
    // Broadcast to appropriate users
    if (notification.targetRoles) {
        notification.targetRoles.forEach(role => {
            io.to(role).emit('newNotification', notification);
        });
    }
    
    if (notification.district) {
        io.to(`district_${notification.district}`).emit('newNotification', notification);
    }
    
    if (notification.state) {
        io.to(`state_${notification.state}`).emit('newNotification', notification);
    }
    
    if (notification.userId) {
        // Send to specific user
        const userSocket = Array.from(connectedUsers.entries())
            .find(([socketId, userData]) => userData.userId === notification.userId);
        if (userSocket) {
            io.to(userSocket[0]).emit('newNotification', notification);
        }
    }
    
    // Always send to admin
    io.to('admin').emit('newNotification', notification);
    
    console.log(`📢 Notification broadcasted: ${notification.type} - ${notification.message}`);
}

// Make broadcast function available to controllers
app.set('broadcastNotification', broadcastNotification);
app.set('connectedUsers', connectedUsers);

// Initialize Cron Jobs
const { initializeCronJobs } = require('./utils/cronJobs');

// Start server
const PORT = process.env.PORT || 5000;

const startServer = async () => {
    try {
        // Test database connection
        const dbConnected = await testConnection();
        
        if (dbConnected) {
            // Initialize database tables
            await initializeTables();
        }

        // Initialize cron jobs for automated reports
        initializeCronJobs();

        // Start the server with Socket.IO
        server.listen(PORT, () => {
            console.log(`
🚀 FRA Atlas & DSS API Server Started
📍 Port: ${PORT}
🌍 Environment: ${process.env.NODE_ENV || 'development'}
🔗 Health Check: http://localhost:${PORT}/api/health
📚 API Documentation: http://localhost:${PORT}/
🔌 WebSocket: Real-time notifications enabled
⏰ Cron Jobs: Weekly reports scheduled (Sunday 9:00 AM IST)
${dbConnected ? '✅ Database: Connected' : '⚠️  Database: Using Mock Data'}
            `);
        });

    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
};

// Handle unhandled promise rejections
process.on('unhandledRejection', (err, promise) => {
    console.log('Unhandled Rejection at:', promise, 'reason:', err);
    // Close server & exit process
    process.exit(1);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
    console.log('Uncaught Exception:', err);
    process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received. Shutting down gracefully...');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('SIGINT received. Shutting down gracefully...');
    process.exit(0);
});

startServer();

module.exports = app;