const { pool } = require('../config/db');
const { notifyClaimUpdate, notifyAIRecommendation } = require('../utils/notifications');

// Mock claims data for demo
const mockClaims = [
    {
        id: 1,
        user_id: 4,
        claim_number: 'FRA-JH-RAN-2025-001',
        applicant_name: 'Ramesh Oraon',
        village: 'Birsa Nagar',
        district: 'Ranchi',
        state: 'Jharkhand',
        claim_type: 'IFR',
        land_area: 2.5,
        latitude: 23.3441,
        longitude: 85.3096,
        status: 'pending',
        document_url: '/uploads/claim_doc_1.pdf',
        remarks: 'Initial submission',
        created_at: new Date('2025-01-15'),
        updated_at: new Date('2025-01-15')
    },
    {
        id: 2,
        user_id: 4,
        claim_number: 'FRA-JH-RAN-2025-002',
        applicant_name: 'Sita Devi',
        village: 'Kanke',
        district: 'Ranchi',
        state: 'Jharkhand',
        claim_type: 'CFR',
        land_area: 5.0,
        latitude: 23.4241,
        longitude: 85.4096,
        status: 'approved',
        document_url: '/uploads/claim_doc_2.pdf',
        remarks: 'Approved after verification',
        reviewed_by: 1,
        reviewed_at: new Date('2025-01-20'),
        created_at: new Date('2025-01-10'),
        updated_at: new Date('2025-01-20')
    },
    {
        id: 3,
        user_id: 4,
        claim_number: 'FRA-JH-DHN-2025-003',
        applicant_name: 'Mukesh Kumar',
        village: 'Jharia',
        district: 'Dhanbad',
        state: 'Jharkhand',
        claim_type: 'IFR',
        land_area: 1.8,
        latitude: 23.7644,
        longitude: 86.4304,
        status: 'under_review',
        document_url: '/uploads/claim_doc_3.pdf',
        remarks: 'Under field verification',
        created_at: new Date('2025-01-18'),
        updated_at: new Date('2025-01-22')
    },
    // Madhya Pradesh Claims
    {
        id: 4,
        user_id: 5,
        claim_number: 'FRA-MP-BHO-2025-001',
        applicant_name: 'Ramesh Patel',
        village: 'Berasia',
        district: 'Bhopal',
        state: 'Madhya Pradesh',
        claim_type: 'IFR',
        land_area: 2.4,
        latitude: 23.547,
        longitude: 77.433,
        status: 'approved',
        ai_score: 89.2,
        linked_scheme: 'PM-KISAN',
        document_url: '/uploads/claim_doc_4.pdf',
        remarks: 'Approved with AI verification score 89.2%',
        reviewed_by: 1,
        reviewed_at: new Date('2025-01-25'),
        created_at: new Date('2025-01-12'),
        updated_at: new Date('2025-01-25')
    },
    {
        id: 5,
        user_id: 5,
        claim_number: 'FRA-MP-BHO-2025-002',
        applicant_name: 'Sita Bai',
        village: 'Kolar',
        district: 'Bhopal',
        state: 'Madhya Pradesh',
        claim_type: 'CFR',
        land_area: 5.1,
        latitude: 23.120,
        longitude: 77.430,
        status: 'pending',
        ai_score: 76.8,
        linked_scheme: 'MGNREGA',
        document_url: '/uploads/claim_doc_5.pdf',
        remarks: 'Pending field verification',
        created_at: new Date('2025-01-20'),
        updated_at: new Date('2025-01-20')
    },
    {
        id: 6,
        user_id: 6,
        claim_number: 'FRA-MP-MAN-2025-003',
        applicant_name: 'Karan Singh',
        village: 'Bichhiya',
        district: 'Mandla',
        state: 'Madhya Pradesh',
        claim_type: 'IFR',
        land_area: 1.7,
        latitude: 22.100,
        longitude: 80.640,
        status: 'approved',
        ai_score: 82.5,
        linked_scheme: 'Jal Jeevan Mission',
        document_url: '/uploads/claim_doc_6.pdf',
        remarks: 'Approved - Linked to Jal Jeevan Mission',
        reviewed_by: 1,
        reviewed_at: new Date('2025-01-23'),
        created_at: new Date('2025-01-14'),
        updated_at: new Date('2025-01-23')
    },
    {
        id: 7,
        user_id: 6,
        claim_number: 'FRA-MP-SEH-2025-004',
        applicant_name: 'Meera Devi',
        village: 'Ashta',
        district: 'Sehore',
        state: 'Madhya Pradesh',
        claim_type: 'CR',
        land_area: 3.5,
        latitude: 23.010,
        longitude: 77.100,
        status: 'rejected',
        ai_score: 58.6,
        linked_scheme: '—',
        document_url: '/uploads/claim_doc_7.pdf',
        remarks: 'Rejected - Insufficient documentation',
        reviewed_by: 1,
        reviewed_at: new Date('2025-01-24'),
        created_at: new Date('2025-01-16'),
        updated_at: new Date('2025-01-24')
    },
    {
        id: 8,
        user_id: 7,
        claim_number: 'FRA-MP-DIN-2025-005',
        applicant_name: 'Pintu Gond',
        village: 'Samnapur',
        district: 'Dindori',
        state: 'Madhya Pradesh',
        claim_type: 'IFR',
        land_area: 4.2,
        latitude: 22.910,
        longitude: 81.080,
        status: 'pending',
        ai_score: 65.0,
        linked_scheme: 'DAJGUA',
        document_url: '/uploads/claim_doc_8.pdf',
        remarks: 'Under AI verification',
        created_at: new Date('2025-01-21'),
        updated_at: new Date('2025-01-21')
    }
];

// Generate unique claim number
const generateClaimNumber = (state, district) => {
    const stateCode = state.substring(0, 2).toUpperCase();
    const districtCode = district.substring(0, 3).toUpperCase();
    const year = new Date().getFullYear();
    const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `FRA-${stateCode}-${districtCode}-${year}-${randomNum}`;
};

// Get all claims with filters
const getClaims = async (req, res) => {
    try {
        const { state, district, status, page = 1, limit = 10 } = req.query;
        const user = req.user || { role: 'admin' }; // Default to admin for demo mode

        let filteredClaims = [...mockClaims];

        // Apply role-based filtering (only if user is authenticated)
        if (req.user) {
            if (user.role === 'citizen') {
                filteredClaims = filteredClaims.filter(claim => claim.user_id === user.id);
            } else if (user.role === 'district') {
                filteredClaims = filteredClaims.filter(claim => claim.district === user.district);
            } else if (user.role === 'state') {
                filteredClaims = filteredClaims.filter(claim => claim.state === user.state);
            }
        }
        // Admin or unauthenticated can see all claims

        // Apply query filters
        if (state) {
            filteredClaims = filteredClaims.filter(claim => 
                claim.state.toLowerCase().includes(state.toLowerCase())
            );
        }

        if (district) {
            filteredClaims = filteredClaims.filter(claim => 
                claim.district.toLowerCase().includes(district.toLowerCase())
            );
        }

        if (status) {
            filteredClaims = filteredClaims.filter(claim => claim.status === status);
        }

        // Pagination
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + parseInt(limit);
        const paginatedClaims = filteredClaims.slice(startIndex, endIndex);

        // Calculate statistics
        const stats = {
            total: filteredClaims.length,
            pending: filteredClaims.filter(c => c.status === 'pending').length,
            approved: filteredClaims.filter(c => c.status === 'approved').length,
            rejected: filteredClaims.filter(c => c.status === 'rejected').length,
            under_review: filteredClaims.filter(c => c.status === 'under_review').length
        };

        res.json({
            success: true,
            data: {
                claims: paginatedClaims,
                pagination: {
                    current_page: parseInt(page),
                    total_pages: Math.ceil(filteredClaims.length / limit),
                    total_records: filteredClaims.length,
                    per_page: parseInt(limit)
                },
                statistics: stats
            }
        });

    } catch (error) {
        console.error('Get claims error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch claims',
            error: error.message
        });
    }
};

// Get single claim by ID
const getClaimById = async (req, res) => {
    try {
        const { id } = req.params;
        const user = req.user;

        const claim = mockClaims.find(c => c.id === parseInt(id));

        if (!claim) {
            return res.status(404).json({
                success: false,
                message: 'Claim not found'
            });
        }

        // Check access permissions
        if (user.role === 'citizen' && claim.user_id !== user.id) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        if (user.role === 'district' && claim.district !== user.district) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        if (user.role === 'state' && claim.state !== user.state) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        res.json({
            success: true,
            data: claim
        });

    } catch (error) {
        console.error('Get claim error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch claim',
            error: error.message
        });
    }
};

// Create new claim
const createClaim = async (req, res) => {
    try {
        const {
            applicant_name,
            village,
            district,
            state,
            claim_type,
            land_area,
            latitude,
            longitude,
            remarks
        } = req.body;

        const user = req.user;

        // Generate claim number
        const claim_number = generateClaimNumber(state, district);

        // Create new claim object
        const newClaim = {
            id: mockClaims.length + 1,
            user_id: user.id,
            claim_number,
            applicant_name,
            village,
            district,
            state,
            claim_type,
            land_area: parseFloat(land_area),
            latitude: latitude ? parseFloat(latitude) : null,
            longitude: longitude ? parseFloat(longitude) : null,
            status: 'pending',
            document_url: req.file ? `/uploads/${req.file.filename}` : null,
            remarks,
            created_at: new Date(),
            updated_at: new Date()
        };

        // In real app, save to database
        mockClaims.push(newClaim);

        // Notify officers about new claim
        notifyClaimUpdate(req, newClaim, 'submitted', `New claim submitted by ${newClaim.applicant_name}`);

        res.status(201).json({
            success: true,
            message: 'Claim submitted successfully',
            data: newClaim
        });

    } catch (error) {
        console.error('Create claim error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create claim',
            error: error.message
        });
    }
};

// Update claim status
const updateClaimStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, remarks } = req.body;
        const user = req.user;

        // Only district, state, and admin can update status
        if (user.role === 'citizen') {
            return res.status(403).json({
                success: false,
                message: 'Citizens cannot update claim status'
            });
        }

        const claimIndex = mockClaims.findIndex(c => c.id === parseInt(id));

        if (claimIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Claim not found'
            });
        }

        const claim = mockClaims[claimIndex];

        // Check district/state access
        if (user.role === 'district' && claim.district !== user.district) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        if (user.role === 'state' && claim.state !== user.state) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        // Update claim
        mockClaims[claimIndex] = {
            ...claim,
            status,
            remarks: remarks || claim.remarks,
            reviewed_by: user.id,
            reviewed_at: new Date(),
            updated_at: new Date()
        };

        // Notify about status change
        notifyClaimUpdate(req, mockClaims[claimIndex], status, 
            `Claim ${claim.claim_number} has been ${status} by ${user.name}`);

        res.json({
            success: true,
            message: 'Claim status updated successfully',
            data: mockClaims[claimIndex]
        });

    } catch (error) {
        console.error('Update claim error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update claim',
            error: error.message
        });
    }
};

// Delete claim (admin only)
const deleteClaim = async (req, res) => {
    try {
        const { id } = req.params;
        const user = req.user;

        if (user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Only admin can delete claims'
            });
        }

        const claimIndex = mockClaims.findIndex(c => c.id === parseInt(id));

        if (claimIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Claim not found'
            });
        }

        // Remove claim
        mockClaims.splice(claimIndex, 1);

        res.json({
            success: true,
            message: 'Claim deleted successfully'
        });

    } catch (error) {
        console.error('Delete claim error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete claim',
            error: error.message
        });
    }
};

// Create claim with polygon geometry (for draw feature)
const createClaimWithGeometry = async (req, res) => {
    try {
        const {
            claimant_name,
            claim_type,
            village,
            area_ha,
            linked_scheme,
            notes,
            geometry
        } = req.body;

        const user = req.user;

        // Validate required fields
        if (!claimant_name || !claim_type || !village || !geometry) {
            return res.status(400).json({
                success: false,
                error: 'Missing required fields: claimant_name, claim_type, village, geometry'
            });
        }

        // Validate geometry
        if (!geometry.type || !geometry.coordinates) {
            return res.status(400).json({
                success: false,
                error: 'Invalid geometry data. Must include type and coordinates.'
            });
        }

        // Get village data to extract district and state
        const villageData = await getVillageDataByCode(village);
        const district = villageData?.district_name || 'Unknown';
        const state = villageData?.state_name || 'Unknown';

        // Generate unique claim ID
        const claim_id = await generateClaimIdWithGeometry(state, district);

        // Calculate area if not provided (using turf.js on backend)
        let calculatedArea = area_ha;
        if (!calculatedArea && geometry) {
            // For now, use provided area. In production, recalculate on backend
            calculatedArea = area_ha || 0;
        }

        // Create new claim object
        const newClaim = {
            id: mockClaims.length + 1,
            claim_id,
            user_id: user.id,
            claimant_name,
            claim_type,
            status: 'Pending',
            village,
            district,
            state,
            area_ha: parseFloat(calculatedArea).toFixed(2),
            linked_scheme: linked_scheme || null,
            notes: notes || null,
            geometry: JSON.stringify(geometry),
            ai_score: null,
            ai_confidence: null,
            recommended_scheme: null,
            created_by: user.id,
            created_date: new Date().toISOString(),
            verified_date: null,
            approved_date: null,
            rejected_date: null
        };

        // In real app, save to database
        mockClaims.push(newClaim);

        console.log(`✅ Claim created: ${claim_id}`);

        // Trigger AI verification asynchronously (don't wait)
        triggerAIVerification(claim_id, geometry, claim_type, calculatedArea)
            .catch(err => console.error('AI verification failed:', err));

        // Notify officers about new claim
        notifyClaimUpdate(req, newClaim, 'submitted', `New claim ${claim_id} submitted by ${claimant_name}`);

        res.status(201).json({
            success: true,
            message: 'Claim created successfully',
            data: {
                claim_id: newClaim.claim_id,
                claimant_name: newClaim.claimant_name,
                status: newClaim.status,
                area_ha: newClaim.area_ha,
                village: newClaim.village,
                district: newClaim.district,
                state: newClaim.state,
                created_date: newClaim.created_date,
                geometry: geometry
            }
        });

    } catch (error) {
        console.error('❌ Create claim with geometry error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to create claim',
            details: error.message
        });
    }
};

// Helper: Get village data by code
async function getVillageDataByCode(villageCode) {
    // In production, query database
    // For now, return mock data
    return {
        village_code: villageCode,
        village_name: villageCode,
        district_name: 'Bhopal',
        state_name: 'Madhya Pradesh',
        state_code: 'MP'
    };
}

// Helper: Generate claim ID with geometry
async function generateClaimIdWithGeometry(state, district) {
    const year = new Date().getFullYear();
    
    // Get state code (first 2 letters)
    const stateCode = state.substring(0, 2).toUpperCase();
    
    // Get district code (first 3 letters)
    const districtCode = district.substring(0, 3).toUpperCase();
    
    // Count existing claims for this year (in production, query database)
    const existingClaims = mockClaims.filter(c => 
        c.claim_id && c.claim_id.includes(year.toString())
    );
    const count = existingClaims.length + 1;
    
    // Format: FRA-{STATE}-{DISTRICT}-{YEAR}-{NUMBER}
    return `FRA-${stateCode}-${districtCode}-${year}-${String(count).padStart(3, '0')}`;
}

// Helper: Trigger AI verification
async function triggerAIVerification(claim_id, geometry, claim_type, area_ha) {
    try {
        console.log(`🤖 Triggering AI verification for ${claim_id}...`);
        
        // In production, call AI service
        // const response = await axios.post('http://localhost:5000/ai/verify-claim', {
        //     claim_id,
        //     geometry,
        //     claim_type,
        //     area_ha
        // });
        
        // For now, simulate AI verification with random score
        setTimeout(() => {
            const ai_score = Math.floor(Math.random() * (95 - 70 + 1)) + 70;
            const confidence = ai_score >= 85 ? 'High' : ai_score >= 70 ? 'Medium' : 'Low';
            
            // Update claim with AI results (in production, update database)
            const claim = mockClaims.find(c => c.claim_id === claim_id);
            if (claim) {
                claim.ai_score = ai_score;
                claim.ai_confidence = confidence;
                claim.recommended_scheme = getRecommendedScheme(claim_type);
                claim.verified_date = new Date().toISOString();
                
                console.log(`✅ AI verification complete for ${claim_id}: ${ai_score}% (${confidence})`);
            }
        }, 3000); // Simulate 3 second processing time
        
    } catch (error) {
        console.error(`❌ AI verification failed for ${claim_id}:`, error);
        // Queue for retry (in production)
    }
}

// Helper: Get recommended scheme based on claim type
function getRecommendedScheme(claim_type) {
    const schemes = {
        'IFR': 'PM-KISAN',
        'CFR': 'MGNREGA',
        'CR': 'DAJGUA'
    };
    return schemes[claim_type] || 'PM-KISAN';
}

module.exports = {
    getClaims,
    getClaimById,
    createClaim,
    createClaimWithGeometry,
    updateClaimStatus,
    deleteClaim
};