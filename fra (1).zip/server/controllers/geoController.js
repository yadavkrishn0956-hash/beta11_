const fs = require('fs').promises;
const path = require('path');
const cacheManager = require('../utils/cacheManager');

// Data file paths
const DATA_DIR = path.join(__dirname, '../data/geo');
const STATES_FILE = path.join(DATA_DIR, 'states.json');
const DISTRICTS_FILE = path.join(DATA_DIR, 'districts.json');
const VILLAGES_FILE = path.join(DATA_DIR, 'villages.json');

// Cache TTL: 24 hours
const CACHE_TTL = 24 * 60 * 60 * 1000;

/**
 * Get all states
 * @route GET /api/geo/states
 */
const getStates = async (req, res) => {
    try {
        // Check cache first
        const cacheKey = 'geo:states';
        const cachedData = cacheManager.get(cacheKey);
        
        if (cachedData) {
            return res.json({
                success: true,
                data: cachedData,
                cached: true
            });
        }

        // Read from file
        const fileData = await fs.readFile(STATES_FILE, 'utf8');
        const states = JSON.parse(fileData);

        // Cache the data
        cacheManager.set(cacheKey, states, CACHE_TTL);

        res.json({
            success: true,
            data: states,
            cached: false
        });

    } catch (error) {
        console.error('Get states error:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'STATES_LOAD_ERROR',
                message: 'Failed to load states data',
                details: error.message
            }
        });
    }
};

/**
 * Get districts by state code
 * @route GET /api/geo/districts/:stateCode
 */
const getDistricts = async (req, res) => {
    try {
        const { stateCode } = req.params;

        // Validate state code
        if (!stateCode || stateCode.length < 2) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 'INVALID_STATE_CODE',
                    message: 'Invalid state code provided',
                    details: 'State code must be at least 2 characters'
                }
            });
        }

        // Check cache first
        const cacheKey = `geo:districts:${stateCode}`;
        const cachedData = cacheManager.get(cacheKey);
        
        if (cachedData) {
            return res.json({
                success: true,
                data: cachedData,
                cached: true
            });
        }

        // Read from file
        const fileData = await fs.readFile(DISTRICTS_FILE, 'utf8');
        const allDistricts = JSON.parse(fileData);

        // Filter by state code
        const districts = allDistricts.filter(d => d.state_code === stateCode);

        if (districts.length === 0) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 'NO_DISTRICTS_FOUND',
                    message: `No districts found for state code '${stateCode}'`,
                    details: 'Please verify the state code and try again'
                }
            });
        }

        // Cache the filtered data
        cacheManager.set(cacheKey, districts, CACHE_TTL);

        res.json({
            success: true,
            data: districts,
            cached: false
        });

    } catch (error) {
        console.error('Get districts error:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'DISTRICTS_LOAD_ERROR',
                message: 'Failed to load districts data',
                details: error.message
            }
        });
    }
};

/**
 * Get villages by district code
 * @route GET /api/geo/villages/:districtCode
 */
const getVillages = async (req, res) => {
    try {
        const { districtCode } = req.params;

        // Validate district code
        if (!districtCode || districtCode.length < 3) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 'INVALID_DISTRICT_CODE',
                    message: 'Invalid district code provided',
                    details: 'District code must be at least 3 characters'
                }
            });
        }

        // Check cache first
        const cacheKey = `geo:villages:${districtCode}`;
        const cachedData = cacheManager.get(cacheKey);
        
        if (cachedData) {
            return res.json({
                success: true,
                data: cachedData,
                cached: true
            });
        }

        // Read from file
        const fileData = await fs.readFile(VILLAGES_FILE, 'utf8');
        const allVillages = JSON.parse(fileData);

        // Filter by district code
        const villages = allVillages.filter(v => v.district_code === districtCode);

        if (villages.length === 0) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 'NO_VILLAGES_FOUND',
                    message: `No villages found for district code '${districtCode}'`,
                    details: 'Please verify the district code and try again'
                }
            });
        }

        // Cache the filtered data
        cacheManager.set(cacheKey, villages, CACHE_TTL);

        res.json({
            success: true,
            data: villages,
            cached: false
        });

    } catch (error) {
        console.error('Get villages error:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'VILLAGES_LOAD_ERROR',
                message: 'Failed to load villages data',
                details: error.message
            }
        });
    }
};

/**
 * Search locations (states, districts, villages)
 * @route GET /api/geo/search?q=query
 */
const searchLocations = async (req, res) => {
    try {
        const { q } = req.query;

        if (!q || q.trim().length < 2) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 'INVALID_SEARCH_QUERY',
                    message: 'Search query must be at least 2 characters',
                    details: 'Please provide a valid search term'
                }
            });
        }

        const query = q.toLowerCase().trim();
        const results = [];

        // Search states
        const statesData = await fs.readFile(STATES_FILE, 'utf8');
        const states = JSON.parse(statesData);
        states.forEach(state => {
            if (state.state_name.toLowerCase().includes(query)) {
                results.push({
                    type: 'state',
                    state_code: state.state_code,
                    state_name: state.state_name,
                    match_score: calculateMatchScore(query, state.state_name.toLowerCase())
                });
            }
        });

        // Search districts
        const districtsData = await fs.readFile(DISTRICTS_FILE, 'utf8');
        const districts = JSON.parse(districtsData);
        districts.forEach(district => {
            if (district.district_name.toLowerCase().includes(query)) {
                results.push({
                    type: 'district',
                    district_code: district.district_code,
                    district_name: district.district_name,
                    state_code: district.state_code,
                    match_score: calculateMatchScore(query, district.district_name.toLowerCase())
                });
            }
        });

        // Search villages
        const villagesData = await fs.readFile(VILLAGES_FILE, 'utf8');
        const villages = JSON.parse(villagesData);
        villages.forEach(village => {
            if (village.village_name.toLowerCase().includes(query)) {
                results.push({
                    type: 'village',
                    village_code: village.village_code,
                    village_name: village.village_name,
                    district_code: village.district_code,
                    geometry: village.geometry,
                    match_score: calculateMatchScore(query, village.village_name.toLowerCase())
                });
            }
        });

        // Sort by match score and limit to top 10
        results.sort((a, b) => b.match_score - a.match_score);
        const topResults = results.slice(0, 10);

        res.json({
            success: true,
            data: topResults,
            total: results.length
        });

    } catch (error) {
        console.error('Search locations error:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'SEARCH_ERROR',
                message: 'Failed to search locations',
                details: error.message
            }
        });
    }
};

/**
 * Calculate match score for search results
 * @param {string} query - Search query
 * @param {string} target - Target string to match
 * @returns {number} Match score (0-1)
 */
function calculateMatchScore(query, target) {
    // Exact match
    if (target === query) return 1.0;
    
    // Starts with query
    if (target.startsWith(query)) return 0.9;
    
    // Contains query
    if (target.includes(query)) return 0.7;
    
    // Fuzzy match (simple implementation)
    const distance = levenshteinDistance(query, target);
    const maxLength = Math.max(query.length, target.length);
    return 1 - (distance / maxLength);
}

/**
 * Calculate Levenshtein distance between two strings
 * @param {string} a - First string
 * @param {string} b - Second string
 * @returns {number} Edit distance
 */
function levenshteinDistance(a, b) {
    const matrix = [];

    for (let i = 0; i <= b.length; i++) {
        matrix[i] = [i];
    }

    for (let j = 0; j <= a.length; j++) {
        matrix[0][j] = j;
    }

    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1,
                    matrix[i][j - 1] + 1,
                    matrix[i - 1][j] + 1
                );
            }
        }
    }

    return matrix[b.length][a.length];
}

/**
 * Get cache statistics
 * @route GET /api/geo/cache/stats
 */
const getCacheStats = (req, res) => {
    const stats = cacheManager.getStats();
    res.json({
        success: true,
        data: stats
    });
};

/**
 * Clear cache
 * @route POST /api/geo/cache/clear
 */
const clearCache = (req, res) => {
    cacheManager.clear();
    res.json({
        success: true,
        message: 'Cache cleared successfully'
    });
};

module.exports = {
    getStates,
    getDistricts,
    getVillages,
    searchLocations,
    getCacheStats,
    clearCache
};
