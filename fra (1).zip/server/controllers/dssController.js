const { pool } = require('../config/db');
const { aiServiceClient } = require('../utils/aiService');
const { notifyAIRecommendation, notifyVerificationComplete } = require('../utils/notifications');

// Mock schemes data for fallback
const mockSchemes = [
    {
        id: 1,
        scheme_name: 'PM-KISAN',
        scheme_code: 'PM_KISAN',
        description: 'Pradhan Mantri Kisan Samman Nidhi Yojana - Financial support to farmers',
        eligibility_criteria: {
            land_area: { max: 3 },
            farmer: true,
            rural: true
        },
        benefits: 'Rs. 6000 per year in three installments',
        ministry: 'Ministry of Agriculture and Farmers Welfare',
        priority: 'high'
    },
    {
        id: 2,
        scheme_name: 'Jal Jeevan Mission',
        scheme_code: 'JJM',
        description: 'Har Ghar Jal - Providing functional household tap connection to every rural household',
        eligibility_criteria: {
            water_access: false,
            rural: true,
            tribal_area: true
        },
        benefits: 'Functional household tap connection with assured water supply',
        ministry: 'Ministry of Jal Shakti',
        priority: 'high'
    },
    {
        id: 3,
        scheme_name: 'MGNREGA',
        scheme_code: 'MGNREGA',
        description: 'Mahatma Gandhi National Rural Employment Guarantee Act',
        eligibility_criteria: {
            rural: true,
            employment_needed: true,
            soil_condition: 'degraded'
        },
        benefits: '100 days guaranteed employment per year with minimum wage',
        ministry: 'Ministry of Rural Development',
        priority: 'medium'
    },
    {
        id: 4,
        scheme_name: 'Green India Mission',
        scheme_code: 'GIM',
        description: 'National Mission for a Green India - Forest conservation and enhancement',
        eligibility_criteria: {
            forest_cover: { min: 70 },
            tribal_area: true,
            claim_type: ['IFR', 'CFR']
        },
        benefits: 'Forest conservation support, livelihood enhancement, and ecosystem services',
        ministry: 'Ministry of Environment, Forest and Climate Change',
        priority: 'medium'
    },
    {
        id: 5,
        scheme_name: 'DAJGUA',
        scheme_code: 'DAJGUA',
        description: 'Development Action Plan for Scheduled Tribes',
        eligibility_criteria: {
            tribal_area: true,
            rural: true
        },
        benefits: 'Comprehensive tribal development support',
        ministry: 'Ministry of Tribal Affairs',
        priority: 'high'
    }
];

// AI-powered scheme recommendations
const getSchemeRecommendations = async (req, res) => {
    try {
        const {
            claim_id,
            land_area,
            village,
            district,
            state,
            claim_type,
            water_access = false,
            soil_condition = 'good',
            forest_cover = 50,
            tribal_area = true,
            employment_needed = false,
            housing_needed = false,
            latitude,
            longitude
        } = req.body;

        const user = req.user;
        
        console.log('🤖 Processing DSS recommendation request:', {
            claim_id,
            land_area,
            district,
            state,
            user: user?.name
        });

        // Prepare data for AI service
        const claimData = {
            claim_id,
            land_area: parseFloat(land_area),
            village,
            district,
            state,
            claim_type: claim_type || 'IFR',
            water_index: water_access ? 0.8 : 0.3, // Convert boolean to index
            soil_quality: soil_condition,
            forest_cover: parseFloat(forest_cover),
            tribal_area,
            employment_needed,
            housing_needed,
            latitude: latitude ? parseFloat(latitude) : null,
            longitude: longitude ? parseFloat(longitude) : null
        };

        // Get AI-powered recommendations
        const aiResponse = await aiServiceClient.getRecommendations(claimData);
        
        if (aiResponse.success) {
            // AI service successful
            const aiData = aiResponse.data;
            
            // Format response for frontend compatibility
            const response = {
                claim_id: aiData.claim_id,
                applicant_profile: {
                    land_area: claimData.land_area,
                    village: claimData.village,
                    district: claimData.district,
                    state: claimData.state,
                    claim_type: claimData.claim_type,
                    water_access: water_access,
                    soil_condition: soil_condition,
                    forest_cover: claimData.forest_cover,
                    tribal_area: tribal_area,
                    employment_needed: employment_needed
                },
                total_schemes_found: aiData.total_schemes,
                schemes: aiData.schemes.map(scheme => ({
                    scheme_id: scheme.scheme_code,
                    scheme_name: scheme.scheme_name,
                    scheme_code: scheme.scheme_code,
                    description: scheme.description,
                    benefits: scheme.benefits,
                    ministry: scheme.ministry,
                    eligibility_percentage: Math.round(scheme.eligibility_score),
                    priority: scheme.priority,
                    application_process: scheme.application_process,
                    estimated_benefit: scheme.estimated_benefit,
                    confidence: scheme.confidence
                })),
                priority: aiData.priority,
                confidence_score: aiData.confidence_score,
                recommendation_date: aiData.recommendation_date,
                generated_by: user?.name || 'AI System',
                ai_insights: aiData.ai_insights || [],
                next_steps: aiData.next_steps || [],
                processing_time_ms: aiData.processing_time_ms,
                ai_powered: true,
                fallback_used: aiResponse.fallback || false
            };

            // Log successful AI processing
            console.log(`✅ AI recommendations generated: ${aiData.total_schemes} schemes in ${aiData.processing_time_ms}ms`);

            // Notify about AI recommendations
            notifyAIRecommendation(req, claimData, response);

            res.json({
                success: true,
                message: `AI found ${aiData.total_schemes} eligible schemes`,
                data: response
            });

        } else {
            // AI service failed, use fallback
            console.log('⚠️ AI service failed, using fallback logic');
            const fallbackResponse = getFallbackRecommendations(claimData, user);
            
            res.json({
                success: true,
                message: `Found ${fallbackResponse.total_schemes_found} eligible schemes (fallback mode)`,
                data: fallbackResponse
            });
        }

    } catch (error) {
        console.error('DSS recommendation error:', error);
        
        // Return fallback recommendations on error
        try {
            const fallbackResponse = getFallbackRecommendations(req.body, req.user);
            
            res.json({
                success: true,
                message: `Found ${fallbackResponse.total_schemes_found} eligible schemes (error fallback)`,
                data: fallbackResponse,
                warning: 'AI service temporarily unavailable'
            });
            
        } catch (fallbackError) {
            console.error('Fallback also failed:', fallbackError);
            
            res.status(500).json({
                success: false,
                message: 'Failed to generate scheme recommendations',
                error: error.message
            });
        }
    }
};

// Fallback recommendation logic
const getFallbackRecommendations = (claimData, user) => {
    const {
        claim_id,
        land_area,
        village,
        district,
        state,
        claim_type,
        water_access = false,
        soil_condition = 'good',
        forest_cover = 50,
        tribal_area = true,
        employment_needed = false
    } = claimData;

    const eligibleSchemes = [];
    
    // Simple rule-based logic
    if (parseFloat(land_area) <= 3.0) {
        eligibleSchemes.push({
            scheme_id: 'PM_KISAN',
            scheme_name: 'PM-KISAN',
            scheme_code: 'PM_KISAN',
            description: 'Pradhan Mantri Kisan Samman Nidhi Yojana',
            benefits: 'Rs. 6000 per year in three installments',
            ministry: 'Ministry of Agriculture and Farmers Welfare',
            eligibility_percentage: 90,
            priority: 'high',
            application_process: 'Online through PM-KISAN portal',
            estimated_benefit: 'Rs. 6,000/year',
            confidence: 0.9
        });
    }

    if (!water_access || parseFloat(forest_cover) < 40) {
        eligibleSchemes.push({
            scheme_id: 'JJM',
            scheme_name: 'Jal Jeevan Mission',
            scheme_code: 'JJM',
            description: 'Providing tap water connection to every household',
            benefits: 'Functional household tap connection',
            ministry: 'Ministry of Jal Shakti',
            eligibility_percentage: 85,
            priority: 'high',
            application_process: 'Through Gram Panchayat',
            estimated_benefit: 'Tap water connection',
            confidence: 0.85
        });
    }

    if (soil_condition === 'poor' || soil_condition === 'degraded' || employment_needed) {
        eligibleSchemes.push({
            scheme_id: 'MGNREGA',
            scheme_name: 'MGNREGA',
            scheme_code: 'MGNREGA',
            description: 'Employment guarantee and land development',
            benefits: '100 days guaranteed employment per year',
            ministry: 'Ministry of Rural Development',
            eligibility_percentage: 80,
            priority: 'medium',
            application_process: 'Job card registration at Gram Panchayat',
            estimated_benefit: 'Rs. 200-300/day for 100 days',
            confidence: 0.8
        });
    }

    if (parseFloat(forest_cover) >= 70) {
        eligibleSchemes.push({
            scheme_id: 'GIM',
            scheme_name: 'Green India Mission',
            scheme_code: 'GIM',
            description: 'Forest conservation and enhancement',
            benefits: 'Forest conservation support and livelihood',
            ministry: 'Ministry of Environment, Forest and Climate Change',
            eligibility_percentage: 75,
            priority: 'medium',
            application_process: 'Through Forest Department',
            estimated_benefit: 'Conservation incentives',
            confidence: 0.75
        });
    }

    if (tribal_area) {
        eligibleSchemes.push({
            scheme_id: 'DAJGUA',
            scheme_name: 'DAJGUA',
            scheme_code: 'DAJGUA',
            description: 'Development Action Plan for Scheduled Tribes',
            benefits: 'Comprehensive tribal development support',
            ministry: 'Ministry of Tribal Affairs',
            eligibility_percentage: 85,
            priority: 'high',
            application_process: 'Through Tribal Development Office',
            estimated_benefit: 'Comprehensive support',
            confidence: 0.85
        });
    }

    // Remove duplicates and sort by eligibility percentage
    const uniqueSchemes = eligibleSchemes.filter((scheme, index, self) =>
        index === self.findIndex(s => s.scheme_code === scheme.scheme_code)
    ).sort((a, b) => b.eligibility_percentage - a.eligibility_percentage);

    const priority = uniqueSchemes.length >= 3 ? 'high' : uniqueSchemes.length >= 2 ? 'medium' : 'low';

    return {
        claim_id: claim_id || null,
        applicant_profile: {
            land_area: parseFloat(land_area),
            village,
            district,
            state,
            claim_type: claim_type || 'IFR',
            water_access,
            soil_condition,
            forest_cover: parseFloat(forest_cover),
            tribal_area,
            employment_needed
        },
        total_schemes_found: uniqueSchemes.length,
        schemes: uniqueSchemes,
        priority,
        confidence_score: uniqueSchemes.length > 0 ? 
            uniqueSchemes.reduce((sum, s) => sum + s.confidence, 0) / uniqueSchemes.length : 0,
        recommendation_date: new Date().toISOString(),
        generated_by: user?.name || 'Fallback System',
        ai_insights: [
            '⚠️ Using rule-based recommendations (AI service unavailable)',
            `📊 Found ${uniqueSchemes.length} eligible schemes based on basic criteria`
        ],
        next_steps: [
            'Review eligible schemes and their requirements',
            'Gather required documents for applications',
            'Visit nearest service center or Gram Panchayat',
            'Contact scheme helplines for detailed guidance'
        ],
        processing_time_ms: 25,
        ai_powered: false,
        fallback_used: true
    };
};

// Get all available schemes
const getAllSchemes = async (req, res) => {
    try {
        res.json({
            success: true,
            data: {
                schemes: mockSchemes,
                total_schemes: mockSchemes.length
            }
        });
    } catch (error) {
        console.error('Get schemes error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch schemes',
            error: error.message
        });
    }
};

// Get AI service status
const getAIServiceStatus = async (req, res) => {
    try {
        const healthCheck = await aiServiceClient.healthCheck();
        const modelStatus = await aiServiceClient.getModelStatus();
        const analytics = await aiServiceClient.getAnalytics();

        res.json({
            success: true,
            data: {
                health: healthCheck,
                models: modelStatus.success ? modelStatus.data : null,
                analytics: analytics.success ? analytics.data : null,
                timestamp: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error('AI service status error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get AI service status',
            error: error.message
        });
    }
};

// Verify claim using AI
const verifyClaimAI = async (req, res) => {
    try {
        const claimData = req.body;
        const user = req.user;

        console.log('🔍 Processing AI claim verification:', {
            claim_id: claimData.claim_id,
            user: user?.name
        });

        const verificationResult = await aiServiceClient.verifyClaim(claimData);

        if (verificationResult.success) {
            // Notify about verification completion
            notifyVerificationComplete(req, claimData, verificationResult.data);
            
            res.json({
                success: true,
                message: 'Claim verification completed',
                data: verificationResult.data
            });
        } else {
            res.json({
                success: false,
                message: 'Claim verification failed',
                data: verificationResult.data,
                error: verificationResult.error
            });
        }

    } catch (error) {
        console.error('AI claim verification error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to verify claim',
            error: error.message
        });
    }
};

module.exports = {
    getSchemeRecommendations,
    getAllSchemes,
    getAIServiceStatus,
    verifyClaimAI
};