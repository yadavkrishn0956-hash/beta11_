const { pool } = require('../config/db');
const { notifyNewFeedback } = require('../utils/notifications');

// Mock feedback data for demo
const mockFeedback = [
    {
        id: 1,
        user_id: 4,
        category: 'System Performance',
        subject: 'Slow loading of claims page',
        message: 'The claims page takes too long to load. Please optimize the performance.',
        rating: 3,
        status: 'open',
        priority: 'medium',
        assigned_to: null,
        response: null,
        created_at: new Date('2025-01-20'),
        updated_at: new Date('2025-01-20')
    },
    {
        id: 2,
        user_id: 4,
        category: 'Feature Request',
        subject: 'Mobile app needed',
        message: 'Please develop a mobile application for easier access to FRA services.',
        rating: 4,
        status: 'in_progress',
        priority: 'high',
        assigned_to: 1,
        response: 'We are working on a mobile app. Expected release in Q2 2025.',
        created_at: new Date('2025-01-18'),
        updated_at: new Date('2025-01-22')
    },
    {
        id: 3,
        user_id: 4,
        category: 'Bug Report',
        subject: 'Document upload fails',
        message: 'Unable to upload PDF documents larger than 5MB.',
        rating: 2,
        status: 'resolved',
        priority: 'high',
        assigned_to: 1,
        response: 'File size limit increased to 10MB. Issue resolved.',
        created_at: new Date('2025-01-15'),
        updated_at: new Date('2025-01-19')
    }
];

// Submit new feedback
const submitFeedback = async (req, res) => {
    try {
        const { category, subject, message, rating, priority } = req.body;
        const user = req.user;

        const newFeedback = {
            id: mockFeedback.length + 1,
            user_id: user.id,
            category,
            subject,
            message,
            rating: rating || null,
            status: 'open',
            priority: priority || 'medium',
            assigned_to: null,
            response: null,
            created_at: new Date(),
            updated_at: new Date()
        };

        // In real app, save to database
        mockFeedback.push(newFeedback);

        // Notify officers about new feedback
        notifyNewFeedback(req, newFeedback);

        res.status(201).json({
            success: true,
            message: 'Feedback submitted successfully',
            data: newFeedback
        });

    } catch (error) {
        console.error('Submit feedback error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to submit feedback',
            error: error.message
        });
    }
};

// Get feedback (for officers/admin)
const getFeedback = async (req, res) => {
    try {
        const { status, priority, category, page = 1, limit = 10 } = req.query;
        const user = req.user || { role: 'admin' }; // Default to admin for demo mode

        // Only officers and admin can view feedback
        if (req.user && user.role === 'citizen') {
            // Citizens can only see their own feedback
            const userFeedback = mockFeedback.filter(f => f.user_id === user.id);
            return res.json({
                success: true,
                data: {
                    feedback: userFeedback,
                    pagination: {
                        current_page: 1,
                        total_pages: 1,
                        total_records: userFeedback.length,
                        per_page: userFeedback.length
                    }
                }
            });
        }

        let filteredFeedback = [...mockFeedback];

        // Apply filters
        if (status) {
            filteredFeedback = filteredFeedback.filter(f => f.status === status);
        }

        if (priority) {
            filteredFeedback = filteredFeedback.filter(f => f.priority === priority);
        }

        if (category) {
            filteredFeedback = filteredFeedback.filter(f => 
                f.category.toLowerCase().includes(category.toLowerCase())
            );
        }

        // Pagination
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + parseInt(limit);
        const paginatedFeedback = filteredFeedback.slice(startIndex, endIndex);

        // Calculate statistics
        const stats = {
            total: filteredFeedback.length,
            open: filteredFeedback.filter(f => f.status === 'open').length,
            in_progress: filteredFeedback.filter(f => f.status === 'in_progress').length,
            resolved: filteredFeedback.filter(f => f.status === 'resolved').length,
            closed: filteredFeedback.filter(f => f.status === 'closed').length,
            avg_rating: filteredFeedback.reduce((sum, f) => sum + (f.rating || 0), 0) / filteredFeedback.length
        };

        res.json({
            success: true,
            data: {
                feedback: paginatedFeedback,
                pagination: {
                    current_page: parseInt(page),
                    total_pages: Math.ceil(filteredFeedback.length / limit),
                    total_records: filteredFeedback.length,
                    per_page: parseInt(limit)
                },
                statistics: stats
            }
        });

    } catch (error) {
        console.error('Get feedback error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch feedback',
            error: error.message
        });
    }
};

// Update feedback status/response
const updateFeedback = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, response, assigned_to } = req.body;
        const user = req.user;

        // Only officers and admin can update feedback
        if (user.role === 'citizen') {
            return res.status(403).json({
                success: false,
                message: 'Citizens cannot update feedback status'
            });
        }

        const feedbackIndex = mockFeedback.findIndex(f => f.id === parseInt(id));

        if (feedbackIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Feedback not found'
            });
        }

        // Update feedback
        mockFeedback[feedbackIndex] = {
            ...mockFeedback[feedbackIndex],
            status: status || mockFeedback[feedbackIndex].status,
            response: response || mockFeedback[feedbackIndex].response,
            assigned_to: assigned_to || mockFeedback[feedbackIndex].assigned_to,
            updated_at: new Date()
        };

        res.json({
            success: true,
            message: 'Feedback updated successfully',
            data: mockFeedback[feedbackIndex]
        });

    } catch (error) {
        console.error('Update feedback error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update feedback',
            error: error.message
        });
    }
};

// Get feedback by ID
const getFeedbackById = async (req, res) => {
    try {
        const { id } = req.params;
        const user = req.user;

        const feedback = mockFeedback.find(f => f.id === parseInt(id));

        if (!feedback) {
            return res.status(404).json({
                success: false,
                message: 'Feedback not found'
            });
        }

        // Check access permissions
        if (user.role === 'citizen' && feedback.user_id !== user.id) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        res.json({
            success: true,
            data: feedback
        });

    } catch (error) {
        console.error('Get feedback by ID error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch feedback',
            error: error.message
        });
    }
};

module.exports = {
    submitFeedback,
    getFeedback,
    updateFeedback,
    getFeedbackById
};