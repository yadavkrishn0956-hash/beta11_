const { generatePDFReport } = require('../utils/pdfGenerator');
const { generateExcelReport } = require('../utils/excelGenerator');
const { sendReportEmail } = require('../utils/emailReports');

/**
 * Get mock report data
 * In production, this would query the database
 */
function getMockReportData(startDate, endDate) {
    return {
        totalClaims: 150,
        approvedClaims: 95,
        pendingClaims: 40,
        rejectedClaims: 15,
        avgProcessingDays: 12,
        districtPerformance: [
            { district: 'Ranchi', filed: 50, approved: 32, pending: 15, avgDays: 10 },
            { district: 'Dhanbad', filed: 60, approved: 38, pending: 18, avgDays: 11 },
            { district: 'Hazaribagh', filed: 40, approved: 25, pending: 7, avgDays: 14 }
        ],
        schemeImpact: [
            { scheme: 'PM-KISAN', beneficiaries: 3200, budget: '₹45.5 Cr', coverage: 85 },
            { scheme: 'Jal Jeevan Mission', beneficiaries: 2100, budget: '₹32.8 Cr', coverage: 72 },
            { scheme: 'MGNREGA', beneficiaries: 1800, budget: '₹28.2 Cr', coverage: 68 },
            { scheme: 'Green India Mission', beneficiaries: 1400, budget: '₹22.5 Cr', coverage: 65 }
        ]
    };
}

/**
 * @route   POST /api/reports/export
 * @desc    Export report as PDF or Excel
 * @access  Public (for demo)
 */
const exportReport = async (req, res) => {
    try {
        const { format, startDate, endDate } = req.query;
        
        console.log(`📊 Exporting ${format} report: ${startDate} to ${endDate}`);
        
        // Validate format
        if (!['pdf', 'excel'].includes(format)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid format. Use "pdf" or "excel"'
            });
        }
        
        // Get report data
        const reportData = getMockReportData(startDate, endDate);
        
        // Generate report
        let buffer;
        let contentType;
        let filename;
        
        if (format === 'pdf') {
            buffer = await generatePDFReport(reportData, startDate, endDate);
            contentType = 'application/pdf';
            filename = `FRA_Report_${startDate}_${endDate}.pdf`;
        } else {
            buffer = await generateExcelReport(reportData, startDate, endDate);
            contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
            filename = `FRA_Report_${startDate}_${endDate}.xlsx`;
        }
        
        // Set headers
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.setHeader('Content-Length', buffer.length);
        
        // Send file
        res.send(buffer);
        
        console.log(`✅ ${format.toUpperCase()} report exported successfully`);
        
    } catch (error) {
        console.error('❌ Error exporting report:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to export report',
            details: error.message
        });
    }
};

/**
 * @route   GET /api/reports/comprehensive
 * @desc    Generate comprehensive analytics report
 * @access  Public (for demo)
 */
const generateComprehensive = async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        
        console.log(`📊 Generating comprehensive report: ${startDate} to ${endDate}`);
        
        // Get comprehensive data
        const reportData = getMockReportData(startDate, endDate);
        
        // Add additional analytics
        const comprehensiveData = {
            ...reportData,
            summary: {
                totalClaims: reportData.totalClaims,
                approvalRate: ((reportData.approvedClaims / reportData.totalClaims) * 100).toFixed(1),
                rejectionRate: ((reportData.rejectedClaims / reportData.totalClaims) * 100).toFixed(1),
                avgProcessingDays: reportData.avgProcessingDays
            },
            trends: {
                monthlyGrowth: [420, 380, 450, 520, 480, 560, 620, 580, 640, 700],
                accuracyTrend: [85, 87, 89, 91, 88, 92, 94, 93, 95, 96]
            },
            topPerformingDistricts: reportData.districtPerformance
                .sort((a, b) => b.approved - a.approved)
                .slice(0, 3),
            schemeUtilization: reportData.schemeImpact.map(scheme => ({
                name: scheme.scheme,
                utilization: scheme.coverage,
                beneficiaries: scheme.beneficiaries
            }))
        };
        
        res.json({
            success: true,
            data: comprehensiveData,
            generated_at: new Date().toISOString()
        });
        
        console.log('✅ Comprehensive report generated');
        
    } catch (error) {
        console.error('❌ Error generating comprehensive report:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to generate comprehensive report',
            details: error.message
        });
    }
};

/**
 * @route   POST /api/reports/share
 * @desc    Share report via email
 * @access  Public (for demo)
 */
const shareReport = async (req, res) => {
    try {
        const { email, format, startDate, endDate } = req.body;
        
        console.log(`📧 Sharing ${format} report to ${email}`);
        
        // Validate inputs
        if (!email || !format || !startDate || !endDate) {
            return res.status(400).json({
                success: false,
                error: 'Missing required fields: email, format, startDate, endDate'
            });
        }
        
        // Get report data
        const reportData = getMockReportData(startDate, endDate);
        
        // Try to send email
        let emailSent = false;
        let emailError = null;
        
        try {
            const emailResult = await sendReportEmail(email, format, reportData, startDate, endDate);
            emailSent = emailResult.success;
            console.log(`✅ Email sent to ${email}:`, emailResult.messageId);
        } catch (error) {
            emailError = error.message;
            console.log(`⚠️ Email not sent (SMTP not configured): ${error.message}`);
        }
        
        res.json({
            success: true,
            message: emailSent 
                ? `Report emailed successfully to ${email}` 
                : `Report prepared for ${email} (Email not sent - configure SMTP in .env)`,
            email_sent: emailSent,
            sent_at: emailSent ? new Date().toISOString() : null,
            note: emailSent ? null : 'Configure EMAIL_USER and EMAIL_PASS in server/.env to enable email sending'
        });
        
        console.log(emailSent ? `✅ Report emailed to ${email}` : `⚠️ Report prepared but not emailed`);
        
    } catch (error) {
        console.error('❌ Error sharing report:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to share report',
            details: error.message
        });
    }
};

/**
 * @route   POST /api/reports/schedule
 * @desc    Schedule weekly report (toggle on/off)
 * @access  Public (for demo)
 */
const scheduleWeeklyReport = async (req, res) => {
    try {
        const { enabled, email } = req.body;
        
        console.log(`⏰ Weekly report schedule ${enabled ? 'enabled' : 'disabled'} for ${email}`);
        
        // In production, save this preference to database
        // For demo, just return success
        
        res.json({
            success: true,
            message: enabled 
                ? `Weekly reports will be sent to ${email} every Sunday at 9:00 AM`
                : 'Weekly report schedule disabled',
            schedule: enabled ? {
                frequency: 'weekly',
                day: 'Sunday',
                time: '09:00 AM IST',
                recipient: email
            } : null
        });
        
        console.log(`✅ Weekly report schedule updated`);
        
    } catch (error) {
        console.error('❌ Error scheduling report:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to schedule report',
            details: error.message
        });
    }
};

/**
 * @route   GET /api/reports/history
 * @desc    Get report generation history
 * @access  Public (for demo)
 */
const getReportHistory = async (req, res) => {
    try {
        // Mock history data
        const history = [
            {
                id: 1,
                type: 'comprehensive',
                format: 'pdf',
                period: '2025-01-01 to 2025-01-31',
                generated_at: '2025-01-31T10:30:00Z',
                generated_by: 'District Officer',
                status: 'completed'
            },
            {
                id: 2,
                type: 'district_performance',
                format: 'excel',
                period: '2024-12-01 to 2024-12-31',
                generated_at: '2025-01-15T14:20:00Z',
                generated_by: 'State Officer',
                status: 'completed'
            },
            {
                id: 3,
                type: 'scheme_impact',
                format: 'pdf',
                period: '2024-10-01 to 2024-12-31',
                generated_at: '2025-01-10T09:00:00Z',
                generated_by: 'Admin',
                status: 'completed'
            }
        ];
        
        res.json({
            success: true,
            data: history,
            total: history.length
        });
        
    } catch (error) {
        console.error('❌ Error fetching report history:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch report history',
            details: error.message
        });
    }
};

module.exports = {
    exportReport,
    generateComprehensive,
    shareReport,
    scheduleWeeklyReport,
    getReportHistory
};
