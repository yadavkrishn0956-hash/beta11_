const { pool } = require('../config/db');

// Mock issues data for demo
const mockIssues = [
    {
        id: 1,
        reported_by: 1,
        category: 'System Bug',
        title: 'Database connection timeout',
        description: 'Users experiencing timeout errors when accessing the claims database during peak hours.',
        priority: 'high',
        status: 'in_progress',
        assigned_to: 3,
        resolution: null,
        created_at: new Date('2025-01-22'),
        updated_at: new Date('2025-01-23')
    },
    {
        id: 2,
        reported_by: 2,
        category: 'Performance',
        title: 'Slow report generation',
        description: 'District-wise reports are taking more than 5 minutes to generate.',
        priority: 'medium',
        status: 'open',
        assigned_to: null,
        resolution: null,
        created_at: new Date('2025-01-21'),
        updated_at: new Date('2025-01-21')
    },
    {
        id: 3,
        reported_by: 1,
        category: 'Security',
        title: 'Unauthorized access attempt',
        description: 'Multiple failed login attempts detected from suspicious IP addresses.',
        priority: 'critical',
        status: 'resolved',
        assigned_to: 3,
        resolution: 'IP addresses blocked. Security measures enhanced.',
        created_at: new Date('2025-01-19'),
        updated_at: new Date('2025-01-20')
    },
    {
        id: 4,
        reported_by: 2,
        category: 'Data Integrity',
        title: 'Duplicate claim entries',
        description: 'Some claims appear to be duplicated in the system.',
        priority: 'medium',
        status: 'assigned',
        assigned_to: 1,
        resolution: null,
        created_at: new Date('2025-01-18'),
        updated_at: new Date('2025-01-22')
    }
];

// Report new issue
const reportIssue = async (req, res) => {
    try {
        const { category, title, description, priority } = req.body;
        const user = req.user;

        const newIssue = {
            id: mockIssues.length + 1,
            reported_by: user.id,
            category,
            title,
            description,
            priority: priority || 'medium',
            status: 'open',
            assigned_to: null,
            resolution: null,
            created_at: new Date(),
            updated_at: new Date()
        };

        // In real app, save to database
        mockIssues.push(newIssue);

        res.status(201).json({
            success: true,
            message: 'Issue reported successfully',
            data: newIssue
        });

    } catch (error) {
        console.error('Report issue error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to report issue',
            error: error.message
        });
    }
};

// Get issues
const getIssues = async (req, res) => {
    try {
        const { status, priority, category, assigned_to, page = 1, limit = 10 } = req.query;
        const user = req.user || { role: 'admin', id: 1 }; // Default to admin for demo

        let filteredIssues = [...mockIssues];

        // Apply role-based filtering (skip for demo if no user)
        if (req.user) {
            if (user.role === 'district') {
                // District officers see issues they reported or are assigned to
                filteredIssues = filteredIssues.filter(issue => 
                    issue.reported_by === user.id || issue.assigned_to === user.id
                );
            } else if (user.role === 'state') {
                // State officers see issues from their state
                filteredIssues = filteredIssues.filter(issue => 
                    issue.reported_by === user.id || issue.assigned_to === user.id
                );
            }
        }
        // Admin and citizens can see all issues

        // Apply query filters
        if (status) {
            filteredIssues = filteredIssues.filter(issue => issue.status === status);
        }

        if (priority) {
            filteredIssues = filteredIssues.filter(issue => issue.priority === priority);
        }

        if (category) {
            filteredIssues = filteredIssues.filter(issue => 
                issue.category.toLowerCase().includes(category.toLowerCase())
            );
        }

        if (assigned_to) {
            filteredIssues = filteredIssues.filter(issue => 
                issue.assigned_to === parseInt(assigned_to)
            );
        }

        // Pagination
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + parseInt(limit);
        const paginatedIssues = filteredIssues.slice(startIndex, endIndex);

        // Calculate statistics
        const stats = {
            total: filteredIssues.length,
            open: filteredIssues.filter(i => i.status === 'open').length,
            assigned: filteredIssues.filter(i => i.status === 'assigned').length,
            in_progress: filteredIssues.filter(i => i.status === 'in_progress').length,
            resolved: filteredIssues.filter(i => i.status === 'resolved').length,
            closed: filteredIssues.filter(i => i.status === 'closed').length,
            critical: filteredIssues.filter(i => i.priority === 'critical').length,
            high: filteredIssues.filter(i => i.priority === 'high').length,
            medium: filteredIssues.filter(i => i.priority === 'medium').length,
            low: filteredIssues.filter(i => i.priority === 'low').length
        };

        res.json({
            success: true,
            data: {
                issues: paginatedIssues,
                pagination: {
                    current_page: parseInt(page),
                    total_pages: Math.ceil(filteredIssues.length / limit),
                    total_records: filteredIssues.length,
                    per_page: parseInt(limit)
                },
                statistics: stats
            }
        });

    } catch (error) {
        console.error('Get issues error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch issues',
            error: error.message
        });
    }
};

// Update issue status/resolution
const updateIssue = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, resolution, assigned_to, priority } = req.body;
        const user = req.user;

        const issueIndex = mockIssues.findIndex(i => i.id === parseInt(id));

        if (issueIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Issue not found'
            });
        }

        const issue = mockIssues[issueIndex];

        // Check permissions
        if (user.role === 'citizen' && issue.reported_by !== user.id) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        // Update issue
        mockIssues[issueIndex] = {
            ...issue,
            status: status || issue.status,
            resolution: resolution || issue.resolution,
            assigned_to: assigned_to !== undefined ? assigned_to : issue.assigned_to,
            priority: priority || issue.priority,
            updated_at: new Date()
        };

        res.json({
            success: true,
            message: 'Issue updated successfully',
            data: mockIssues[issueIndex]
        });

    } catch (error) {
        console.error('Update issue error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update issue',
            error: error.message
        });
    }
};

// Get issue by ID
const getIssueById = async (req, res) => {
    try {
        const { id } = req.params;
        const user = req.user;

        const issue = mockIssues.find(i => i.id === parseInt(id));

        if (!issue) {
            return res.status(404).json({
                success: false,
                message: 'Issue not found'
            });
        }

        // Check access permissions
        if (user.role === 'citizen' && issue.reported_by !== user.id) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        if (user.role === 'district' && issue.reported_by !== user.id && issue.assigned_to !== user.id) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        res.json({
            success: true,
            data: issue
        });

    } catch (error) {
        console.error('Get issue by ID error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch issue',
            error: error.message
        });
    }
};

// Delete issue (admin only)
const deleteIssue = async (req, res) => {
    try {
        const { id } = req.params;
        const user = req.user;

        if (user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Only admin can delete issues'
            });
        }

        const issueIndex = mockIssues.findIndex(i => i.id === parseInt(id));

        if (issueIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Issue not found'
            });
        }

        // Remove issue
        mockIssues.splice(issueIndex, 1);

        res.json({
            success: true,
            message: 'Issue deleted successfully'
        });

    } catch (error) {
        console.error('Delete issue error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete issue',
            error: error.message
        });
    }
};

module.exports = {
    reportIssue,
    getIssues,
    updateIssue,
    getIssueById,
    deleteIssue
};