const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');

// Mock data for demo purposes
const mockUsers = [
    {
        id: 1,
        name: 'Rajesh Kumar',
        email: 'rajesh@district.gov.in',
        password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
        role: 'district',
        district: 'Ranchi',
        state: 'Jharkhand'
    },
    {
        id: 2,
        name: 'Priya Sharma',
        email: 'priya@state.gov.in',
        password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
        role: 'state',
        district: null,
        state: 'Jharkhand'
    },
    {
        id: 3,
        name: 'Admin User',
        email: 'admin@fra.gov.in',
        password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
        role: 'admin',
        district: null,
        state: null
    },
    {
        id: 4,
        name: 'Ramesh Oraon',
        email: 'ramesh@citizen.com',
        password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
        role: 'citizen',
        district: 'Ranchi',
        state: 'Jharkhand'
    }
];

// Generate JWT token
const generateToken = (userId, role) => {
    return jwt.sign(
        { userId, role },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN }
    );
};

// Register new user
const register = async (req, res) => {
    try {
        const { name, email, password, role, district, state, phone } = req.body;

        // Check if user already exists (mock check)
        const existingUser = mockUsers.find(user => user.email === email);
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'User already exists with this email'
            });
        }

        // Hash password
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // In a real app, save to database
        // For demo, we'll simulate successful registration
        const newUser = {
            id: mockUsers.length + 1,
            name,
            email,
            password: hashedPassword,
            role,
            district,
            state,
            phone,
            created_at: new Date()
        };

        // Generate token
        const token = generateToken(newUser.id, newUser.role);

        res.status(201).json({
            success: true,
            message: 'User registered successfully',
            data: {
                user: {
                    id: newUser.id,
                    name: newUser.name,
                    email: newUser.email,
                    role: newUser.role,
                    district: newUser.district,
                    state: newUser.state
                },
                token
            }
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Registration failed',
            error: error.message
        });
    }
};

// Login user
const login = async (req, res) => {
    try {
        const { email, password, role } = req.body;

        // Find user (using mock data for demo)
        const user = mockUsers.find(u => u.email === email);
        
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Check password
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Check role if provided
        if (role && user.role !== role) {
            return res.status(401).json({
                success: false,
                message: 'Invalid role for this user'
            });
        }

        // Generate token
        const token = generateToken(user.id, user.role);

        res.json({
            success: true,
            message: 'Login successful',
            data: {
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    role: user.role,
                    district: user.district,
                    state: user.state
                },
                token
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Login failed',
            error: error.message
        });
    }
};

// Get current user profile
const getProfile = async (req, res) => {
    try {
        const user = mockUsers.find(u => u.id === req.user.id);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.json({
            success: true,
            data: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role,
                district: user.district,
                state: user.state
            }
        });

    } catch (error) {
        console.error('Profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get profile',
            error: error.message
        });
    }
};

// Refresh token
const refreshToken = async (req, res) => {
    try {
        const user = req.user;
        const newToken = generateToken(user.id, user.role);

        res.json({
            success: true,
            message: 'Token refreshed successfully',
            data: {
                token: newToken
            }
        });

    } catch (error) {
        console.error('Token refresh error:', error);
        res.status(500).json({
            success: false,
            message: 'Token refresh failed',
            error: error.message
        });
    }
};

// Logout (client-side token removal)
const logout = async (req, res) => {
    res.json({
        success: true,
        message: 'Logged out successfully'
    });
};

module.exports = {
    register,
    login,
    getProfile,
    refreshToken,
    logout
};