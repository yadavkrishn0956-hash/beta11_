const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');

// Mock users for demo
const mockUsers = [
    {
        id: 1,
        name: 'Rajesh Kumar',
        email: 'rajesh@district.gov.in',
        role: 'district',
        district: 'Ranchi',
        state: 'Jharkhand',
        is_active: true
    },
    {
        id: 2,
        name: 'Priya Sharma',
        email: 'priya@state.gov.in',
        role: 'state',
        district: null,
        state: 'Jharkhand',
        is_active: true
    },
    {
        id: 3,
        name: 'Admin User',
        email: 'admin@fra.gov.in',
        role: 'admin',
        district: null,
        state: null,
        is_active: true
    },
    {
        id: 4,
        name: 'Ramesh Oraon',
        email: 'ramesh@citizen.com',
        role: 'citizen',
        district: 'Ranchi',
        state: 'Jharkhand',
        is_active: true
    }
];

// Verify JWT token
const verifyToken = async (req, res, next) => {
    try {
        const token = req.header('Authorization')?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'Access denied. No token provided.'
            });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // Find user in mock data (in real app, query database)
        const user = mockUsers.find(u => u.id === decoded.userId);

        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid token. User not found.'
            });
        }
        
        if (!user.is_active) {
            return res.status(401).json({
                success: false,
                message: 'Account is deactivated.'
            });
        }

        req.user = user;
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: 'Token expired. Please login again.'
            });
        }
        
        return res.status(401).json({
            success: false,
            message: 'Invalid token.'
        });
    }
};

// Check user roles
const roleCheck = (allowedRoles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Authentication required.'
            });
        }

        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: 'Access denied. Insufficient permissions.'
            });
        }

        next();
    };
};

// Log user actions for audit
const auditLog = async (req, res, next) => {
    const originalSend = res.send;
    
    res.send = function(data) {
        // Log the action after response is sent
        if (req.user && req.method !== 'GET') {
            console.log(`Audit: User ${req.user.id} performed ${req.method} ${req.originalUrl}`);
        }
        
        originalSend.call(this, data);
    };
    
    next();
};

module.exports = {
    verifyToken,
    roleCheck,
    auditLog
};