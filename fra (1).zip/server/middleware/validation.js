const Joi = require('joi');

// Validation schemas
const schemas = {
    register: Joi.object({
        name: Joi.string().min(2).max(100).required(),
        email: Joi.string().email().required(),
        password: Joi.string().min(6).required(),
        role: Joi.string().valid('citizen', 'district', 'state', 'admin').required(),
        district: Joi.string().max(100),
        state: Joi.string().max(100),
        phone: Joi.string().pattern(/^[0-9]{10}$/)
    }),

    login: Joi.object({
        email: Joi.string().email().required(),
        password: Joi.string().required(),
        role: Joi.string().valid('citizen', 'district', 'state', 'admin')
    }),

    claim: Joi.object({
        applicant_name: Joi.string().min(2).max(255).required(),
        village: Joi.string().min(2).max(100).required(),
        district: Joi.string().min(2).max(100).required(),
        state: Joi.string().min(2).max(100).required(),
        claim_type: Joi.string().valid('IFR', 'CFR', 'CR').required(),
        land_area: Joi.number().positive().max(1000).required(),
        latitude: Joi.number().min(-90).max(90),
        longitude: Joi.number().min(-180).max(180),
        remarks: Joi.string().max(1000)
    }),

    feedback: Joi.object({
        category: Joi.string().min(2).max(100).required(),
        subject: Joi.string().min(5).max(255).required(),
        message: Joi.string().min(10).max(2000).required(),
        rating: Joi.number().integer().min(1).max(5),
        priority: Joi.string().valid('low', 'medium', 'high', 'urgent').default('medium')
    }),

    issue: Joi.object({
        category: Joi.string().min(2).max(100).required(),
        title: Joi.string().min(5).max(255).required(),
        description: Joi.string().min(10).max(2000).required(),
        priority: Joi.string().valid('low', 'medium', 'high', 'critical').default('medium')
    }),

    updateStatus: Joi.object({
        status: Joi.string().required(),
        remarks: Joi.string().max(1000)
    }),

    dssRecommend: Joi.object({
        claim_id: Joi.number().integer().positive(),
        land_area: Joi.number().positive().required(),
        village: Joi.string().required(),
        district: Joi.string().required(),
        state: Joi.string().required(),
        claim_type: Joi.string().valid('IFR', 'CFR', 'CR').required(),
        water_access: Joi.boolean(),
        soil_condition: Joi.string().valid('good', 'degraded', 'poor'),
        forest_cover: Joi.number().min(0).max(100),
        tribal_area: Joi.boolean(),
        employment_needed: Joi.boolean()
    })
};

// Validation middleware
const validate = (schemaName) => {
    return (req, res, next) => {
        const schema = schemas[schemaName];
        
        if (!schema) {
            return res.status(500).json({
                success: false,
                message: 'Validation schema not found'
            });
        }

        const { error, value } = schema.validate(req.body, {
            abortEarly: false,
            stripUnknown: true
        });

        if (error) {
            const errors = error.details.map(detail => ({
                field: detail.path.join('.'),
                message: detail.message
            }));

            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors
            });
        }

        req.body = value;
        next();
    };
};

module.exports = {
    validate,
    schemas
};