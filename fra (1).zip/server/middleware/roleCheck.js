/**
 * Role-based access control middleware
 * Restricts access to routes based on user roles
 */

/**
 * Check if user has one of the allowed roles
 * @param {Array<string>} allowedRoles - Array of allowed role names
 * @returns {Function} Express middleware function
 */
const roleCheck = (allowedRoles) => {
    return (req, res, next) => {
        try {
            // Check if user exists (should be set by auth middleware)
            if (!req.user) {
                return res.status(401).json({
                    success: false,
                    error: 'Authentication required'
                });
            }

            // Check if user has a role
            if (!req.user.role) {
                return res.status(403).json({
                    success: false,
                    error: 'Access denied: No role assigned to user'
                });
            }

            // Normalize role to lowercase for comparison
            const userRole = req.user.role.toLowerCase();

            // Check if user's role is in the allowed roles list
            const hasPermission = allowedRoles.some(role => 
                role.toLowerCase() === userRole
            );

            if (!hasPermission) {
                return res.status(403).json({
                    success: false,
                    error: 'Access denied: Insufficient permissions',
                    details: `Required roles: ${allowedRoles.join(', ')}. Your role: ${req.user.role}`
                });
            }

            // User has permission, proceed to next middleware
            next();

        } catch (error) {
            console.error('Role check error:', error);
            return res.status(500).json({
                success: false,
                error: 'Internal server error during role verification'
            });
        }
    };
};

module.exports = roleCheck;
