#!/bin/bash

# FRA Atlas Backend Startup Script

echo "🚀 Starting FRA Atlas & DSS Backend Server..."
echo "================================================"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js v16 or higher."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 16 ]; then
    echo "❌ Node.js version 16 or higher is required. Current version: $(node -v)"
    exit 1
fi

echo "✅ Node.js version: $(node -v)"

# Check if package.json exists
if [ ! -f "package.json" ]; then
    echo "❌ package.json not found. Please run this script from the server directory."
    exit 1
fi

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install dependencies."
        exit 1
    fi
    echo "✅ Dependencies installed successfully."
else
    echo "✅ Dependencies already installed."
fi

# Create uploads directory if it doesn't exist
if [ ! -d "uploads" ]; then
    mkdir -p uploads
    echo "✅ Created uploads directory."
fi

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "⚠️  .env file not found. Using default configuration."
    echo "   You can create a .env file to customize settings."
else
    echo "✅ Environment configuration loaded."
fi

# Start the server
echo ""
echo "🌟 Starting FRA Atlas Backend Server..."
echo "   - API will be available at: http://localhost:5000"
echo "   - Health check: http://localhost:5000/api/health"
echo "   - API documentation: http://localhost:5000/"
echo ""
echo "📝 Demo Users:"
echo "   - District Officer: rajesh@district.gov.in / password"
echo "   - State Officer: priya@state.gov.in / password"
echo "   - Admin: admin@fra.gov.in / password"
echo "   - Citizen: ramesh@citizen.com / password"
echo ""
echo "Press Ctrl+C to stop the server"
echo "================================================"

# Check if we should run in development mode
if [ "$1" = "dev" ] || [ "$NODE_ENV" = "development" ]; then
    if command -v nodemon &> /dev/null; then
        echo "🔄 Running in development mode with auto-reload..."
        nodemon app.js
    else
        echo "⚠️  nodemon not found. Installing..."
        npm install -g nodemon
        nodemon app.js
    fi
else
    echo "🚀 Running in production mode..."
    node app.js
fi