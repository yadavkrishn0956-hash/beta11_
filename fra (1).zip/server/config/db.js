const { Pool } = require('pg');
require('dotenv').config();

// PostgreSQL connection configuration
const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'fra_atlas_db',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'password',
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
});

// Test database connection
const testConnection = async () => {
    try {
        const client = await pool.connect();
        console.log('✅ PostgreSQL connected successfully');
        client.release();
        return true;
    } catch (error) {
        console.log('❌ PostgreSQL connection failed:', error.message);
        console.log('📝 Using mock data for demo purposes');
        return false;
    }
};

// Initialize database tables
const initializeTables = async () => {
    const createTablesQuery = `
        -- Users table
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL CHECK (role IN ('citizen', 'district', 'state', 'admin')),
            district VARCHAR(100),
            state VARCHAR(100),
            phone VARCHAR(20),
            is_active BOOLEAN DEFAULT true,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Claims table
        CREATE TABLE IF NOT EXISTS claims (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id),
            claim_number VARCHAR(50) UNIQUE NOT NULL,
            applicant_name VARCHAR(255) NOT NULL,
            village VARCHAR(100) NOT NULL,
            district VARCHAR(100) NOT NULL,
            state VARCHAR(100) NOT NULL,
            claim_type VARCHAR(50) NOT NULL CHECK (claim_type IN ('IFR', 'CFR', 'CR')),
            land_area DECIMAL(10,2) NOT NULL,
            latitude DECIMAL(10,8),
            longitude DECIMAL(11,8),
            status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'under_review')),
            document_url VARCHAR(500),
            remarks TEXT,
            reviewed_by INTEGER REFERENCES users(id),
            reviewed_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Feedback table
        CREATE TABLE IF NOT EXISTS feedback (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id),
            category VARCHAR(100) NOT NULL,
            subject VARCHAR(255) NOT NULL,
            message TEXT NOT NULL,
            rating INTEGER CHECK (rating >= 1 AND rating <= 5),
            status VARCHAR(50) DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
            priority VARCHAR(20) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
            assigned_to INTEGER REFERENCES users(id),
            response TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Issues table
        CREATE TABLE IF NOT EXISTS issues (
            id SERIAL PRIMARY KEY,
            reported_by INTEGER REFERENCES users(id),
            category VARCHAR(100) NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT NOT NULL,
            priority VARCHAR(20) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
            status VARCHAR(50) DEFAULT 'open' CHECK (status IN ('open', 'assigned', 'in_progress', 'resolved', 'closed')),
            assigned_to INTEGER REFERENCES users(id),
            resolution TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Reports table
        CREATE TABLE IF NOT EXISTS reports (
            id SERIAL PRIMARY KEY,
            generated_by INTEGER REFERENCES users(id),
            report_type VARCHAR(100) NOT NULL,
            title VARCHAR(255) NOT NULL,
            filters JSONB,
            file_url VARCHAR(500),
            status VARCHAR(50) DEFAULT 'generating' CHECK (status IN ('generating', 'completed', 'failed')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Schemes table (for DSS recommendations)
        CREATE TABLE IF NOT EXISTS schemes (
            id SERIAL PRIMARY KEY,
            scheme_name VARCHAR(255) NOT NULL,
            scheme_code VARCHAR(50) UNIQUE NOT NULL,
            description TEXT,
            eligibility_criteria JSONB,
            benefits TEXT,
            ministry VARCHAR(255),
            is_active BOOLEAN DEFAULT true,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Create indexes for better performance
        CREATE INDEX IF NOT EXISTS idx_claims_status ON claims(status);
        CREATE INDEX IF NOT EXISTS idx_claims_district ON claims(district);
        CREATE INDEX IF NOT EXISTS idx_claims_user_id ON claims(user_id);
        CREATE INDEX IF NOT EXISTS idx_feedback_status ON feedback(status);
        CREATE INDEX IF NOT EXISTS idx_issues_status ON issues(status);
        CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    `;

    try {
        await pool.query(createTablesQuery);
        console.log('✅ Database tables initialized successfully');
        
        // Insert default schemes
        await insertDefaultSchemes();
        
    } catch (error) {
        console.log('❌ Error initializing tables:', error.message);
    }
};

// Insert default government schemes
const insertDefaultSchemes = async () => {
    const schemes = [
        {
            name: 'PM-KISAN',
            code: 'PM_KISAN',
            description: 'Pradhan Mantri Kisan Samman Nidhi Yojana',
            criteria: { land_area: { max: 3 }, farmer: true },
            benefits: 'Rs. 6000 per year in three installments',
            ministry: 'Ministry of Agriculture and Farmers Welfare'
        },
        {
            name: 'Jal Jeevan Mission',
            code: 'JJM',
            description: 'Har Ghar Jal - Providing tap water connection to every household',
            criteria: { water_access: false, rural: true },
            benefits: 'Tap water connection to household',
            ministry: 'Ministry of Jal Shakti'
        },
        {
            name: 'MGNREGA',
            code: 'MGNREGA',
            description: 'Mahatma Gandhi National Rural Employment Guarantee Act',
            criteria: { rural: true, employment_needed: true },
            benefits: '100 days guaranteed employment per year',
            ministry: 'Ministry of Rural Development'
        },
        {
            name: 'Green India Mission',
            code: 'GIM',
            description: 'National Mission for a Green India',
            criteria: { forest_cover: { min: 70 }, tribal_area: true },
            benefits: 'Forest conservation and livelihood support',
            ministry: 'Ministry of Environment, Forest and Climate Change'
        }
    ];

    for (const scheme of schemes) {
        try {
            await pool.query(
                `INSERT INTO schemes (scheme_name, scheme_code, description, eligibility_criteria, benefits, ministry) 
                 VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT (scheme_code) DO NOTHING`,
                [scheme.name, scheme.code, scheme.description, JSON.stringify(scheme.criteria), scheme.benefits, scheme.ministry]
            );
        } catch (error) {
            // Ignore duplicate key errors
        }
    }
};

module.exports = {
    pool,
    testConnection,
    initializeTables
};