#!/bin/bash

# Start Frontend Server Script
# This script starts a simple HTTP server to serve the frontend files

echo "🚀 Starting Frontend Server..."
echo ""
echo "📂 Serving files from current directory"
echo "🌐 Frontend will be available at: http://localhost:8080"
echo ""
echo "⚠️  IMPORTANT: Open http://localhost:8080/index.html in your browser"
echo "   Do NOT open the file directly (file:// protocol won't work)"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

# Check if Python 3 is available
if command -v python3 &> /dev/null; then
    echo "✅ Using Python 3"
    python3 -m http.server 8080
elif command -v python &> /dev/null; then
    echo "✅ Using Python 2"
    python -m SimpleHTTPServer 8080
else
    echo "❌ Python not found!"
    echo "Please install Python or use another HTTP server"
    echo ""
    echo "Alternatives:"
    echo "1. Install Python: https://www.python.org/downloads/"
    echo "2. Use Node.js: npx http-server -p 8080"
    echo "3. Use PHP: php -S localhost:8080"
    exit 1
fi
