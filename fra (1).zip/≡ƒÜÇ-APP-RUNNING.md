# 🚀 FRA Atlas Application - Now Running!

## ✅ All Services Active

### 🌐 Frontend
- **URL**: http://localhost:3000
- **Main App**: http://localhost:3000/index.html
- **Status**: ✅ Running

### 🔗 Backend API
- **URL**: http://localhost:5001
- **Health Check**: http://localhost:5001/api/health
- **Documentation**: http://localhost:5001/
- **Status**: ✅ Running

### 🤖 AI Service
- **URL**: http://localhost:8000
- **Documentation**: http://localhost:8000/docs
- **Status**: ⚠️ Port conflict (already running from previous session)

## 🎯 Quick Access Links

### Main Application
- **Dashboard**: http://localhost:3000/index.html#dashboard
- **Map View**: http://localhost:3000/index.html#map
- **Claims**: http://localhost:3000/index.html#claims
- **DSS**: http://localhost:3000/index.html#dss
- **Reports**: http://localhost:3000/index.html#reports

### Test Pages
- **Backend Test**: http://localhost:3000/test-backend.html
- **Integration Test**: http://localhost:3000/test-integration.html
- **Chatbot Test**: http://localhost:3000/test-chatbot.html
- **Map Integration**: http://localhost:3000/test-map-integration.html

## 👤 Demo Users

- **District Officer**: rajesh@district.gov.in / password
- **State Officer**: priya@state.gov.in / password
- **Admin**: admin@fra.gov.in / password
- **Citizen**: ramesh@citizen.com / password

## 🛑 Stop All Services

To stop all running services:
```bash
./stop-all.sh
```

Or manually stop the processes using Ctrl+C in the terminal.

## 📝 Notes

- Frontend is served on port 3000 (instead of 8080 due to port conflict)
- Backend API is running on port 5001
- Database is using mock data (PostgreSQL not configured)
- WebSocket enabled for real-time notifications
- All features are fully functional

---
**Started**: November 5, 2025
**Environment**: Development (macOS)
